
// React-router handles navigation between these application 'pages'
// (each page is really just an independent React component)
import AppHome from './components/home/AppHome';

// Application Page Components
import LoginPage from './components/home/LoginPage';
import HeatMap from './components/home/HeatMap';
import ChartDetailsPage from './components/ChartDetails/ChartDetailsPage';
import TransactionsDashboard from './components/dashboards/transactions/TransactionsDashboard';
import WorkflowsDashboard from './components/dashboards/workflows/WorkflowsDashboard';
import OperationsDashboard from './components/dashboards/operations/OperationsDashboard';
import ApplicationsDashboard from './components/dashboards/applications/ApplicationsDashboard';
import Registration from './components/home/Registration';
import AlertCreation from './components/home/AlertCreation';
import UserLoginComplete from './components/home/UserLoginComplete';

// NotFound Component (404)
import NotFound from './components/404/NotFound';

module.exports = {
  routes: [
    { path: '/',
      component: AppHome,
      indexRoute: { components: LoginPage },
      childRoutes: [
        { path: 'chartDetail', components: ChartDetailsPage },
        { path: 'TxnDashboard', components: TransactionsDashboard },
        { path: 'WorkflowsDashboard', components: WorkflowsDashboard },
        { path: 'AppDashboard', components: ApplicationsDashboard },
        { path: 'OperationsDashboard', components: OperationsDashboard },
        { path: 'heatmap', components: HeatMap },
        { path: 'Registration', components: Registration },
        { path: 'AlertCreation', components: AlertCreation },
        { path: 'logincomplete', components: UserLoginComplete },
        { path: 'not-found', components: NotFound }, // keep this line for explicitly redirecting to a 404 page from web server (e.g. hapi.js)
      ],
    },
    {
      path: '*', // for all other routes not defined above, redirect to 404 page
      component: AppHome,
      indexRoute: { components: NotFound },
    },
  ],
};
