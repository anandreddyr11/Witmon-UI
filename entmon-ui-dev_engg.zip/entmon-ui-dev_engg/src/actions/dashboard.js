export function dashboardAppsSet(appDetails) {
  return {
    type: 'DASHBOARD_APPS_SET',
    appDetails,
  };
}

export function duplicateApiSet(apiDetails) {
  return {
    type: 'DASHBOARD_DUPLICATEAPI_SET',
    apiDetails,
  };
}

export function showWorkflowFormSet(bool) {
  return {
    type: 'DASHBOARD_SHOWWORKFLOWFORM_SET',
    bool,
  };
}

export function isWorkflowFormUpdateSet(bool) {
  return {
    type: 'DASHBOARD_ISWORKFLOWFORMUPDATE_SET',
    bool,
  };
}

export function workflowFormDataSet(workflowData) {
  return {
    type: 'DASHBOARD_WORKFLOWFORMDATA_SET',
    workflowData,
  };
}
