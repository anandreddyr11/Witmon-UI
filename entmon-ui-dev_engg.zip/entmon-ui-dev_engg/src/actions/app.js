export function appErrorsSet(appErrors) {
  return {
    type: 'APP_ERRORS_SET',
    appErrors,
  };
}
