const reduxStorageKeys = require('../components/home/common.js').reduxStorageKeys;

export function menuCurrentPageSet(page) {
  return {
    type: 'TOPMENU_CURRENTPAGE_SET',
    page,
  };
}

export function menuTimeRangeSet(menu, timeRange) {
  localStorage.setItem(reduxStorageKeys.menuTimeRange, timeRange);
  localStorage.removeItem(reduxStorageKeys.menuCustomStartTime);

  return {
    type: 'TOPMENU_TIMERANGE_SET',
    menu,
    timeRange
  };
}

export function menuCustomTimeRangeStartTimeSet(menu, timeRange, customStartTime) {
  localStorage.setItem(reduxStorageKeys.menuTimeRange, timeRange);
  // Using getTime() to store as epoch timestamp to avoid moment.js deprecation warning
  // See warning with the following: moment(new Date().toString())
  localStorage.setItem(reduxStorageKeys.menuCustomStartTime, customStartTime.getTime());

  return {
    type: 'TOPMENU_TIMERANGE_CUSTOMSTART_SET',
    menu,
    timeRange,
    customStartTime
  };
}

export function menuThemeSet(themeLabel) {
  localStorage.setItem(reduxStorageKeys.menuTheme, themeLabel);

  return {
    type: 'TOPMENU_THEME_SET',
    themeLabel
  };
}

export function menuWorkflowGroupsSet(workflowGroups) {
  return {
    type: 'TOPMENU_WORKFLOWGROUPS_SET',
    workflowGroups,
  };
}

/**
 * Called by comp to set app name array on menu
 */
export function menuAppnamesSet(appNames) {
  return {
    type: 'TOPMENU_APPNAMES_SET',
    appNames
  };
}

/**
 * Called by comp to set app name array on menu
 */
export function menuAppnameSet(menu, appNameList, appSelected) {
  return {
    type: 'TOPMENU_APPNAME_SET',
    menu,
    app: { appNameList, appSelected }
  };
}

/**
 * flag indicating app name should be shown. Default is true
 * @param {*} bool
 */
export function menuShowAppnamesSet(bool) {
  return {
    type: 'TOPMENU_SHOWAPPNAMES_SET',
    bool,
  };
}

export function menuAppNamesSelectedSet(appNames, appNamesSelected) {
  localStorage.setItem(reduxStorageKeys.menuAppNamesSelected, appNamesSelected);
  const apps = appNames.filter((element, index) => appNamesSelected[index]);
  return {
    type: 'TOPMENU_APPNAMESSELECTED_SET',
    apps,
    appNamesSelected,
  };
}

export function menuWorkflowGroupsSelectedSet(workflowGroups, workflowGroupsSelected) {
  localStorage.setItem(reduxStorageKeys.menuWorkflowGroupsSelected, workflowGroupsSelected);
  const groups = workflowGroups.filter((element, index) => workflowGroupsSelected[index]);
  return {
    type: 'TOPMENU_WORKFLOWGROUPSSELECTED_SET',
    groups,
    workflowGroupsSelected,
  };
}

export function menuAutoRefreshSet(bool) {
  localStorage.setItem(reduxStorageKeys.autoRefreshEnabled, bool);
  return {
    type: 'TOPMENU_AUTOREFRESH_SET',
    bool,
  };
}

export function menuRefreshNow() {
  return {
    type: 'TOPMENU_REFRESHNOW_CHANGED',
    changedTime: new Date()
  };
}

export function menuShowTimeRangeSet(bool) {
  return {
    type: 'TOPMENU_SHOWTIMERANGE_SET',
    bool
  };
}

export function menuShowMenuSet(bool) {
  return {
    type: 'TOPMENU_SHOWMENU_SET',
    bool
  };
}
