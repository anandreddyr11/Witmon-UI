
const Config = require(`../../config.${process.env.NODE_ENV}.json`);

export function loginErrored(errorDetail) {
  return {
    type: 'USER_LOGIN_ERRORED',
    errorDetail
  };
}

export function loginIsProcessing(bool) {
  return {
    type: 'USER_LOGIN_PROCESSING',
    isLoading: bool
  };
}

export function loginProcessComplete(user) {
  return {
    type: 'USER_LOGIN_PROCESS_COMPLETE',
    user
  };
}

export function processLogout(user) {
  sessionStorage.removeItem("UserProfileRespTxt");
  return {
    type: 'USER_LOGIN_PROCESS_LOGOUT',
    user
  };
}

export function processLogin(token) {
  return (dispatch) => {
    dispatch(loginIsProcessing(true));
    dispatch(loginErrored({ hasErrored: false, errorText: "" }));
    sessionStorage.removeItem("UserProfileRespTxt");
    // FIXME - do we need to convert XMLHttpRequest to someting modern like fetch?
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
      if (this.readyState === 4) {
        if (this.status == 200) { // action to be performed when the document is ready:
          let reponse = JSON.parse(xhttp.responseText);
          dispatch(loginProcessComplete(reponse));
          if (!reponse.loggedin)
            dispatch(loginErrored({ hasErrored: true, errorText: reponse.errormessages[0] }));
          else
            sessionStorage.setItem("UserProfileRespTxt", xhttp.responseText); // Saving response text in storage in case of hard reload at a later point
        }
        else {
          dispatch(loginErrored({ hasErrored: true, errorText: xhttp.statusText }));
        }
        dispatch(loginIsProcessing(false));
      }
    };
    xhttp.open("GET", `${Config.serverUrl}/get-user-profile`, true);
    xhttp.setRequestHeader("authorization", `Bearer ${((token.indexOf("&") > 0) ? token.split("&")[0] : token)}`);
    xhttp.send();
  };
}

/*

{
  "email": "test@example.com",
  "fname": "Dan",
  "lname": "Brown",
  "loggedin": false,
  "autherror": false
}

*/
