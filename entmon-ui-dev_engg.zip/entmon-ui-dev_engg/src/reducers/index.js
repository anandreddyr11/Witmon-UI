import { combineReducers } from 'redux';

import {
  appErrors,
} from './app';

import {
  userProfile,
  loginErrored,
  loginIsProcessing,
} from './user';

import {
  menuCurrentPage,
  menuRefreshNowChanged,
  menuOptions,
  menuTheme,
  menuAppnames,
  menuAppNamesSelected,
  menuWorkflowGroupsSelected,
  menuWorkflowGroups,
  menuShowAppnames,
  menuShowTimeRange,
  menuAutoRefresh,
  menuShowMenu,
} from './menu';

import {
  dashboardApps,
  dashboardDuplicateApis,
  showWorkflowForm,
  workflowFormData,
  isWorkflowFormUpdate,
} from './dashboard';

export default combineReducers({
  appErrors,
  userProfile, // UID Login
  menuCurrentPage,
  loginErrored,
  loginIsProcessing,
  menuRefreshNow: menuRefreshNowChanged, // Top Bar Menu
  menuOptions,
  menuTheme,
  menuAppnames,
  menuAppNamesSelected,
  menuWorkflowGroupsSelected,
  menuWorkflowGroups,
  menuShowAppnames,
  menuShowTimeRange,
  menuAutoRefresh,
  dashboardApps,
  dashboardDuplicateApis,
  showWorkflowForm,
  isWorkflowFormUpdate,
  workflowFormData,
  menuShowMenu,
});
