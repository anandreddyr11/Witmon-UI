export function appErrors(state = [], action) {
  switch (action.type) {
    case 'APP_ERRORS_SET': {
      return action.appErrors;
    }
    default:
      return state;
  }
}
