export function loginErrored(state = {hasErrored: false, errorText: ""}, action) {
    //console.log("REDUCER: loginErrored", state, action);
    switch (action.type) {
        case 'USER_LOGIN_ERRORED':
            return action.errorDetail;
        default:
            return state;
    }
}

export function loginIsProcessing(state = false, action) {
    //console.log("REDUCER: loginIsProcessing", state, action);
    switch (action.type) {
        case 'USER_LOGIN_PROCESSING':
            return action.isLoading;
        default:
            return state;
    }
}

export function userProfile(state = {}, action) {
    //console.log("REDUCER: userProfile", state, action);
    switch (action.type) {
        case 'USER_LOGIN_PROCESS_COMPLETE':
            return action.user;
        case 'USER_LOGIN_PROCESS_LOGOUT':
            return Object.assign({}, action.user, {
                loggedin: false
            });
        default:
            return state;
    }
}