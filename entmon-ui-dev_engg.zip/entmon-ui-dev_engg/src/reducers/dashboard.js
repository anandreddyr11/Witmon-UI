export function dashboardApps(state = [], action) {
  switch (action.type) {
    case 'DASHBOARD_APPS_SET': {
      return action.appDetails;
    }
    default:
      return state;
  }
}

export function dashboardDuplicateApis(state = [], action) {
  switch (action.type) {
    case 'DASHBOARD_DUPLICATEAPI_SET': {
      return action.apiDetails;
    }
    default:
      return state;
  }
}

export function showWorkflowForm(state = false, action) {
  switch (action.type) {
    case 'DASHBOARD_SHOWWORKFLOWFORM_SET': {
      return action.bool;
    }
    default:
      return state;
  }
}

export function isWorkflowFormUpdate(state = false, action) {
  switch (action.type) {
    case 'DASHBOARD_ISWORKFLOWFORMUPDATE_SET': {
      return action.bool;
    }
    default:
      return state;
  }
}

export function workflowFormData(state = {}, action) {
  switch (action.type) {
    case 'DASHBOARD_WORKFLOWFORMDATA_SET': {
      return action.workflowData;
    }
    default:
      return state;
  }
}
