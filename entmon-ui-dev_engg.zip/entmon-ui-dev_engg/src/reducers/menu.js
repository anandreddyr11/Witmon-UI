const reduxStorageKeys = require('../components/home/common.js').reduxStorageKeys;

const menuTimeRange = JSON.parse(localStorage.getItem(reduxStorageKeys.menuTimeRange)) || 0.5;
const menuCustomStartTime = JSON.parse(localStorage.getItem(reduxStorageKeys.menuCustomStartTime));
const menuAppNamesSelectedStorage = JSON.parse(`[${localStorage.getItem(reduxStorageKeys.menuAppNamesSelected)}]`);
const menuWorkflowGroupsSelectedStorage = JSON.parse(`[${localStorage.getItem(reduxStorageKeys.menuWorkflowGroupsSelected)}]`);
const TOMPMENU_DEFAULT_THEME = localStorage.getItem(reduxStorageKeys.menuTheme) || 'Light Theme';

const storedAutoRefresh = JSON.parse(localStorage.getItem(reduxStorageKeys.autoRefreshEnabled));
// If auto refresh option isn't in session storage, turn it on by default
const TOMPMENU_DEFAULT_AUTOREF_ENABLED = storedAutoRefresh !== null ? storedAutoRefresh : true;

// Initial states
const TOPMENU_DEFAULTS = {
  menuTimeRange: menuTimeRange,
  menuCustomStartTime: menuCustomStartTime,
  apps: [{ appName: "All Apps", appInstanceId: "" }],
  themeLabel: TOMPMENU_DEFAULT_THEME,
};

export function menuCurrentPage(state = 'Dashboard', action) {
  switch (action.type) {
    case 'TOPMENU_CURRENTPAGE_SET':
      return action.page;
    default:
      return state;
  }
}

export function menuRefreshNowChanged(state = new Date(), action) {
  switch (action.type) {
    case 'TOPMENU_REFRESHNOW_CHANGED':
      return action.changedTime;
    default:
      return state;
  }
}

export function menuTheme(state = TOMPMENU_DEFAULT_THEME, action) {
  switch (action.type) {
    case 'TOPMENU_THEME_SET':
      return action.themeLabel;
    default:
      return state;
  }
}

export function menuWorkflowGroups(state = [], action) {
  switch (action.type) {
    case 'TOPMENU_WORKFLOWGROUPS_SET':
      return action.workflowGroups;
    default:
      return state;
  }
}

export function menuAppnames(state = [], action) {
  switch (action.type) {
    case 'TOPMENU_APPNAMES_SET':
      return action.appNames;
    default:
      return state;
  }
}

export function menuAppNamesSelected(state = menuAppNamesSelectedStorage, action) {
  switch (action.type) {
    case 'TOPMENU_APPNAMESSELECTED_SET':
      return action.appNamesSelected;
    default:
      return state;
  }
}

export function menuWorkflowGroupsSelected(state = menuWorkflowGroupsSelectedStorage, action) {
  switch (action.type) {
    case 'TOPMENU_WORKFLOWGROUPSSELECTED_SET':
      return action.workflowGroupsSelected;
    default:
      return state;
  }
}

/**
 * Show app name or not. Its enabled by default
 */
export function menuShowAppnames(state = true, action) {
  switch (action.type) {
    case 'TOPMENU_SHOWAPPNAMES_SET':
      return action.bool;
    default:
      return state;
  }
}

export function menuAutoRefresh(state = TOMPMENU_DEFAULT_AUTOREF_ENABLED, action) {
  switch (action.type) {
    case 'TOPMENU_AUTOREFRESH_SET':
      return action.bool;
    default:
      return state;
  }
}

/**
 * Display time range in menu. Its displayed by default
 * @param {Enable/Disable time range visiblity} state
 * @param {*} action
 */
export function menuShowTimeRange(state = true, action) {
  switch (action.type) {
    case 'TOPMENU_SHOWTIMERANGE_SET':
      return action.bool;
    default:
      return state;
  }
}

export function menuOptions(state = TOPMENU_DEFAULTS, action) {
  switch (action.type) {
    case 'TOPMENU_TIMERANGE_SET':
      return Object.assign({}, action.menu, {
        menuTimeRange: action.timeRange,
        menuCustomStartTime: null // Reset start time as we are setting only time range; ie; last n hours
      });
    case 'TOPMENU_TIMERANGE_CUSTOMSTART_SET':
      return Object.assign({}, action.menu, {
        menuTimeRange: action.timeRange,
        menuCustomStartTime: action.customStartTime
      });
    default:
      return state;
  }
}

export function menuShowMenu(state = true, action) {
  switch (action.type) {
    case 'TOPMENU_SHOWMENU_SET':
      return action.bool;
    default:
      return state;
  }
}
