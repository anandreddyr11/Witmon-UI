/* eslint-disable import/default */

import React from 'react';
import ReactDom from 'react-dom';
import Routes from './routes';
import {Router, hashHistory} from 'react-router';
require("grommet/scss/hpe/index.scss");
require('./images/favicon.ico');
let element = document.getElementById('app');

ReactDom.render(<Router history={hashHistory} routes={Routes.routes} /> , element);

document.body.classList.remove('loading');
