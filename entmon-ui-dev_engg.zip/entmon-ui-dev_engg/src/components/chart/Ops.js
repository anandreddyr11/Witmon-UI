import React from 'react';
import * as d3 from 'd3';
import d3Tip from 'd3-tip';
import moment from 'moment';
let common = require('../home/common.js');

let emitter;
const CPU = 0,
  MEMORY = 1,
  CONNECTIONS = 2,
  containerResizeDelta = 32,
  TRANSITIONDURATION = 1500,
  MAXPERCENTAGE = 100,
  DOTRADIUS = 3,
  DATEFORMAT = 'YYYY-MM-DD HH:mm:ss';

const legendData = [
  {
    color: '#2ad2c9',
    name: 'CPU'
  },
  {
    color: '#614767',
    name: 'Memory'
  },
  {
    color: '#ff8d6d',
    name: 'Connections'
  }
];

export default class Ops extends React.Component {
  constructor(props) {
    super(props);
    this.dimensionsUpdated = this.dimensionsUpdated.bind(this);
    this.containerWidth = 0;
    emitter = this.props.emitter;
    this.subscriptionMoveCrosshair = null;
    this.subscriptionHideCrosshair = null;
    this.cpuVerticalLine = null;
    this.memoryVerticalLine = null;
    this.connectionsVerticalLine = null;
    this.x = null;
    this.moveCrosshair = this.moveCrosshair.bind(this);
    this.hideCrosshair = this.hideCrosshair.bind(this);
  }

  componentDidMount() {
    this.containerWidth = d3.select(this.refs.container).node()
      .getBoundingClientRect().width;
    window.addEventListener('resize', this.dimensionsUpdated);
    this.subscriptionMoveCrosshair = emitter
      .addListener(common.eventNames.moveCrosshair, this.moveCrosshair);
    this.subscriptionHideCrosshair = emitter
      .addListener(common.eventNames.hideCrosshair, this.hideCrosshair);
    this.forceUpdate();
  }

  componentDidUpdate(prevProps) {
    d3.select(this.refs.cpuChart).html('');
    d3.select(this.refs.cpuGauge).html('');
    d3.select(this.refs.memoryChart).html('');
    d3.select(this.refs.memoryGauge).html('');
    d3.select(this.refs.connectionsChart).html('');
    d3.select(this.refs.connectionsGauge).html('');
    d3.select(this.refs.legend).html('');
    this.draw(this.props.data, prevProps.data, this.props, prevProps);
    this.addLegend();
  }

  componentWillUnmount() {
    window.removeEventListener("resize", this.dimensionsUpdated);
    if (this.subscriptionMoveCrosshair && this.subscriptionHideCrosshair) {
      this.subscriptionMoveCrosshair.remove();
      this.subscriptionHideCrosshair.remove();
    }
  }

  moveCrosshair(timestamp) {
    if (this.cpuVerticalLine && this.memoryVerticalLine && this.connectionsVerticalLine && this.x) {
      let px = this.x(timestamp);
      this.cpuVerticalLine.attr("x1", px).attr("x2", px).attr("opacity", 1);
      this.memoryVerticalLine.attr("x1", px).attr("x2", px).attr("opacity", 1);
      this.connectionsVerticalLine.attr("x1", px).attr("x2", px).attr("opacity", 1);
    }
  }

  hideCrosshair() {
    if (this.cpuVerticalLine && this.memoryVerticalLine && this.connectionsVerticalLine) {
      this.cpuVerticalLine.attr("opacity", 0);
      this.memoryVerticalLine.attr("opacity", 0);
      this.connectionsVerticalLine.attr("opacity", 0);
    }
  }

  dimensionsUpdated() {
    let width = d3.select(this.refs.container).node().getBoundingClientRect().width;

    if (Math.abs(width - this.containerWidth) > containerResizeDelta) {
      this.containerWidth = width;
      this.forceUpdate();
    }
  }

  addLegend() {
    // @todo: Manage this in one place to avoid duplication from drawChart
    let winwidth = 530;
    let width = winwidth - 35;

    let legendContainer = d3.select(this.refs.legend);

    let legend = legendContainer.selectAll(".legend")
      .data(legendData)
      .enter().append("g")
      .attr("class", "legend")
      .attr("transform", (d, i) => "translate(30," + i * 19 + ")");

    legend.append("rect")
      .attr("x", width - 18)
      .attr("width", 18)
      .attr("height", 18)
      .style("fill", (d, i) => legendData[i].color)
      .style("background", (d, i) => legendData[i].color);

    legend.append("text")
      .attr("x", width + 5)
      .attr("y", 9)
      .attr("dy", ".35em")
      .style("text-anchor", "start")
      .text((d, i) => legendData[i].name);
  }

  extractCpuData(data) {
    return data.map(
      (v, i) => ({
        time: (new Date(data[i].ops_reported_time)).valueOf(),
        xdata: data[i].cpu_usage,
        item: 'CPU Percentage'
      }
      ));
  }

  extractMemoryData(data) {
    return data.map(
      (v, i) => ({
        time: (new Date(data[i].ops_reported_time)).valueOf(),
        xdata: data[i].memory_consumption,
        item: 'Memory Utilization'
      }
      ));
  }

  extractConnectionsData(data) {
    return data.map(
      (v, i) => ({
        time: (new Date(data[i].ops_reported_time)).valueOf(),
        xdata: data[i].concurrent_connections,
        item: 'Active Connections'
      }
      ));
  }

  calculateArea(d3, x, height, y, firstRender) {
    let area = d3.area()
      .x(d => x(d.time))
      .y0(height)
      .y1(firstRender ? height : (d => y(d.xdata)))
      .curve(d3.curveCardinal);

    return area;
  }

  drawPath(svg, data, area, legendIndex) {
    let path = svg.append("path")
      .data([data])
      .attr("class", "area")
      .attr("d", area)
      .attr("fill", legendData[legendIndex].color);

    return path;
  }

  transitionPath(path, area) {
    path.transition()
      .duration(TRANSITIONDURATION)
      .attr("d", area);
  }

  drawDots(svg, data, x, y, height, tip, firstRender) {
    tip.html(d => {
      if (d.item !== "Active Connections") {
        return `<b>Start Time : </b> ${moment(d.time).format(DATEFORMAT)} <br/> <b> ${d.item} : </b> ${Math.round(d.xdata * 100) / 100} %`;
      }
      else {
        return `<b>Start Time : </b> ${moment(d.time).format(DATEFORMAT)} <br/> <b> ${d.item} : </b> ${d.xdata}`;
      }
    });
    let dotRadius = firstRender ? 0 : DOTRADIUS;
    let cyValue = firstRender ? height : d => y(d.xdata);
    let dots = svg.selectAll("dot")
      .data(data)
      .enter().append("circle")
      .attr("r", dotRadius)
      .attr("cx", d => x(d.time))
      .attr("cy", cyValue)
      .on('mouseover', tip.show)
      .on('mouseout', tip.hide);

    return dots;
  }

  transitionDots(dots, x, y) {
    dots.transition()
      .duration(TRANSITIONDURATION)
      .attr("r", DOTRADIUS)
      .attr("cx", d => x(d.time))
      .attr("cy", d => y(d.xdata));
  }

  isEqualData(prevData, newData) {
    for (let i = 0; i < newData.length; i++) {
      if (prevData[i].time !== newData[i].time ||
        prevData[i].xdata !== newData[i].xdata ||
        prevData[i].item !== newData[i].item) {
        return false;
      }
    }
    return true;
  }

  draw(data, prevData, props, prevProps) {

    let cpu = this.extractCpuData(data);
    let prevCpu = this.extractCpuData(prevData);

    let memory = this.extractMemoryData(data);
    let prevMemory = this.extractMemoryData(prevData);

    let connections = this.extractConnectionsData(data);
    let prevConnections = this.extractConnectionsData(prevData);

    // Draw charts and gauges
    this.drawChart(cpu, prevCpu, this.refs.cpuChart, CPU, props, prevProps);
    this.drawChart(memory, prevMemory, this.refs.memoryChart, MEMORY, props, prevProps);
    this.drawChart(connections, prevConnections, this.refs.connectionsChart, CONNECTIONS, props, prevProps);
  }

  drawChart(data, prevData, chartContainer, legendIndex, props, prevProps) {
    let tooltips = document.getElementsByClassName('d3-tip');
    for (let i = 0; i < tooltips.length; i++) {
      tooltips[i].style["opacity"] = 0;
    }
    let winwidth = (d3.select(chartContainer).node().getBoundingClientRect().width) - 10;
    let margin = { top: 20, right: 20, bottom: 180, left: 50 },
      width = winwidth,
      height = 50;
    let startTime = props.startTime;
    let endTime = props.endTime;
    let prevStartTime = prevProps.startTime;
    let prevEndTime = prevProps.endTime;

    let x = d3.scaleLinear()
      .range([0, width]);
    this.x = x;

    let y = d3.scaleLinear()
      .domain([0, Math.max(MAXPERCENTAGE, d3.max(data, d => d.xdata))]) // 100 for CPU and memory.
      .range([height, 0]);

    let xAxis = d3.axisBottom()
      .scale(x)
      .ticks(3)
      .tickFormat(d3.timeFormat("%d %b -%H:%M"));

    let yAxis = d3.axisLeft()
      .scale(y)
      .ticks(3);

    x.domain([moment(startTime), moment(endTime)]);

    let svg = d3.select(chartContainer)
      .attr("preserveAspectRatio", "xMinYMin meet")
      .attr("viewBox", "-8 0 " + (width + 125) + " " + (height - 20) + "")
      .attr("width", (width + 100))
      .attr("height", (height + 28))
      .append("g")
      .attr("transform", "translate(" + 50 + "," + 13 + ")");

    svg.append("g")
      .attr("class", "x axis")
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis)
      .selectAll("text")
      .style("text-anchor", "center");

    svg.append("g")
      .attr("class", "y axis")
      .call(yAxis);

    // add the Y gridlines
    svg.append("g")
      .attr("class", "grid")
      .call(d3.axisLeft(y)
        .ticks(1)
        .tickSize(-width)
        .tickFormat("")
      );

    // Add tooltip
    let tip = d3Tip()
      .attr('class', 'd3-tip')
      .offset([-10, 0]);

    svg.call(tip);

    let hasAxis = svg.select('.axis');

    if (!hasAxis) {
      // Not sure when this block will ever be reached.
      alert('in ops.js, this is not expected to be reached because of !hasAxis condition');
      svg.append("svg:g") // add a container for the axis
        .attr("class", "x axis") // add some classes so we can style it
        .attr("transform", "translate(0," + (height - margin.bottom) + ")") // move it into position
        .call(xAxis); // finally, add the axis to the visualisation

      svg.append("svg:g")
        .attr("class", "y axis")
        .attr("transform", "translate(" + (margin.left) + ",0)")
        .call(yAxis);
    }

    let firstRender = prevData === null || prevData.length === 0;
    if (firstRender) {
      y.domain([0, Math.max(MAXPERCENTAGE, d3.max(data, d => d.xdata))]);
      //Draw Path & Dots
      let area = this.calculateArea(d3, x, height, y, firstRender);
      let path = this.drawPath(svg, data, area, legendIndex);

      let dots = this.drawDots(svg, data, x, y, height, tip, firstRender);

      area.y1(d => y(d.xdata));
      this.transitionPath(path, area);
      this.transitionDots(dots, x, y);
    } else {
      if (!this.isEqualData(prevData, data)) { // If new data is different than previous data
        x.domain([moment(prevStartTime), moment(prevEndTime)]);
        y.domain([0, Math.max(MAXPERCENTAGE, d3.max(prevData, d => d.xdata))]);
        // Draw Path
        let area = this.calculateArea(d3, x, height, y, firstRender);
        let path = this.drawPath(svg, prevData, area, legendIndex);

        let dots = this.drawDots(svg, prevData, x, y, height, tip, firstRender);

        x.domain([moment(startTime), moment(endTime)]);
        y.domain([0, Math.max(MAXPERCENTAGE, d3.max(data, d => d.xdata))]);
        path.data([data]);
        this.transitionPath(path, area);

        dots.data(data);
        this.transitionDots(dots, x, y);
      } else {
        y.domain([0, Math.max(MAXPERCENTAGE, d3.max(data, d => d.xdata))]);
        let area = this.calculateArea(d3, x, height, y, firstRender);
        this.drawPath(svg, data, area, legendIndex);

        this.drawDots(svg, data, x, y, height, tip, firstRender);
      }
    }

    // Crosshairs
    let verticalLine = svg.append("line")
      .attr("opacity", 0)
      .attr("y1", 0)
      .attr("y2", height)
      .attr("stroke", "black")
      .attr("stroke-width", 1)
      .attr("pointer-events", "none");

    switch (legendIndex) {
      case CPU:
        this.cpuVerticalLine = verticalLine;
        break;
      case MEMORY:
        this.memoryVerticalLine = verticalLine;
        break;
      case CONNECTIONS:
        this.connectionsVerticalLine = verticalLine;
        break;
      default:
        this.cpuVerticalLine = verticalLine;
    }

    let crosshairArea = svg.selectAll("path");
    crosshairArea.on("mousemove", function () {
      let mouse = d3.mouse(this);
      let timeStamp = mouse.map(x.invert);
      emitter.emit(common.eventNames.moveCrosshair, timeStamp[0]);
    })
      .on("mouseout", function () {
        emitter.emit(common.eventNames.hideCrosshair);
      });
  }

  render() {
    return (
      <div ref="container" className="ops-ec-container">
        <div className="multiLine">
          <svg ref="cpuChart" viewBox="0 0 410 51" preserveAspectRatio="xMidYMid" />
          <span ref="cpuGauge" className="opCharts" />
        </div>
        <div className="multiLine">
          <svg ref="memoryChart" viewBox="0 0 410 50" preserveAspectRatio="xMidYMid" />
          <span ref="memoryGauge" className="opCharts" />
        </div>
        <div className="multiLine">
          <svg ref="connectionsChart" viewBox="0 0 410 51" preserveAspectRatio="xMidYMid" />
          <span ref="connectionsGauge" className="opCharts" />
        </div>
        <div ref="legend" className="legendContain" />
      </div>
    );
  }
}

Ops.propTypes = {
  width: React.PropTypes.number,
  height: React.PropTypes.number,
  margin: React.PropTypes.object,
  data: React.PropTypes.array,
  emitter: React.PropTypes.object,
  gettingData: React.PropTypes.bool,
};
