import React from 'react';
import Tiles from 'grommet/components/Tiles';
import Tile from 'grommet/components/Tile';
import Heading from 'grommet/components/Heading';
import Button from 'grommet/components/Button';
import FormNextLinkIcon from 'grommet/components/icons/base/FormNextLink';
import CloseIcon from 'grommet/components/icons/base/Close';

const common = require('../home/common');

const defaultTransactionLineColor = common.colors.transactions.line;
const defaultWorkflowLineColor = common.colors.workflow.line;
const defaultTransactionBarColorRange = common.colors.transactions.barColorRange;
const defaultWorkflowBarColorRange = common.colors.workflow.barColorRange;
const defaultChartTileHeaderColor = common.colors.tileHeader;

const customizationColors = [
  '#ffcccc', '#ffe0cc', '#ffeacc', '#fff4cc', '#fffecc',
  '#effac8', '#c7f5c4', '#c4f0f4', '#c4daf4', '#c9c4f4',
  '#e1c4f4', '#f6c6e6', '#8e44ad', '#34495e', '#2c3e50',
  '#b3cae5', '#dbdde4', '#e4e3e4', '#f7ddbb', '#efcab2',
  '#bccacc', '#c7d8d6', '#d9ebe0', '#ebf9e3', '#f4f8d0',
  '#5e7fb1', '#dce8f7', '#eff1f4', '#fce1a8', '#f7ec86',
  '#8fb8ee', '#cbe2f4', '#dbe5eb', '#f9d3b8', '#e0b2a3',
  '#a2e0f9', '#cef5fc', '#eafaeb', '#fefcd3', '#fdf4ba',
  '#6bafd2', '#a4c8dc', '#d6cbca', '#eabc96', '#db8876',
  '#b4ced8', '#d7e5d4', '#e2e8c9', '#f1e5b9', '#edd7ac',
  '#29153e', '#657489', '#bfb6aa', '#ead79d', '#f2ebda',
  '#20202f', '#273550', '#416081', '#adacb2', '#eac3a2',
  '#555351', '#8d7b6c', '#cc9d7a', '#fff9aa', '#f8c785',
  '#171c33', '#525f83', '#848896', '#bb9d78', '#f6e183',
  '#ffe3c8', '#efad9e', '#c79797', '#a78a92', '#857d8d',
  '#6f749e', '#9a8daf', '#d0a8b9', '#f8bbb1', '#fde6b1',
  '#536a97', '#8087ad', '#bca391', '#bd968a', '#a38b8a',
  '#325176', '#7b9ea7', '#9baf93', '#dbaf81', '#fbdf73',
  '#727288', '#8e889b', '#d3c2bd', '#f9d89a', '#dc2878',
  '#F8B75F', '#6b486b', '#a05d56', '#ff8c00', '#98abc5',
  '#8a89a6', '#7b6888', '#00cceb', '#4476A0', '#f5f5f5',
  '#f1c40f', '#f39c12', '#e67e22', '#d35400', '#e74c3c',
  '#c0392b', '#ecf0f1', '#bdc3c7', '#95a5a6', '#7f8c8d',
  '#1abc9c', '#16a085', '#2ecc71', '#27ae60', '#3498db',
  '#2980b9', '#9b59b6',
];

export default class ChartTileCustomization extends React.Component {
  constructor(props) {
    super(props);

    this.hideChartCustomization = this.hideChartCustomization.bind(this);
    this.handleResetColorsButton = this.handleResetColorsButton.bind(this);
  }

  hideChartCustomization() {
    this.props.setChartState({ showCustomization: false });
  }

  handleResetColorsButton() {
    this.setLocalStorageColor('lineColor', null);
    this.setLocalStorageColor('barColorRange', null);
    this.setLocalStorageColor('tileHeadingColor', null);
    if (this.props.chartType === 'transactions' || this.props.chartType === 'exception' || this.props.chartType === 'operations') {
      this.props.setChartState({
        lineColor: defaultTransactionLineColor,
        barColorRange: defaultTransactionBarColorRange,
        tileHeadingColor: defaultChartTileHeaderColor,
      });
    } else if (this.props.chartType === 'workflow') {
      this.props.setChartState({
        lineColor: defaultWorkflowLineColor,
        barColorRange: defaultWorkflowBarColorRange,
        tileHeadingColor: defaultChartTileHeaderColor,
      });
    } else {
      this.props.setChartState({ tileHeadingColor: defaultChartTileHeaderColor });
    }
  }

  setLocalStorageColor(stateName, value) {
    const key = `${this.props.userProfile.email}-chartTile-${this.props.chartType}-${this.props.id}-${stateName}`;
    localStorage.setItem(key, JSON.stringify(value));
  }

  getCustomizeChartRender() {
    return (
      <div>
        <Heading tag={'h4'} margin={'none'} className="mt-10">
          Chart Line Color
        </Heading>
        {this.getChartCustomizationTiles('lineColor', false)}
        <Heading tag={'h4'} margin={'none'} className="mt-10">
          Chart Bar Color
        </Heading>
        {this.getChartCustomizationTiles('barColorRange', true)}
      </div>
    );
  }

  getChartCustomizationTiles(stateName, isRange) { 
    return (
      <Tiles>
        {customizationColors.map((color, i) => {
          const active = this.props.chartState[stateName].includes(color);
          const borderStyle = active ? '4px dashed black' : undefined;
          return (
            <Tile key={i} className="charttile-body-content-colortile"
              style={{ backgroundColor: color, border: borderStyle }} onClick={() => {
                if (isRange) {
                  const colorRange = [...this.props.chartState[stateName]];
                  colorRange.shift();
                  colorRange.push(color);
                  this.props.setChartState({ [stateName]: colorRange });
                  this.setLocalStorageColor(stateName, colorRange);
                } else {
                  this.props.setChartState({ [stateName]: color });
                  this.setLocalStorageColor(stateName, color);
                }
              }} />
          );
        })}
      </Tiles>
    );
  }

  render() {
    let isCustomizableChart = false;
    if (this.props.chartType === 'transactions' || this.props.chartType === 'workflow' || this.props.chartType === 'exception' || this.props.chartType === 'operations') {
      isCustomizableChart = true;
    }
    const customizeChartRender = isCustomizableChart ?
      this.getCustomizeChartRender() :
      undefined;
    return (
      <div className="charttile-body">
        <div className="charttile-body-menu">
          <Button icon={<FormNextLinkIcon />} label={'Return'}
            onClick={this.hideChartCustomization} />
          <Button icon={<CloseIcon />} label={'Reset Colors'}
            onClick={this.handleResetColorsButton} />
        </div>
        <div className="charttile-body-content">
          <Heading tag={'h4'} margin={'none'}>
            Tile Heading Color
          </Heading>
          {this.getChartCustomizationTiles('tileHeadingColor', false)}
          {customizeChartRender}
        </div>
      </div>
    );
  }
}

ChartTileCustomization.propTypes = {
  id: React.PropTypes.string.isRequired,
  userProfile: React.PropTypes.object.isRequired,
  chartType: React.PropTypes.string.isRequired,
  chartState: React.PropTypes.object.isRequired,
  setChartState: React.PropTypes.func.isRequired,
};
