import React from 'react';
import * as d3 from 'd3';
import Spinning from 'grommet/components/icons/Spinning';
import Box from 'grommet/components/Box';

const transitionDuration = 1000;

export default class HorizontalStackedBar extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      color: d3.scaleOrdinal(d3.schemeCategory20c),
      xScale: d3.scaleLinear().rangeRound([0, this.props.chartWidth]),
    };

    this.bars;
  }

  componentDidMount() {
    this.draw();
  }

  componentDidUpdate() {
    d3.select(this.refs.chart).html('');
    d3.select(this.refs.legend).html('');
    this.draw();
  }

  drawChart() {
    const parseDate = d3.utcParse('%Y-%m-%d %H:%M:%S.%L');
    const margin = { top: 0, right: 20, bottom: 40, left: 50 };
    const yScale = d3.scaleBand().rangeRound([this.props.chartHeight, 0])
      .padding(0.1);

    const xAxis = d3.axisBottom(this.state.xScale);
    let yAxis;
    if (this.props.disableYAxisTickLabels) {
      yAxis = d3.axisLeft(yScale).tickFormat(d3.timeFormat(''));
    } else {
      yAxis = d3.axisLeft(yScale).tickFormat(d3.timeFormat('%d %b'));
    }

    const chart = d3.select(this.refs.chart)
      .append('svg')
      .attr('width', this.props.chartWidth + margin.left + margin.right)
      .attr('height', this.props.chartHeight + margin.top + margin.bottom)
      .append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);

      const layers = d3.stack()
      .keys(this.props.stackKeys)
      .offset(d3.stackOffsetNone)(this.props.data);

    yScale.domain(this.props.data.map(d => parseDate(d.start_time)));
    this.state.xScale.domain([0, d3.max(layers[layers.length - 1], d => d[0] + d[1])]).nice();

    this.bars = chart.append('g')
      .selectAll('.stackedBar')
      .data(layers)
      .enter()
      .append('g')
      .attr('class', 'layer')
      .style('fill', (d, i) => {
        let name = this.props.stackKeys[i];
        name = name.substr(0,name.length - (i+'').length);
        return this.state.color(name);
      })
      .selectAll('rect')
      .data(d => d)
      .enter()
      .append('rect')
      .attr('x', () => this.state.xScale(0))
      .attr('y', d => yScale(parseDate(d.data.start_time)))
      .attr('width', () => this.state.xScale(0) - this.state.xScale(0))
      .attr('height', yScale.bandwidth());

    this.bars.transition()
      .duration(transitionDuration)
      .attr('x', d => this.state.xScale(d[0]))
      .attr('width', d => (this.state.xScale(d[1]) - this.state.xScale(d[0])) - 2 );

    // X-axis.
    chart.append('g')
      .attr('class', 'axis axis--x')
      .attr('transform', `translate(0, ${this.props.chartHeight})`)
      .call(xAxis);

    // Y-axis.
    chart.append('g')
      .attr('class', 'axis axis--y')
      .attr('transform', 'translate(0, 0)')
      .call(yAxis);

    // X-axis label.
    const xAxisLabel = chart.append('text')
      .text('Duration (ms)');
    xAxisLabel.attr('y', this.props.chartHeight + margin.top + margin.bottom - 5)
      .attr('x', this.props.chartWidth / 2 - (xAxisLabel.node().getBBox().width / 2));
  }

  drawLegend() {
    const legend = d3.select(this.refs.legend);

    let keysObj = {}; 
    this.props.stackKeys.forEach((name,i) => {
      name = name.substr(0,name.length - (i+'').length);
      keysObj[name] = {}; 
    })

    const legendItems = legend.selectAll('.legend')
      .data(Object.keys(keysObj))
      .enter()
      .append('div')
      .attr('class', 'legend-item');

    // Add legend squares
    legendItems.append('div')
      .attr('class', 'legend-item-box')
      .style('background', d => this.state.color(d));

    // Add legend texts
    legendItems.append('text')
      .text(d => d);
  }

  draw() {
    this.drawChart();
    this.drawLegend();
  }

  getChartContent() {
    if (this.props.gettingData) {
      return (
        <Box direction="row" full="horizontal" justify="end" className="charttile-heading-buttons">
          <Box pad={'small'}>
            <Spinning size="small" />
          </Box>
        </Box>
      );
    } else {
      return (
        <div className="horizontal-stacked-bar">
          <div className="chart" ref="chart" />
          <div className="legend" ref="legend" style={{ width: this.props.chartWidth }} />
        </div>);
    }
  }

  render() {
    return (
      <div>{this.getChartContent()}</div>
    );
  }
}

HorizontalStackedBar.propTypes = {
  disableYAxisTickLabels: React.PropTypes.bool,
  data: React.PropTypes.array.isRequired,
  stackKeys: React.PropTypes.array.isRequired,
  chartWidth: React.PropTypes.number.isRequired,
  chartHeight: React.PropTypes.number.isRequired,
  gettingData: React.PropTypes.bool,
};
