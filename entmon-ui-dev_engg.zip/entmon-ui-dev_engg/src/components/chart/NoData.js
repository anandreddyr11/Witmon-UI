import React from 'react';
import * as d3 from 'd3';

const common = require('../home/common.js');

export default class NoData extends React.Component {
  componentDidMount() {
    this.getChartStatus(this.props);
  }
  componentWillReceiveProps(nextProps) {
    this.getChartStatus(nextProps);
  }
  getChartStatus(props){
    d3.select(this.refs.chart).html('');
    // Add no data / retrieving data html
    d3.select(this.refs.chart)
      .classed('svg-container', false)
      .append('div')
      .attr('class', 'nodatadiv')
      .html(props.gettingData ? common.messages.gettingdata : common.messages.nodata);
  }

  render() {
    return (
      <div ref="container" className="chartholder">
        <div ref="chart" />
        <div ref="legend" className="legendContain" />
      </div>
    );
  }
}

NoData.propTypes = {
  gettingData: React.PropTypes.bool,
};
