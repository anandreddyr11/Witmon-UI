import React from 'react';
import * as d3 from 'd3';
import moment from 'moment';

const common = require('../home/common.js');

let emitter;

const containerResizeDelta = 10;
const TRANSITIONDURATION = 1000;
const DOTRADIUS = 3;
const dateFormat = 'YYYY-MM-DD HH:mm:ss';
const maximumYAxisTicks = 8;

export default class LineChart extends React.Component {
  constructor(props) {
    super(props);
    this.containerWidth = 0;
    emitter = this.props.emitter;
    this.subscriptionMoveCrosshair;
    this.subscriptionHideCrosshair;
    this.verticalLine = null;
    this.x = null;
    this.firstRender = true;

    const colorRange = d3.scaleOrdinal().range(props.colorRange);
    const legendData = [{
      name: props.lineKey,
      color: props.lineColor,
    }];

    this.state = {
      legendData,
      colorRange,
    };

    this.draw = this.draw.bind(this);
    this.moveCrosshair = this.moveCrosshair.bind(this);
    this.hideCrosshair = this.hideCrosshair.bind(this);
    this.getLegendTooltipHtml = this.getLegendTooltipHtml.bind(this);
    this.dimensionsUpdated = this.dimensionsUpdated.bind(this);
  }

  componentDidMount() {
    this.containerWidth = d3.select(this.refs.container).node()
      .getBoundingClientRect().width;
    window.addEventListener('resize', this.dimensionsUpdated);
    this.subscriptionMoveCrosshair = emitter.addListener(common.eventNames.moveCrosshair,
      this.moveCrosshair);
    this.subscriptionHideCrosshair = emitter.addListener(common.eventNames.hideCrosshair,
      this.hideCrosshair);
    this.forceUpdate();
  }

  componentDidUpdate(prevProps) {
    // Destroy the chart and rerender svg
    d3.select(this.refs.chart).html('');
    d3.select(this.refs.legend).html('');
    this.draw(this.props.barData, this.props, prevProps);
  }

  componentWillUnmount() {
    // Remove event listeners
    window.removeEventListener('resize', this.dimensionsUpdated);
    if (this.subscriptionMoveCrosshair !== undefined) {
      this.subscriptionMoveCrosshair.remove();
    }
    if (this.subscriptionHideCrosshair !== undefined) {
      this.subscriptionHideCrosshair.remove();
    }
  }

  moveCrosshair(timestamp) {
    if (this.verticalLine && this.x) {
      const px = this.x(timestamp);
      this.verticalLine.attr('x1', px).attr('x2', px)
        .attr('opacity', 1);
    }
  }

  hideCrosshair() {
    if (this.verticalLine) {
      this.verticalLine.attr('opacity', 0);
    }
  }

  dimensionsUpdated() {
    const width = d3.select(this.refs.container).node()
      .getBoundingClientRect().width;
    if (Math.abs(width - this.containerWidth) > containerResizeDelta) {
      this.containerWidth = width;
      this.forceUpdate();
    }
  }

  getGraphTooltipHtml(timeSeries, i) {
    const startTimeUtc = moment(timeSeries[i].startTime).format(dateFormat);
    const endTimeUtc = moment(timeSeries[i].endTime).format(dateFormat); 
    const totalLineValue = Object.entries(this.props.lineData[i])
      .reduce((acc, [key]) => acc + this.props.lineData[i][key], 0);
    const displayStackData = this.props.stackKeys.map(key => `
        <strong>
          <span class="tooltip-legend" style="color: ${this.state.colorRange(key)}">&#9632;</span>
          ${key}
        </strong> :  ${this.props.lineData[i][key]}
        <br />
      `
    );
    return `
      <div class="tooltip-header">
        <strong>Start Time: </strong>
        ${startTimeUtc}
        <br />
        <strong>End Time: </strong>
        ${endTimeUtc}
        <br /> 
        <strong>Total ${this.props.yLineLabel}: </strong>
        ${totalLineValue}
        <br />
      </div>
      <div class="tooltip-body">
        ${displayStackData.join('')}
      </div>
    `;
  }

  getLegendTooltipHtml(i) {
    const legendText = i === this.props.stackKeys.length ?
      this.props.lineKey :
      this.props.stackKeys[i];
    return `<span>${legendText}</span>`;
  }

  drawBars(svg, data, timeSeries, barWidth, tip, x, y) {
    let yValue;
    let heightValue;
    if (this.firstRender) {
      yValue = () => y(0);
      heightValue = () => 0;
    } else {
      yValue = d => y(d[1]);
      heightValue = d => y(d[0]) - y(d[1]);
    }
    const that = this;
    return svg.append('g')
      .selectAll('g')
      .data(d3.stack().keys(this.props.stackKeys)(data))
      .enter()
      .append('g')
      .attr('fill', d => this.state.colorRange(d.key))
      .selectAll('rect')
      .data(d => d)
      .enter()
      .append('rect')
      .attr('x', (d, i) => x(timeSeries[i].startTime))
      .attr('width', barWidth)
      .attr('y', yValue)
      .attr('height', heightValue)
      .on('mouseover', function(d, i) {
        d3.select(this)
          .transition()
          .duration('100')
          .style('opacity', .7);
        tip.transition()
          .duration(200)
          .style('opacity', 1);
        tip.html(that.getGraphTooltipHtml(timeSeries, i))
          .style('left', `${d3.event.pageX}px`)
          .style('top', `${d3.event.pageY - 28}px`);
      })
      .on('mouseout', function() {
        d3.select(this)
          .transition()
          .duration('100')
          .style('opacity', 1);
        tip.transition()
          .duration(500)
          .style('opacity', 0);
      });
  }

  transitionBars(bars, y) {
    bars.transition()
      .duration(TRANSITIONDURATION)
      .attr('y', d => y(d[1]))
      .attr('height', d => y(d[0]) - y(d[1]));
  }

  drawDots(svg, data, tip, x, y1, timeSeries, barWidth) {
    const dotRadius = d => {
      if (d > 0) {
        return DOTRADIUS;
      }
      return 0;
    };
    let cyValue;
    if (this.firstRender) {
      cyValue = () => y1(0);
    } else {
      cyValue = d => y1(d);
    }
    const dots = svg.selectAll('dot')
      .data(data)
      .enter()
      .append('circle')
      .style('fill', this.props.lineColor)
      .attr('r', dotRadius)
      .attr('cx', (d, i) => x(timeSeries[i].startTime) + barWidth / 2)
      .attr('cy', cyValue)
      .style('opacity', '0.7')
      .on('mouseover', (d, i) => {
        tip.transition()
          .duration(200)
          .style('opacity', 1);
        tip.html(this.getGraphTooltipHtml(timeSeries, i))
          .style('left', `${d3.event.pageX}px`)
          .style('top', `${d3.event.pageY - 28}px`);
      })
      .on('mouseout', () => {
        tip.transition()
          .duration(500)
          .style('opacity', 0);
      });

    return dots;
  }

  transitionDots(dots, timeSeries, barWidth, x, y1) {
    dots.transition()
      .duration(TRANSITIONDURATION)
      .attr('r', DOTRADIUS)
      .attr('cx', (d, i) => x(timeSeries[i].startTime) + barWidth / 2)
      .attr('cy', d => y1(d));
  }

  calculateLine(d3, timeSeries, barWidth, x) {
    return d3.line().x((d, i) => x(timeSeries[i].startTime) + barWidth / 2);
  }

  drawPath(svg, transactions, line) {
    const path = svg.append('path')
      .data([transactions])
      .attr('class', 'line')
      .style('stroke', this.props.lineColor)
      .attr('d', line)
      .style('opacity', '0.7');
    return path;
  }

  transitionPath(path, line) {
    path.transition()
      .duration(TRANSITIONDURATION)
      .attr('d', line);
  }

  getSummedBarValues(barData) {
    // Get data from data object and put into array indexed by each stacked bar.
    const stackedBarData = barData.map(tuple =>
      this.props.stackKeys.map(key => tuple[key])
    );
    // Sum bar values in each stacked bar
    const summedBarValues = stackedBarData.map(stackedBar =>
      stackedBar.reduce((acc, val) => acc + val)
    );
    return summedBarValues;
  }

  getSummedLineValues(data) {
    // Get data from data object and put into array indexed by each stacked bar.
    const lineData = data.map(tuple =>
      this.props.stackKeys.map(key => tuple[key])
    );
    // Sum line values in each stacked bar
    const summedLineValues = lineData.map(stackedBar =>
      stackedBar.reduce((acc, val) => acc + val)
    );
    return summedLineValues;
  }

/**
 * Calculates the width in pixels for y-axis ticks and their lablels. Part of fix for #185.
 * Used to determine where to place the axis description text so it doesn't overlap the tick labels.
 * @param {number} maxValue - The maximum value in a y-axis domain
 * @return {number} The expected maximum width in pixels for y-axis ticks and their labels
 */
  getYAxisOffset(maxValue) {
    const tickPixels = 9.5;
    const digitPixels = 7;
    const commaPixels = 3;
    const commaThreshold = 1000;
    const digitCount = Math.round(maxValue).toString().length;

    let commaCount = 0;
    while (maxValue > commaThreshold) {
      maxValue /= commaThreshold;
      commaCount += 1;
    }

    return (digitPixels * digitCount) + (commaPixels * commaCount) + tickPixels;
  }

/**
 * Calculates the needed minimum x value for the chart's SVG viewBox properties.
 * Part of fix for #185.
 * @param {number} yAxisOffset - The number of pixels taken up by the ticks + labels on the Y axis
 * @return {number} A negative minimum X value for chart's SVG viewBox
 */
  getViewBoxMinimumX(yAxisOffset) {
    const scalingFactor = 1.45;
    const expectedLowDurations = 0;
    const expectedLowTransactions = 1;
    const lowDurationsOffset = this.getYAxisOffset(expectedLowDurations);
    const lowTransactionsOffset = this.getYAxisOffset(expectedLowTransactions);

    // @FIXME: This formula was created by experimentation and is ugly and potentially brittle.
    return ((yAxisOffset / scalingFactor) - (lowTransactionsOffset * lowDurationsOffset / yAxisOffset)) * -1;
  }

  draw(data, props, prevProps) {
    const summedBarValues = this.getSummedBarValues(props.barData);
    // Get max stacked bar value out of all stacked bars
    const maxStackedBarValue = Math.max.apply(null, summedBarValues);

    const summedLineValues = this.getSummedLineValues(props.lineData);
    // Get max point value in line.
    const maxLineValue = Math.max.apply(null, summedLineValues);

    // Build y-axis meta
    const yAxisOffset = this.getYAxisOffset(maxStackedBarValue);
    const y1AxisOffset = this.getYAxisOffset(maxLineValue);
    const yAxisLabelWidth = 13;
    const yAxisLabelBuffer = 5;

    // Build time series meta
    const startTime = new Date(props.startTime);
    const endTime = new Date(props.endTime);
    const timeSeries = common.buildTimeRange(startTime, endTime, data.length);

    // Build Chart display meta
    const svgWidth = (d3.select(this.refs.container).node()
      .getBoundingClientRect().width) - 10;
    const svgHeight = 237;
    const margin = { top: 20, right: 20, bottom: 30, left: 40 };
    const width = svgWidth - margin.left - yAxisOffset - y1AxisOffset;
    const height = svgHeight - margin.top - margin.bottom;

    // Build Bar display meta
    const barPadding = 0.15;
    const barWidth = width / data.length - ((width / data.length) * barPadding);

    // Scale axis
    const x = d3.scaleTime().rangeRound([0, width]);
    const y = d3.scaleLinear().range([height, 0]);
    const y1 = d3.scaleLinear().range([height, 0]);
    this.x = x;

    // Calculate y-axis information
    const yAxisTickValues = common.generateYAxisTickValues(0,
      maxStackedBarValue, maximumYAxisTicks);
    const maxYAxisTickValue = yAxisTickValues[yAxisTickValues.length - 1];
    const yAxis = d3.axisLeft(y)
      .tickValues(yAxisTickValues)
      .tickFormat(d3.format(',.0f'));

    // Calculate the y1-axis information
    const y1AxisTickValues = common.generateYAxisTickValues(0, maxLineValue, maximumYAxisTicks);
    const maxY1AxisTickValue = y1AxisTickValues[y1AxisTickValues.length - 1];
    const y1Axis = d3.axisLeft(y1)
      .tickValues(y1AxisTickValues)
      .tickFormat(d3.format(',.0f'));

    // Scale the range of the data in the domains
    x.domain([moment(startTime), moment(endTime)]);
    y.domain([0, maxYAxisTickValue]);
    y1.domain([0, maxY1AxisTickValue]);

    const xAxisTicks = common.getXAxisTicks(width, startTime, endTime);

    const xAxis = d3.axisBottom()
      .scale(x)
      .ticks(xAxisTicks)
      .tickFormat(d3.timeFormat('%d %b -%H:%M'));

    const viewBoxMinimumX = this.getViewBoxMinimumX(yAxisOffset);

    // Get chart
    const svg = d3.select(this.refs.chart)
      .classed('svg-container', true)
      .append('svg')
      .attr('preserveAspectRatio', 'xMinYMin meet')
      .attr('viewBox', `${viewBoxMinimumX} 0 ${svgWidth} ${svgHeight}`)
      .attr('width', svgWidth)
      .attr('height', svgHeight)
      .attr('class', 'my-chart')
      .append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);

    let tip = d3.select('.tooltip');
    if (tip === undefined) {
      tip = d3.select('body').append('div')
        .attr('class', 'tooltip')
        .style('opacity', 0);
    }

    // add the Y gridlines
    svg.append('g')
      .attr('class', 'grid')
      .call(d3.axisLeft(y).ticks(5)
        .tickSize(-width)
        .tickFormat('')
      );

    svg.append('g')
      .attr('class', 'x axis')
      .attr('transform', `translate(0, ${height})`)
      .call(xAxis)
      .selectAll('text')
      .style('text-anchor', 'center');

    common.hideOverlappingXAxisTicks(this.refs.container);

    // Draw legend
    const legendContainer = d3.select(this.refs.legend);

    // Get legend
    const legend = legendContainer.selectAll('.legend')
      .data(this.state.legendData)
      .enter()
      .append('g')
      .attr('class', 'legend')
      .attr('transform', (d, i) => `translate(30, ${i * 19})`);

    // Add legend colored squares
    // Add tooltip showing the API name for the hovered-over legend square
    legend.append('rect')
      .attr('x', width - 18)
      .attr('width', 18)
      .attr('height', 18)
      .style('fill', (d, i) => this.state.legendData[i].color)
      .style('background', (d, i) => this.state.legendData[i].color)
      .on('mouseover', (d, i) => {
        tip.style('opacity', .95);
        tip.html(this.getLegendTooltipHtml(i))
          .style('left', `${d3.event.pageX}px`)
          .style('top', `${d3.event.pageY - 28}px`);
      })
      .on('mouseout', () => {
        tip.transition()
          .duration(500)
          .style('opacity', 0);
      });

    // Add legend texts
    legend.append('text')
      .attr('x', width + 5)
      .attr('y', 9)
      .attr('dy', '.35em')
      .style('text-anchor', 'start')
      .text((d, i) => this.state.legendData[i].name);

    // Check if the total width of all the legend items exceeds the width of the SVG container.
    // If it does, then remove the legend text and add an overflow-y value to the
    // legendContainer so that a scroll bar appears in that case that the legend
    // boxes total width still exceeds the SVG container width.
    let totalLegendWidth = 0;
    legend.each(function() {
      totalLegendWidth += d3.select(this).node()
        .getBoundingClientRect().width + 15;
    });
    // TODO: Get these values from elements themselves rather than hard code
    // Account for padding right of legendContainer
    totalLegendWidth += 100;
    if (totalLegendWidth > svgWidth) {
      legend.each(function() {
        d3.select(this)
          .style('margin-right', '7px')
          .select('text')
          .remove();
      });
    }

    // add y-axis
    svg.append('g')
      .style('pointer-events', 'none')
      .call(yAxis);

    // add y1-axis
    svg.append('g')
      .attr('class', 'y1 axis')
      .attr('transform', `translate(${width}, 0)`)
      .style('display', 'none')
      .call(y1Axis)
      .selectAll('text')
      .style('text-anchor', 'center');

    // add y-axis text
    svg.append('text')
      .attr('transform', 'rotate(-90)')
      .attr('y', 0 - yAxisOffset - yAxisLabelWidth - yAxisLabelBuffer)
      .attr('x', 0 - (height / 2))
      .attr('dy', '1em')
      .style('text-anchor', 'middle')
      .style('pointer-events', 'none')
      .text(this.props.lineKey);

    // add y1-axis text
    svg.append('text')
      .attr('transform', 'rotate(-90)')
      .attr('y', (width + y1AxisOffset))
      .attr('x', 0 - (height / 2))
      .attr('dy', '1em')
      .style('text-anchor', 'middle')
      .style('display', 'none')
      .text(`${this.props.yLineLabel}`);

    const prevLineData = prevProps.lineData === undefined ?
      props.lineData :
      prevProps.lineData;

    // Draw and transition line.
    const prevSummedLineValues = this.getSummedLineValues(prevLineData);
    const prevY1AxisTickValues = common.generateYAxisTickValues(0,
      d3.max(prevSummedLineValues), maximumYAxisTicks);
    const prevMaxY1AxisTickValue = prevY1AxisTickValues[prevY1AxisTickValues.length - 1];
    y1.domain([0, prevMaxY1AxisTickValue]);
    const line = this.calculateLine(d3, timeSeries, barWidth, x);
    let path;
    if (this.firstRender) {
      line.y(() => y1(0));
      path = this.drawPath(svg, summedLineValues, line);
    } else {
      line.y(d => y1(d));
      path = this.drawPath(svg, prevSummedLineValues, line);
    }
    y1.domain([0, maxY1AxisTickValue]);
    line.y(d => y1(d));
    path.data([summedLineValues]);
    this.transitionPath(path, line);

    // Draw and transition dots.
    const dots = this.drawDots(svg, prevSummedLineValues, tip, x, y1, timeSeries, barWidth);
    dots.data(summedLineValues);
    this.transitionDots(dots, timeSeries, barWidth, x, y1);

    // Crosshairs
    this.verticalLine = svg.append('line')
      .attr('opacity', 0)
      .attr('y1', 0)
      .attr('y2', height)
      .attr('stroke', 'black')
      .attr('stroke-width', 1)
      .attr('pointer-events', 'none');

    svg.on('mousemove', function () {
      const mouse = d3.mouse(this);
      const timeStamp = mouse.map(x.invert);
      emitter.emit(common.eventNames.moveCrosshair, timeStamp[0]);
    })
      .on('mouseout', () => {
        emitter.emit(common.eventNames.hideCrosshair);
      });

    this.firstRender = false;
  }

  render() {
    return (
      <div ref="container" className="chartholder">
        <div ref="chart" />
        <div ref="legend" className="legendContain" />
      </div>
    );
  }
}

LineChart.propTypes = {
  barData: React.PropTypes.array.isRequired,
  lineData: React.PropTypes.array.isRequired,
  lineColor: React.PropTypes.string.isRequired,
  colorRange: React.PropTypes.array.isRequired,
  width: React.PropTypes.number,
  height: React.PropTypes.number,
  margin: React.PropTypes.object,
  emitter: React.PropTypes.object,
  gettingData: React.PropTypes.bool,
  stackKeys: React.PropTypes.array.isRequired,
  lineKey: React.PropTypes.string,
  yBarLabel: React.PropTypes.string,
  yLineLabel: React.PropTypes.string,
};
