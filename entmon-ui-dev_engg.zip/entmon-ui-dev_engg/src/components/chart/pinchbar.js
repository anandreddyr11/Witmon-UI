import React, { PropTypes } from 'react';
import * as d3 from 'd3';
import moment from 'moment';
import Box from 'grommet/components/Box';
let self;

export default class pinchbar extends React.Component {
    constructor(props) {
      super(props);
      self = this;
      this.dimensionsUpdated = this.dimensionsUpdated.bind(this);
    }

    componentDidMount() {
        d3.select(this.refs.pinchbardiv).html('');
        this.timer(this.props.timeRange);
        window.addEventListener("resize", this.dimensionsUpdated);
    }

    componentWillReceiveProps(nextProps) {
        if (!nextProps.pinchbarSelected) {
            d3.select(this.refs.pinchbardiv).html('');
            this.timer(nextProps.timeRange);
        }
    }

    componentWillUnmount() {
      window.removeEventListener("resize", this.dimensionsUpdated);
    }

    dimensionsUpdated() {
      d3.select(this.refs.pinchbardiv).html('');
      this.timer(this.props.timeRange);
    }

    timer(timerdata) {
        let pinchdiv = document.getElementById('pinchbar-container');
        let pinchdivwidth = pinchdiv.getBoundingClientRect().width;
        let winwidth = pinchdivwidth - 25;
        let dateFormat = 'YYYY-MM-DD HH:mm:ss';
        let startTime1 = moment.utc().subtract(timerdata, "Hours").format(dateFormat);
        let endTime1 = moment.utc().format(dateFormat);
        let margin = { top: 40, right: 40, bottom: 40, left: 40 },
            width = winwidth,
            height = 50;
        let x = d3.scaleTime().rangeRound([0, width]);
        x.domain([moment(startTime1), moment(endTime1)]);
        let svg = d3.select(this.refs.pinchbardiv).append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height)
            .append("g")
            .attr("transform", "translate(" + 10 + "," + 10 + ")");

        let gradient = svg
            .append("linearGradient")
            .attr("y1", "0")
            .attr("y2", "0")
            .attr("x1", "0")
            .attr("x2", width)
            .attr("id", "gradient")
            .attr("gradientUnits", "userSpaceOnUse");

        //The color at x1/y1
        gradient
            .append("stop")
            .attr("offset", ".2")
            .attr("stop-color", "#4D4");

        //The color at x2/y2
        gradient
            .append("stop")
            .attr("offset", ".8")
            .attr("stop-color", "#5bf");

        svg
            .selectAll("rect")
            .data(d3.range(20))
            .enter()
            .append("rect")
            .attr("width", width)
            .attr("height", 19)
            .attr("fill", "url(#gradient)");

        let xAxis = svg.append("g")
            .attr("class", "axis axis--x")
            .attr("transform", "translate(0," + 19 + ")")
            .call(d3.axisBottom(x)
                .ticks(3)
                .tickPadding(0));

        xAxis.style("text-anchor", "end")
            .selectAll("text")
            .attr("x", 6);

        svg.append("g")
            .attr("class", "brush")
            .call(d3.brushX()
                .extent([
                    [0, 0],
                    [width, 19]
                ])
                .on("end", brushended));

        function brushended() {
            if (!d3.event.sourceEvent) return; // Only transition after input.
            if (!d3.event.selection) {
                let pinchstart = "";
                let pinchend = "";
                self.props.handlePinchbarChanged(pinchstart, pinchend, false);
                return;
            }
            let d0 = d3.event.selection.map(x.invert);
            /*   d1 = d0.map(d3.timeDay.round);*/
            let pinchstart = moment(d0[0]).format(dateFormat);
            let pinchend = moment(d0[1]).format(dateFormat);
            self.props.handlePinchbarChanged(pinchstart, pinchend, true);
        }
    }

    render() {
        return ( 
            <Box>
            <div ref="pinchbardiv"/>
            </Box>
        );
    }
}

pinchbar.propTypes = {
  timeRange: PropTypes.number,
  menuOptions: PropTypes.object
};

