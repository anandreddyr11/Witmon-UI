import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { buildQuery, processStatus } from 'grommet/utils/Rest';
import _ from 'lodash';
import moment from 'moment';
import StackedBar from './StackedBar';
import LineChart from './LineChart';
import Ops from './Ops';
import NoData from './NoData';
import ChartTileCustomization from './ChartTileCustomization';
import Box from 'grommet/components/Box';
import Heading from 'grommet/components/Heading';
import Button from 'grommet/components/Button';
import Menu from 'grommet/components/Menu';
import MenuIcon from 'grommet/components/icons/base/Menu';
import RefreshIcon from 'grommet/components/icons/base/Refresh';
import PaintIcon from 'grommet/components/icons/base/Paint';
import TrashIcon from 'grommet/components/icons/base/Trash';
import DocumentUpdateIcon from 'grommet/components/icons/base/DocumentUpdate';
import NotesIcon from 'grommet/components/icons/base/Notes';
import CloseIcon from 'grommet/components/icons/base/Close';
import Spinning from 'grommet/components/icons/Spinning';
import NotificationIcon from 'grommet/components/icons/base/Notification';
import Layer from 'grommet/components/Layer';
import Alert from 'grommet/components/icons/base/Alert';
import BarChart from 'grommet/components/icons/base/BarChart';

import {
  appErrorsSet,
} from '../../actions/app';
import {
  showWorkflowFormSet,
  workflowFormDataSet,
  isWorkflowFormUpdateSet,
} from '../../actions/dashboard';
import {
  menuAutoRefreshSet,
  menuCurrentPageSet,
} from '../../actions/menu';
import AlertCreation from '../home/AlertCreation';

const config = require(`../../../config.${process.env.NODE_ENV}.json`);
const common = require('../home/common');
let duplicateApiNames;

const defaultTransactionLineColor = common.colors.transactions.line;
const defaultWorkflowLineColor = common.colors.workflow.line;
const defaultTransactionBarColorRange = common.colors.transactions.barColorRange;
const defaultWorkflowBarColorRange = common.colors.workflow.barColorRange;

const transactionBarLabel = 'Duration (ms)';
const workflowBarLabel = 'Duration (ms)';
const exceptionBarLabel = 'Duration (ms)';

const transactionLineLabel = 'Transactions Count';
const workflowLineLabel = 'Transactions Count';
const exceptionLineLabel = 'Exceptions Count';
const alertLineLabel = 'Alerts Count';

const dateFormat = 'YYYY-MM-DD HH:mm:ss';

class ChartTile extends React.Component {
  constructor(props) {
    super(props);

    // Add event listeners
    this.handleResizeChartEvent = this.handleResizeChartEvent.bind(this);
    const resizeListener = this.props.emitter.addListener(common.eventNames.resizeChart,
      this.handleResizeChartEvent);
    this.handleResetDashboardTileLayout = this.handleResetDashboardTileLayout.bind(this);
    const resetDashboardTileLayoutListener = this.props.emitter.addListener(
      common.eventNames.resetDashboardTileLayout,
      this.handleResetDashboardTileLayout
    );

    let lineColor;
    let barColorRange;
    if (this.props.chartType === 'transactions' || this.props.chartType === 'alertHistory' || this.props.chartType === 'exception' || this.props.chartType === 'operations') {
      lineColor = this.getLocalStorageColor('lineColor') ||
        defaultTransactionLineColor;
      barColorRange = this.getLocalStorageColor('barColorRange') ||
        defaultTransactionBarColorRange;
    } else if (this.props.chartType === 'workflow') {
      lineColor = this.getLocalStorageColor('lineColor') ||
        defaultWorkflowLineColor;
      barColorRange = this.getLocalStorageColor('barColorRange') ||
        defaultWorkflowBarColorRange;
    }

    this.apiName = this.props.api_name;
    this.state = {
      chartType: this.props.chartType,
      title: this.props.title || this.props.api_name,
      lineColor,
      barColorRange,
      tileHeadingColor: this.getTileHeadingColor(),
      resizeListener,
      resetDashboardTileLayoutListener,
      showCustomization: false,
      verifyDelete: true,
    };

    this.nowRendring = undefined;
    this.preRendring = undefined;
    this.isAlertOpen = false;
    this.alertPreviousState = false;
    this.toggleCustomization = this.toggleCustomization.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleUpdateButton = this.handleUpdateButton.bind(this);
    this.handleChartDetailButton = this.handleChartDetailButton.bind(this);
    this.handleAlertHistoryButton = this.handleAlertHistoryButton.bind(this);
    this.getDuplicateApis = this.getDuplicateApis.bind(this);
    this.getData = this.getData.bind(this);
    this.setChartState = this.setChartState.bind(this);
    this.toggleVerifyDelete = this.toggleVerifyDelete.bind(this);
    this.handleRefreshButton = this.handleRefreshButton.bind(this);
    this.onClickAlert = this.onClickAlert.bind(this);
  }

  componentDidMount() {
    if (this.props.chartType !== 'operations')
      this.getDuplicateApis();
    this.getData();
  }

  componentDidUpdate(prevProps) {
    if (this.shouldRefreshData(prevProps, this.props)) {
      this.getData();
    }
  }

  componentWillUnmount() {
    this.state.resizeListener.remove();
    this.state.resetDashboardTileLayoutListener.remove();
  }

  getLocalStorageColor(stateName) {
    const key = `${this.props.userProfile.email}-chartTile-${this.props.chartType}-${this.props.id}-${stateName}`;
    const color = JSON.parse(localStorage.getItem(key));
    return color;
  }

  setChartState(state) {
    this.setState(state);
  }

  shouldRefreshData(props, nextProps) {
    return (
      props.startTime !== nextProps.startTime ||
      props.endTime !== nextProps.endTime ||
      props.api_name !== nextProps.api_name
    );
  }

  handleResetDashboardTileLayout(dashboardTileId) {
    if (this.props.dashboardTileId === dashboardTileId) {
      this.forceUpdate();
    }
  }

  handleResizeChartEvent(id) {
    if ((this.props.chartType === 'transactions' || this.props.chartType === 'alertHistory' || this.props.chartType === 'exception') &&
      id === `${this.props.appinstanceid}${this.props.chartIndex}`) {
      this.forceUpdate();
    } else if (this.props.chartType === 'workflow' && id === this.props.id) {
      this.forceUpdate();
    }
  }

  getDuplicateApis() {
    duplicateApiNames = (this.props.dashboardDuplicateApis)
      .map(e => e.api_name);
  }

  getData(startTime = this.props.startTime, endTime = this.props.endTime) {
    const props = this.props;
    this.setState({ gettingData: true });
    let uri;
    if (props.chartType === 'alertHistory' || this.nowRendring === 'alertHistory') {
      uri = `${config.serverUrl}/get-notification-history-chart-data?app_name=${props.app_name}&api_name=${props.api_name}&start_time=${startTime}&end_time=${endTime}&application_instance_id=${props.appinstanceid}&user_email_id=${props.userProfile.email}`;
      uri = encodeURI(uri);
    } else if (props.chartType === 'transactions') {
      uri = `${config.serverUrl}/get-transaction-chart-data?app_name=${props.app_name}&api_name=${props.api_name}&start_time=${startTime}&end_time=${endTime}&user_action=${props.user_action}&application_instance_id=${props.appinstanceid}`;
      if (props.userAction && props.userAction === 'subscriber' || props.user_action === 'subscriber') {
        if (duplicateApiNames.includes(this.props.api_name)) {
          const duplicateValueConsumerId = (this.props.dashboardDuplicateApis)
            .filter(e => e.api_name === this.props.api_name);
          uri = `${uri}&application_consumer_id=${duplicateValueConsumerId[0].appconsumerid}`;
        } else {
          uri = `${uri}&application_consumer_id=${props.appconsumerid}`;
        }
      }
      uri = encodeURI(uri);
    } else if (props.chartType === 'exception') {
      uri = `${config.serverUrl}/get-exception-chart-data?app_name=${props.app_name}&application_consumer_id=${props.appconsumerid}&user_action=${props.user_action}&application_instance_id=${props.appinstanceid}&start_time=${props.startTime}&end_time=${props.endTime}`;
      uri = encodeURI(uri);
    } else if (props.chartType === 'operations') {
      uri = `${config.serverUrl}/get-ops-data?app_name=${props.app_name}&application_instance_id=${props.appinstanceid}&start_time=${props.startTime}&end_time=${props.endTime}`;
      uri = encodeURI(uri);
    } else if (props.chartType === 'operations-node') {
      const host = config.serverUrl;
      const endpoint = '/get-ops-data-for-node';
      const query = buildQuery({
        app_name: props.applicationName,
        application_instance_id: props.appinstanceid,
        node_instance_id: props.operationsNode,
        start_time: props.startTime,
        end_time: props.endTime,
      });
      uri = `${host}${endpoint}${query}`;
    } else if (props.chartType === 'workflow') {
      const host = config.serverUrl;
      const endpoint = '/get-workflow-chart-data';
      const query = buildQuery({
        workflow_id: props.workflow.workflow_id,
        start_time: startTime,
        end_time: endTime,
        user_email: props.userProfile.email,
      });
      uri = `${host}${endpoint}${query}`;
    }
    fetch(uri)
      .then(processStatus)
      .then(response => {
        response = response.json();
        return response;
      })
      .then(data => {
        let title = (this.props.title || this.props.api_name);
        if (props.chartType === 'alertHistory' || this.nowRendring === 'alertHistory') {
          data = data.map(obj => {
            return {
              start_time: obj.startTime,
              end_time: obj.endTime,
              alertCount: obj.alertCount,
            };
          });
          title = `${this.props.title || this.props.api_name} - Alert History`;
        }
        if (this.nowRendring === 'alertHistory') {
          return this.setState({
            data, gettingData: false,
            title: `${this.props.title || this.props.api_name} - Alert History`,
          });
        }
        return this.setState({ data, gettingData: false, title });
      })
      .catch(error => this.setState({ error, gettingData: false }));
  }

  getTimesForCustomMenu(menuCustomStartTime, timeRange) {
    const startTime = moment(menuCustomStartTime).format(dateFormat);
    const endTime = moment(menuCustomStartTime).add(timeRange, 'Hours')
      .format(dateFormat);
    return { startTime, endTime };
  }

  getTimes(timeRange) {
    const endTime = moment.utc().format(dateFormat);
    const startTime = moment.utc().subtract(timeRange, 'Hours')
      .format(dateFormat);
    return { startTime, endTime };
  }

  filterProperties(key, value) {
    // Filtering out emitter property
    if (key === 'emitter') {
      return undefined;
    }
    return value;
  }

  handleChartDetailButton() {
    this.props.menuCurrentPageSet('Chart Details');
    const json = JSON.parse(JSON.stringify(this.props, this.filterProperties));
    if (this.nowRendring === 'alertHistory') {
      json.chartType = 'alertHistory';
    }
    json.isInDetailPage = true;
    sessionStorage.setItem('currentDetail', JSON.stringify(json));
    window.location = '/#/chartDetail';
  }

  handleDelete() {
    let endpoint;
    const queryParams = { workflow_id: this.props.workflow.workflow_id };
    if (this.props.workflow.user_role === 'admin') {
      endpoint = '/workflow';
    } else {
      queryParams.user_email = this.props.userProfile.email;
      endpoint = '/workflow-user-mapping';
    }
    const uri = `${config.serverUrl}${endpoint}${buildQuery(queryParams)}`;
    fetch(encodeURI(uri), { method: 'DELETE' })
      .then(() => window.location.reload(true))
      .catch(error => {
        const appErrors = this.props.appErrors.concat([`Error deleting Workflow (${error.toString()})`]);
        this.props.appErrorsSet(appErrors);
      });
  }

  handleUpdateButton() {
    this.props.showWorkflowFormSet(true);
    this.props.isWorkflowFormUpdateSet(true);
    this.props.workflowFormDataSet(this.props.workflow);
  }

  onClickAlert(e) {
    this.isAlertOpen = true;
    this.alertPreviousState = this.props.menuAutoRefresh;
    this.props.menuAutoRefreshSet(false);
    e.preventDefault();
    this.setState({
      showAddAlertModal: true,
    });
  }

  getAddAlertModalRender() {
    const self = this;
    const props = this.props;
    let workflowName = '';
    if (this.state.showAddAlertModal) {
      let alertCategory;
      if (props.chartType === 'transactions' || props.chartType === 'alertHistory' || props.chartType === 'exception') {
        alertCategory = 'Application';
      } else if (props.chartType === 'workflow') {
        alertCategory = 'Workflow';
        workflowName = props.workflow.workflow_name;
      }
      return (
        <Layer dataSort={true} filter={{ type: 'TextFilter' }} className="layer-style" closer={true} onClose={function toggleShowAddAlertModal() {
          self.setState({ showAddAlertModal: false });
        }}>
          <AlertCreation isFromChart={true} appName={props.app_name} applicationApiName={props.api_name}
            applicationInstanceId={props.appinstanceid} userEmail={props.userProfile.email} userAction={props.user_action}
            alertCategory={alertCategory} workflowName={workflowName} />
        </Layer>
      );
    }
    if (this.isAlertOpen === true) {
      this.isAlertOpen = false;
      this.props.menuAutoRefreshSet(this.alertPreviousState);
    }
  }

  refresh() {
    let times;
    if (this.props.menuOptions.menuCustomStartTime) {
      times = this.getTimesForCustomMenu(this.props.menuOptions.menuCustomStartTime,
        this.props.menuOptions.menuTimeRange);
    } else {
      times = this.getTimes(this.props.menuOptions.menuTimeRange);
    }
    this.getData(times.startTime, times.endTime);
  }

  handleRefreshButton() {
    this.refresh();
  }

  toggleCustomization() {
    this.setState({ showCustomization: !this.state.showCustomization });
  }

  toggleVerifyDelete() {
    this.setState({ verifyDelete: !this.state.verifyDelete });
  }

  getTileHeadingColor() {
    const customHeaderColor = this.getLocalStorageColor('tileHeadingColor');
    const isHeaderCustomized = customHeaderColor !== null;
    if (isHeaderCustomized) {
      return customHeaderColor;
    } else {
      if (this.props.menuTheme === 'Dark Theme') return '#444';
      else return common.colors.tileHeader;
    }
  }

  getNoDataRender() {
    this.preRendring = this.nowRendring;
    return <NoData {...this.props} gettingData={this.state.gettingData} />;
  }

  getTransactionChartRender() {
    // Format transactions data for line.

    if ((this.nowRendring === 'alertHistory' && this.state.gettingData === false) || this.preRendring === 'alertHistory' || this.props.chartType === 'alertHistory') {
      const stackKeys1 = ['Alerts Count'];
      const lineKey1 = 'Alerts Count';
      const lineData1 = this.state.data.map(datum => ({ 'Alerts Count': datum.alertCount }));
      const barData1 = this.state.data.map(datum => ({ 'Alerts Count': datum.alertCount }));
      this.preRendring = this.nowRendring;
      return (
        <LineChart {...this.props} gettingData={this.state.gettingData}
          stackKeys={stackKeys1} lineKey={lineKey1} colorRange={this.state.barColorRange}
          barData={barData1} lineData={lineData1} lineColor={this.state.lineColor}
          yLineLabel={alertLineLabel} />
         );
    } else {
      const stackKeys = ['duration'];
      const lineKey = 'transactions';
      const lineData = this.state.data.map(datum => ({ duration: datum.transactions }));
      const barData = this.state.data.map(datum => ({ duration: datum.duration }));
      this.preRendring = this.nowRendring;
      if (this.props.chartType === 'exception') {
        return (
          <StackedBar {...this.props} gettingData={this.state.gettingData}
            stackKeys={stackKeys} lineKey={lineKey} colorRange={this.state.barColorRange}
            barData={barData} lineData={lineData} lineColor={this.state.lineColor}
            yBarLabel={exceptionBarLabel} yLineLabel={exceptionLineLabel} />
           );
      } else {
        return (
          <StackedBar {...this.props} gettingData={this.state.gettingData}
            stackKeys={stackKeys} lineKey={lineKey} colorRange={this.state.barColorRange}
            barData={barData} lineData={lineData} lineColor={this.state.lineColor}
            yBarLabel={transactionBarLabel} yLineLabel={transactionLineLabel} />
           );
      }
    }
  }

  getOpsChartRender() {
    return (
      <Ops {...this.props}
        data={this.state.data}
        gettingData={this.state.gettingData} />
    );
  }

  getWorkflowChartRender() {
    const data = _.cloneDeep(this.state.data);
    common.sortArrayOfObjectsByKey(data.apis, 'api_name');
    const stackKeys = data.apis.map(api => api.api_name);
    // Format durations data for stacked bars.
    const durationsArrays = data.apis.map(api =>
      api.data.map(data => data.duration));
    const barData = data.apis[0].data.map((timeSlice, index) => {
      const timeSliceBarData = {};
      stackKeys.forEach((key, keyIndex) => {
        timeSliceBarData[key] = durationsArrays[keyIndex][index];
      });
      return timeSliceBarData;
    });
    // Format transactions data for line.
    const transactionsArrays = data.apis.map(api =>
      api.data.map(data => data.transactions));
    const lineData = data.apis[0].data.map((timeSlice, index) => {
      const timeSliceLineData = {};
      stackKeys.forEach((key, keyIndex) => {
        timeSliceLineData[key] = transactionsArrays[keyIndex][index];
      });
      return timeSliceLineData;
    });
    return (
      <StackedBar {...this.props} stackKeys={stackKeys}
        barData={barData} gettingData={this.state.gettingData}
        lineKey={'transactions'} lineData={lineData} lineColor={this.state.lineColor}
        colorRange={this.state.barColorRange} yBarLabel={workflowBarLabel}
        yLineLabel={workflowLineLabel} />
    );
  }

  getChartRender() {
    if (this.state.data === undefined || this.state.data.length === 0) {
      return this.getNoDataRender();
    } else if (this.state.chartType === 'alertHistory' || this.props.chartType === 'transactions' || this.props.chartType === 'exception') {
      return this.getTransactionChartRender();
    } else if (this.props.chartType === 'operations') {
      return this.getOpsChartRender();
    } else if (this.props.chartType === 'operations-node') {
      return this.getOpsChartRender();
    } else if (this.props.chartType === 'workflow') {
      return this.getWorkflowChartRender();
    }
  }

  getBodyRender() {
    if (!this.state.verifyDelete) {
      return (
        <div className="charttile-body verify-delete">
          <Heading tag="h3" style={{ borderBottom: '0px' }}>Are you sure?</Heading>
          <div>
            <Button label={'Delete'} plain={true} onClick={this.handleDelete}
              icon={<TrashIcon size="small" />} />
            <Button icon={<CloseIcon size="small" />} label={'Cancel'} plain={true}
              onClick={this.toggleVerifyDelete} />
          </div>
        </div>
      );
    } else if (this.state.showCustomization) {
      return (
        <ChartTileCustomization setChartState={this.setChartState} chartState={this.state}
          {...this.props} />
      );
    } else {
      return this.getChartRender();
    }
  }

  getDeleteButtonRender() {
    if (this.props.chartType === 'workflow') {
      return (
        <Button label={'Delete Workflow'} plain={true} onClick={this.toggleVerifyDelete}
          icon={<TrashIcon size="small" />} />
      );
    }
  }

  getUpdateButtonRender() {
    if (this.props.chartType === 'workflow') {
      return (
        <Button label={'Update Workflow'} plain={true} onClick={this.handleUpdateButton}
          icon={<DocumentUpdateIcon size="small" />} />
      );
    }
  }

  getDrilldownButtonRender() {
    if (this.props.showDrilldownLink === false) return;
    const OPERATIONS = 'operations';
    return (
      <Box style = {{ visibility: this.props.chartType === OPERATIONS ? 'hidden' : 'visible' }} >
        <Button icon={<NotesIcon size="small" />} className="charttile-heading-buttons-chartdetails"
          onClick={this.handleChartDetailButton} />
      </Box>
    );
  }

  getAlertButtonRender() {
    if (this.props.showAlertButton === false) return;
    return (
      <Box>
        <Button icon={<NotificationIcon size="small" />}
          label="Alerts" plain={true} onClick={this.onClickAlert} />
      </Box>
    );
  }


  handleAlertHistoryButton() {
    if (this.props.isInDetailPage === true) {
      let json;
      if (this.props.chartType === 'alertHistory') {
        this.props.menuCurrentPageSet('Chart Details');
        json = JSON.parse(JSON.stringify(this.props, this.filterProperties));
        json.chartType = 'transactions';
      } else {
        this.props.menuCurrentPageSet('Chart Details');
        json = JSON.parse(JSON.stringify(this.props, this.filterProperties));
        json.chartType = 'alertHistory';
      }
      json.isInDetailPage = true;
      sessionStorage.setItem('currentDetail', JSON.stringify(json));
      window.location = '/#/chartDetail';
      window.location.reload();
    } else if (this.nowRendring === 'alertHistory') {
      this.nowRendring = undefined;
    } else {
      this.nowRendring = 'alertHistory';
    }
    this.refresh();
  }

  getAlertHistoryButtonRender() {
    if (this.props.showAlertHistoryButton === false || this.props.chartType === 'workflow') return;
    let marginRight = '-10px';
    if (this.props.isInDetailPage === true) {
      marginRight = '0';
    }
    if (this.nowRendring === 'alertHistory' || this.props.chartType === 'alertHistory') {
      return (
        <div style={{ marginRight }}>
          <Button icon={<BarChart size="small" />} className="charttile-heading-buttons-chartdetails"
            onClick={this.handleAlertHistoryButton} />
        </div>
      );
    } else {
      return (
        <div style={{ marginRight }}>
          <Button icon={<Alert size="small" />} className="charttile-heading-buttons-chartdetails"
             onClick={this.handleAlertHistoryButton} />
        </div>
      );
    }
  }

  getHeadingMenuRender() {
    if (this.state.gettingData) {
      return (
        <Box direction="row" full="horizontal" justify="end" className="charttile-heading-buttons">
          <Box pad={'small'}>
            <Spinning size="small" />
          </Box>
        </Box>
      );
    } else {
      return (
        <Box direction="row" full="horizontal" justify="end" className="charttile-heading-buttons">
          {this.getAlertHistoryButtonRender()}
          {this.getDrilldownButtonRender()}
          {this.getAddAlertModalRender()}
          <Menu icon={<MenuIcon size="small" />}>
            {this.getAlertButtonRender()}
            <Button icon={<RefreshIcon size="small" />}
              label="Refresh" plain={true} onClick={this.handleRefreshButton} />
            <Button icon={<PaintIcon size="small" />} label="Customize" plain={true}
              onClick={this.toggleCustomization} />
            {this.getUpdateButtonRender()}
            {this.getDeleteButtonRender()}
          </Menu>
        </Box>
      );
    }
  }

  getHeadingRender() {
    return (
      <Box direction="row" className="charttile-heading" align="center" responsive={false}
        style={{ backgroundColor: this.getTileHeadingColor() }}>
        <Box direction="row" full="horizontal" margin={{ left: 'medium' }}
          className="charttile-heading-title" responsive={false}>
          <Heading tag="h3">
            {this.state.title}
          </Heading>
        </Box>
        {this.getHeadingMenuRender()}
      </Box>
    );
  }

  render() {
    return (
      <Box align="start" colorIndex="light-1" className="chart-box charttile">
        {this.getHeadingRender()}
        {this.getBodyRender()}
      </Box>
    );
  }
}

ChartTile.propTypes = {
  operationsNode: React.PropTypes.string,
  appErrors: React.PropTypes.array.isRequired,
  appErrorsSet: React.PropTypes.func.isRequired,
  dashboardTileId: React.PropTypes.string.isRequired,
  menuCurrentPageSet: React.PropTypes.func.isRequired,
  menuAutoRefreshSet: PropTypes.func.isRequired,
  menuTheme: React.PropTypes.string.isRequired,
  app_name: React.PropTypes.string,
  api_name: React.PropTypes.string,
  user_action: React.PropTypes.string,
  startTime: React.PropTypes.string,
  endTime: React.PropTypes.string,
  api_creator_group: React.PropTypes.string,
  api_consumer_group: React.PropTypes.string,
  userProfile: PropTypes.object.isRequired,
  menuOptions: PropTypes.object.isRequired,
  menuRefreshNow: PropTypes.object.isRequired,
  chartdata: PropTypes.array.isRequired,
  appinstanceid: React.PropTypes.string,
  appconsumerid: React.PropTypes.string,
  chartIndex: React.PropTypes.number.isRequired,
  emitter: React.PropTypes.object,
  chartType: React.PropTypes.string.isRequired,
  title: React.PropTypes.string,
  id: React.PropTypes.string,
  workflow: React.PropTypes.object,
  dashboardDuplicateApis: React.PropTypes.array,
  showWorkflowFormSet: React.PropTypes.func.isRequired,
  workflowFormDataSet: React.PropTypes.func.isRequired,
  isWorkflowFormUpdateSet: React.PropTypes.func.isRequired,
  isWorkflowFormUpdate: React.PropTypes.bool.isRequired,
  showDrilldownLink: React.PropTypes.bool,
  showAlertButton: React.PropTypes.bool,
};

const mapStateToProps = state => ({
  appErrors: state.appErrors,
  menuTheme: state.menuTheme,
  userProfile: state.userProfile,
  menuOptions: state.menuOptions,
  menuRefreshNow: state.menuRefreshNow,
  menuAutoRefresh: state.menuAutoRefresh,
  dashboardDuplicateApis: state.dashboardDuplicateApis,
  isWorkflowFormUpdate: state.isWorkflowFormUpdate,
});

const mapDispatchToProps = dispatch => ({
  appErrorsSet: appErrors => dispatch(appErrorsSet(appErrors)),
  menuCurrentPageSet: page => dispatch(menuCurrentPageSet(page)),
  menuAutoRefreshSet: bool => dispatch(menuAutoRefreshSet(bool)),
  showWorkflowFormSet: bool => dispatch(showWorkflowFormSet(bool)),
  workflowFormDataSet: obj => dispatch(workflowFormDataSet(obj)),
  isWorkflowFormUpdateSet: bool => dispatch(isWorkflowFormUpdateSet(bool)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ChartTile);