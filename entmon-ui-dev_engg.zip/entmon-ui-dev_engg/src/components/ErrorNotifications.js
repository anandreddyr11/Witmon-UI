import React from 'react';
import { connect } from 'react-redux';
import Toast from 'grommet/components/Toast';

import { appErrorsSet } from '../actions/app';

class ErrorNotifications extends React.PureComponent {
  render() {
    const errorRenders = this.props.appErrors.map((appError, index) =>
      <Toast key={index} status={'critical'}>
        {appError}
      </Toast>
    );
    return (
      <div>
        {errorRenders}
      </div>
    );
  }
}

ErrorNotifications.propTypes = {
  appErrors: React.PropTypes.array.isRequired,
  appErrorsSet: React.PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  appErrors: state.appErrors,
});

const mapDispatchToProps = dispatch => ({
  appErrorsSet: appErrors => dispatch(appErrorsSet(appErrors)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ErrorNotifications);
