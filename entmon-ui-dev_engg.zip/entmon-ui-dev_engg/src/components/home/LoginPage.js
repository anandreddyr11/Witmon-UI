import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { processLogin } from '../../actions/user';

import LoginForm from 'grommet/components/LoginForm';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import LoginIcon from 'grommet/components/icons/base/Login';
import Notification from 'grommet/components/Notification';
import Heading from 'grommet/components/Heading';
import Accordion from 'grommet/components/Accordion';
import AccordionPanel from 'grommet/components/AccordionPanel';

const Config = require('Config');

const common = require('../home/common.js');
const defaultRedirectLocation = '/TxnDashboard'; // Where to redirect if login successful
let redirectLocation = defaultRedirectLocation;

class LoginPage extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.state = {
      loginIsProcessing: false,
      loginError: [],
    };

    this._onSubmit = this._onSubmit.bind(this);
    this.sessionLogin = this.sessionLogin.bind(this);
    this.processAuth = this.processAuth.bind(this);
    this.loginRedirect = this.loginRedirect.bind(this);
  }
  componentDidMount() {
    const decodedLocationHash = decodeURIComponent(location.hash);
    // The match group is (\/[^?]+)
    const regularExpression = /\?parent=.+\/#(\/[^?]+)\?_k=/;
    const regexResult = decodedLocationHash.match(regularExpression);

    // Not sure if the loginComplete check here is really necessary
    if (regexResult !== null && regexResult[1].indexOf('/loginComplete') === -1) {
      redirectLocation = regexResult[1];
    } else {
      redirectLocation = defaultRedirectLocation;
    }

    // this is for the scenario when somebody visits the login page after already logging in
    this.loginRedirect();
  }
  componentWillReceiveProps() {
    this.loginRedirect();
  }

  loginRedirect() {
    if (this.props.userProfile.loggedin) {
      this.context.router.push(redirectLocation);
    }
  }

  _onSubmit(fields) {
    this.sessionLogin(fields.username, fields.password); // LDAP + Authorization
  }

  sessionLogin(username, password) { // authenticate LDAP
    if (Config.ldapAuthPB && password !== '') {
      this.setState({ loginError: ['Authentication is disabled. Password must be empty'] });
      return;
    }
    if (!Config.ldapAuthPB && password === '') {
      this.setState({ loginError: ['Password is mandatory'] });
      return;
    }
    if (!common.isEmail(username)) {
      this.setState({ loginError: ['Email format error'] });
      return;
    }

    const ldapAuthenticationRequestOptions = {
      dataType: 'json',
      contentType: 'application/json; charset=utf-8',
      data: JSON.stringify({ username, password }),
      url: `${Config.serverUrl}/post-ldap-authentication`,
      type: 'POST',
    };

    this.setState({
      loginIsProcessing: true,
      loginError: [],
    });

    common.makeAjaxCall(ldapAuthenticationRequestOptions)
      .then(this.processAuth)
      .catch(err => {
        this.setState({
          loginError: [
            'Error with authentication',
            err ? JSON.parse(err).message : 'No further information available',
          ],
          loginIsProcessing: false,
        });
      });
  }

  /**
   * Process returned by LDAP service call
   * @param {JSON from LDAP Auth} response
   */
  processAuth(response) {
    this.setState({ loginIsProcessing: false });
    const respJSON = JSON.parse(response);
    if (respJSON.statusCode === 200) {
      this.props.processLogin(respJSON.token);
    } else {
      this.setState({
        loginError: [
          'Authentication error',
          respJSON.statusCode,
        ],
      });
    }
  }

  handleDigitalBadgeLogin() {
    const urlAfterLoginSuccess = encodeURIComponent(`${location.protocol}//${location.host}/#${redirectLocation}`);
    window.location = `${Config.serverUrl}/login?parent=${urlAfterLoginSuccess}`;
  }

  getHpeLogo() {
    const html = document.getElementsByTagName('html')[0];
    const isDarkTheme = html.classList.contains('dark-theme');

    let logo;

    if (isDarkTheme) {
      logo = require('../../images/hpesm_pri_grn_rev_rgb.svg');
    } else {
      logo = require('../../images/hpesm_pri_grn_pos_rgb.svg');
    }

    return logo;
  }

  getLoginErrors() {
    if (this.state.loginError.length > 0) {
      return this.state.loginError;
    }

    return [this.props.loginErrored.errorText];
  }

  getLoggingInMessage() {
    const isLoginProcessing = (this.props.loginProcessing || this.state.loginIsProcessing);
    if (!this.props.userProfile.loggedin && isLoginProcessing) {
      return (
        <Notification status="disabled"
          message="Please wait while login is processing..."
          timestamp={new Date()} />
      );
    }
  }

  render() {
    if (this.props.userProfile.loggedin) {
      return (
        <div>
          <Notification status="disabled"
            message="You will be redirected shortly. If seeing this message for a long time, please use links below to navigate"
            timestamp={new Date()} /> <br />
          <a href={redirectLocation}>Redirect</a>&nbsp;
          <a href="/">Home</a>
        </div>
      );
    }
    return (
      <Box>
        <Box full="horizontal" direction="row">
          <Box pad="small" alignSelf="start" />
          <Box pad="large" full="horizontal" alignSelf="start">
            <Heading strong={true}>
              Choose a log on option:
            </Heading>
          </Box>
          <Box pad="large" alignSelf="end" justify="end" full="horizontal">
            <img className="hpe-logo" src={this.getHpeLogo()} height="65" />
          </Box>
        </Box>
        <Box direction="column" justify="start">
          <Box full="horizontal" direction="row">
            <Box pad="large" />
            <Box alignSelf="start">
              <Heading style={{ paddingLeft: '14px' }}>Use your DigitalBadge</Heading>
              <Box pad="medium">
                <Button icon={<LoginIcon />}
                  label="Log on with a DigitalBadge"
                  onClick={this.handleDigitalBadgeLogin}
                  primary={true} />
              </Box>
            </Box>
          </Box>
          <Box full="horizontal" direction="row">
            <Box pad="large" />
            <Accordion>
              <AccordionPanel heading={<Heading>Use your email address</Heading>}>
                <LoginForm errors={this.getLoginErrors()}
                  onSubmit={this._onSubmit}
                  rememberMe={false}
                  align="start" />
              </AccordionPanel>
            </Accordion>
          </Box>
        </Box>
        <Box>
          {this.getLoggingInMessage()}
        </Box>
        <Box pad="small" full="false" alignSelf="end" align="end">
          <Heading strong={true} tag="h5">
            <span className="buildnumberdisplay">{ Config.buildNumber } </span>
          </Heading>
        </Box>
      </Box>
    );
  }
}

LoginPage.propTypes = {
  processLogin: PropTypes.func.isRequired,
  userProfile: PropTypes.object.isRequired,
  loginErrored: PropTypes.object,
  loginProcessing: PropTypes.bool.isRequired,
};

LoginPage.contextTypes = {
  router: React.PropTypes.object.isRequired,
};

const mapStateToProps = state => ({
  userProfile: state.userProfile,
  loginErrored: state.loginErrored,
  loginProcessing: state.loginIsProcessing,
});

const mapDispatchToProps = dispatch => ({
  processLogin: token => dispatch(processLogin(token)),
});

export default connect(mapStateToProps, mapDispatchToProps)(LoginPage);
