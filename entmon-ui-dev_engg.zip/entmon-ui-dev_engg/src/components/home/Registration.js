import React from 'react';
import Section from 'grommet/components/Section';
import Form from 'grommet/components/Form';
import Heading from 'grommet/components/Heading';
import Header from 'grommet/components/Header';
import FormField from 'grommet/components/FormField';
import Button from 'grommet/components/Button';
import { browserHistory } from 'react-router';
import { menuShowMenuSet } from '../../actions/menu';
import { connect } from 'react-redux';
import { processStatus } from "grommet/utils/Rest";
import Label from 'grommet/components/Label';
import Toast from 'grommet/components/Toast';
import Status from 'grommet/components/icons/Status';
import Box from 'grommet/components/Box';
let config = require('Config');
let common = require('../home/common.js');

class Registration extends React.Component {
  constructor(props) {
    super(props);
    //Change the page title
    document.title = 'Registration';
    this.state = {
      eprid: '',
      app_name: '',
      application_instance_id: '',
      user_email: '',
      user_action: 'creator',
      registration_page_required: false,
      invalidEmailError:  '',
      msg: '',
      errorMsg: '',
      successNotification: 'success-notification-invisible',
      showSuccessMsg: false,
      formContent: ''
    };
    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  componentWillMount(){
    // Checking whether application is registered
    let eprId = this.props.location.query.EPRID;
    let appName = this.props.location.query.AppName;
    let appInstanceId = this.props.location.query.ApplicationInstanceID;
    this.setState({msg:<Label className="tCenter"><b>Please wait.. <br/>we are checking whether the application is already registered</b></Label>});
    const queryParam = `eprid=${eprId}&app_name=${appName}&application_instance_id=${appInstanceId}&user_action=creator`;
    fetch(`${config.serverUrl}/get-is-application-registered?${queryParam}`, { method: 'get' })
      .then(processStatus)
      .then(response => response.json())
      .then(
        res => {//Redirecting to login page if application is registered
          if(res.isApplicationRegistered){
            browserHistory.push('#/');
            window.location.reload();
          }
          else{
            this.setState({registration_page_required:true});
          }
        }
      )
      .catch(() => this.setState({errorMsg: 'We cannot connect to server at this time. Please try again later!'}));
  }

  componentDidMount(){
    this.props.menuShowMenuSet(false);
  }

  componentWillUnmount(){
     this.props.menuShowMenuSet(true);
     document.title = 'EntMon Dashboard';
  }

  handleInputChange(event) {
    const TARGET = event.target;
    const VALUE = TARGET.value;
    const NAME = TARGET.name;

    if(NAME === 'user_email'){
      this.setState({invalidEmailError:''});
    }
    this.setState({
      [NAME]: VALUE
    });
  }

  handleSubmit(event){
    event.preventDefault();
    let invalidEmailError = false;
    let hasErrored = false;
    let userEmail = this.state.user_email;
    if(!userEmail){
      invalidEmailError = 'Owner email address cannot be empty!';
      hasErrored = true;
    }
    else if(!common.isEmail(userEmail)){
      invalidEmailError = `${userEmail} is not a valid email.`;
      hasErrored = true;
    }
    this.setState({invalidEmailError});
    if (!hasErrored) {
      this.sendFormData();
    }
  }

  sendFormData() {
    // Prepare form parameters for submitting
    let eprId = this.props.location.query.EPRID;
    let appName = this.props.location.query.AppName;
    let appInstanceId = this.props.location.query.ApplicationInstanceID;
    let data = new FormData();
    data.append('eprid', eprId);
    data.append('app_name', appName);
    data.append('application_instance_id', appInstanceId);
    data.append('user_email', this.state.user_email);
    data.append('user_action', 'creator');

    let request = new Request(`${config.serverUrl}/post-api-registration-form-data`, {
      method: 'post',
      body: data
    });
    fetch(request)
      .then(processStatus)
      .then(response => response.text())
      .then(
        res => {
          if (res == 'Record inserted successfully'){
            this.setState({
              showSuccessMsg: true,
              successNotification: 'success-notification',
              formContent: 'disabled-content'
            });
            setTimeout(()=>{
                  browserHistory.push('#/');
                  window.location.reload();
                },4000);
          }
          else{
            this.setState({errorMsg: 'Error in registration process'});
          }
        }
      )
      .catch(() => this.setState({errorMsg: 'We cannot connect to server at this time. Please try again later!'}));
  }

  closeErrorNotifications(){
    this.setState({errorMsg: ''});
  }

  render() {
    let errorNotifications;
    let successMsg;
    if(this.state.errorMsg){
      errorNotifications = (
        <div className="email-error-toast">
          <Toast onClose={this.closeErrorNotifications.bind(this)} >
            <Status value="critical" size="medium"/>
            <strong>{this.state.errorMsg} </strong>
          </Toast>
        </div>);
    }

    if (this.state.showSuccessMsg){
      successMsg=(
        <Box className={this.state.successNotification}>
          <strong>
            You have successfully registered the application! <br/>
            Please wait while we are redirecting to dashboard.
          </strong>
        </Box>);
    }

    if(this.state.registration_page_required){
      return (
        <Section id="reg-page-wrap" full="vertical" flex={true} >
          <Form id= "Registration" name="Registration" className={this.state.formContent} >
            <Header>
              <Heading id="h1">
                <strong>Registration Form</strong>
              </Heading>
            </Header><br/><br/>
            <FormField id="disable_form_field" label="EPRID">
              <textarea name="eprid" value={this.props.location.query.EPRID} disabled/>
            </FormField><br/>
            <FormField id="disable_form_field" label="Application Name">
              <textarea name="app_name" value={this.props.location.query.AppName} disabled/>
            </FormField><br/>
            <FormField id="disable_form_field" label="Application Instance ID">
              <textarea name="api_creator_group" value={this.props.location.query.ApplicationInstanceID} disabled/>
            </FormField><br/>
            <FormField label="Owner Email Address" error={this.state.invalidEmailError}>
              <textarea placeholder="Email of a person who is registring in API catalog as owner of API" name="user_email" value={this.state.user_email} onChange={this.handleInputChange}  />
            </FormField><br/>
          </Form>
          <form className={this.state.formContent}>
            <Button label="Register" onClick={this.handleSubmit}/>
          </form><br/>
          {errorNotifications}
          {successMsg}
        </Section>
      );
    }
    else{
      return(this.state.msg);
    }
  }
}

Registration.propTypes = {
  location: React.PropTypes.object,
  menuShowMenuSet: React.PropTypes.func
};
const mapDispatchToProps = (dispatch) => {
  return {
   menuShowMenuSet: (bool) => dispatch(menuShowMenuSet(bool))
  };
};

export default connect (props => ({menuShowMenuSet:props.menuShowMenuSet}), mapDispatchToProps)(Registration);
