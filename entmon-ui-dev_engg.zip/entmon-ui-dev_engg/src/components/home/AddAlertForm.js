import React from 'react';
import { connect } from 'react-redux';
import { buildQuery, processStatus } from 'grommet/utils/Rest';
import Heading from 'grommet/components/Heading';
import Header from 'grommet/components/Header';
import FormField from 'grommet/components/FormField';
import Button from 'grommet/components/Button';
import Select from 'grommet/components/Select';
import Label from 'grommet/components/Label';
import CheckBox from 'grommet/components/CheckBox';
import RadioButton from 'grommet/components/RadioButton';
import Notification from 'grommet/components/Notification';

const common = require('../home/common');
const config = require(`../../../config.${process.env.NODE_ENV}.json`);
const DURATION = 'duration';
const COUNT = 'count';
const PATTERNMATCH = 'patternMatch';
const FREQUENCY = 'frequency';
const FREQUENCYCOUNT = 'frequencyCount';
const EDIT = 'edit';
const ADD_ALERT = 'Add Alert';
const EDIT_ALERT = 'Edit Alert';
const SAVE = 'Save';
const APPLICATION = 'Application';
const WORKFLOW = 'Workflow';
const GREATOR_OPERATOR = '>';
const LESSER_OPERATOR = '<';
const PARAM_KEY_SEPERATOR = '=';

class AddAlertForm extends React.Component {
  constructor(props) {
    super(props);

    this.setAlertDetails(props);

    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleAlertTypeChange = this.handleAlertTypeChange.bind(this);
    this.getApplicationApiNames = this.getApplicationApiNames.bind(this);
    this.getAlertThresholdDiv = this.getAlertThresholdDiv.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.resetNotifications = this.resetNotifications.bind(this);
    this.getLabel = this.getLabel.bind(this);
    this.selectedAppConsGrp = {
      groupId: '',
    };
  }

  componentWillMount() {
    if (this.props.action === EDIT) {
      this.setAlertdetailsForEditAction(this.props);
    }
  }

  componentWillReceiveProps(newProps) {
    if (newProps.action === EDIT) {
      this.setAlertdetailsForEditAction(newProps);
    } else {
      this.setAlertDetails(newProps);
    }
  }

  setAlertDetails(props) {
    document.title = ADD_ALERT;
    const applicationApiNames = [];
    const appNameOptions = [];
    const appListForUser = [];
    const apiListForUser = [];
    const apiNameOptions = [];

    if (props.isFromChart && props.action !== EDIT) {
      if (props.applicationApiName) {
        applicationApiNames.push(props.applicationApiName);
      }

      if (props.appName) {
        appNameOptions.push(props.appName);
      }

      if (props.apiName) {
        apiNameOptions.push(props.apiName);
      }

      if (props.userAction && props.applicationInstanceId) {
        const appForUser = {};
        appForUser.isFromChart = props.isFromChart;
        appListForUser.push(appForUser);
      }
    }

    this.state = {
      alertCategory: props.alertCategory ? props.alertCategory : '',
      alertCategoryOptions: [APPLICATION, WORKFLOW],
      appListForUser,
      workflowListForUser: [],
      applicationApiNames,
      appName: props.isFromChart ? props.appName : '',
      workflowName: props.isFromChart ? props.workflowName : '',
      selectedApiName: props.isFromChart ? props.applicationApiName : '',
      applicationInstanceId: props.isFromChart ? props.applicationInstanceId : '',
      selectedAppUserAction: '',
      appNameOptions,
      workflowNameOptions: [],
      alertTypeSelection: DURATION,
      alertEnable: 'Y',
      alertEnableValue: true,
      alertName: '',
      alertDescription: '',
      alertThreshold: '',
      minJobCountThForFrequency: '',
      minJobCountThForFreqCount: '',
      timeRangeStart: '',
      timeRangeEnd: '',
      alertComputationInterval: '',
      notificationSuppressionDuration: '',
      alertDistributionList: '',
      emailFieldError: '',
      alertThresholdFieldError: '',
      alertComputationIntervalFieldError: '',
      notificationSuppressionDurationFieldError: '',
      workflowNameError: '',
      appNameError: '',
      appApiNameError: '',
      alertNameError: '',
      alertDescriptionError: '',
      appDataForUser: {},
      err: '',
      success: '',
      alertFormHeading: 'Add a new Alert',
      userEmail: props.isFromChart ? props.userEmail : '',
      isTooltipActive: false,
      EPRID_APP_NAMES: [],
      EPRID_API_NAMES: [],
      isgetAppName: false,
      apiNameOptions,
      apiListForUser,
      responseStatus: '',
      applicationConsumerId: '',
      apiName: '',
      selectedWorkflowDetail: '',
    };
  }

  setAlertdetailsForEditAction(props) {
    if (props.action === EDIT) {
      document.title = EDIT_ALERT;
      let alertEnable = 'N';
      let alertEnableValue = false;
      if (props.alertEnable === 'Y') {
        alertEnable = 'Y';
        alertEnableValue = true;
      } else {
        alertEnable = 'N';
        alertEnableValue = false;
      }

      let alertThersholdValue;
      if (props.alertTypeSelection === DURATION) {
        alertThersholdValue = props.alertThresholdDuration;
      } else if (props.alertTypeSelection === COUNT) {
        alertThersholdValue = props.alertThresholdCount;
      } else if (props.alertTypeSelection === PATTERNMATCH) {
        alertThersholdValue = props.alertCriteriaPatternMatch;
      }

      let paramValue = '';
      const paramValues = props.paramKeyValues.split(PARAM_KEY_SEPERATOR);
      if (paramValues.length !== 2) {
        paramValue = '';
      } else {
        paramValue = paramValues[1];
      }

      this.setState({
        userEmail: props.userEmail,
        notificationId: props.notificationId,
        appName: props.appName,
        workflowName: props.workflowName,
        alertCategoryOptions: [props.alertCategory],
        selectedApiName: props.applicationApiName,
        applicationApiNames: [props.applicationApiName],
        applicationInstanceId: props.applicationInstanceId,
        alertName: props.alertName,
        alertDescription: props.alertDescription,
        requestResponseParamKey: paramValues[0],
        requestResponseParamValue: paramValue,
        alertTypeSelection: props.alertTypeSelection,
        alertThreshold: alertThersholdValue,
        minJobCountThForFrequency: props.minJobCountThForFrequency,
        minJobCountThForFreqCount: props.minJobCountThForFreqCount,
        timeRangeStart: props.timeRangeStart,
        timeRangeEnd: props.timeRangeEnd,
        alertComputationInterval: props.alertComputationInterval,
        notificationSuppressionDuration: props.notificationSuppressionDuration,
        responseStatus: props.responseStatus,
        alertDistributionList: props.alertDistributionList,
        alertEnable,
        alertEnableValue,
        alertFormHeading: 'Edit the selected Alert',
        alertConsumerId: '',
      });
    }
  }

  fetchDataForUserAndSetState(alertCategory) {
    let uri;
    if (this.props.userEmail !== undefined) {
      const host = config.serverUrl;
      let endpoint = '/get-app-details';
      if (alertCategory === WORKFLOW) {
        endpoint = '/get-my-workflows';
      }
      const query = buildQuery({
        user_email: this.props.userEmail,
      });
      uri = `${host}${endpoint}${query}`;
      fetch(uri)
        .then(processStatus)
        .then(response => response.json())
        .then(itemListForUser => {
          if (alertCategory === APPLICATION) {
            const mainAllAppNames = [];
            const allAppNames = itemListForUser.map(element => {
              mainAllAppNames.push(element.app_name);
              return `${`${element.eprid}-${element.app_name}`} <${element.application_instance_id}> [${element.user_action}]`;
            });
            const listOfAppNames = allAppNames.filter((elem, index, originalArray) => {
              return index === originalArray.indexOf(elem);
            });
            const EPRID_APP_NAMES = listOfAppNames.filter((elem, index, self) => {
              return index === self.indexOf(elem);
            });
            this.setState({
              alertCategory,
              appListForUser: itemListForUser,
              mainAllAppNames,
              appNameOptions: listOfAppNames,
              EPRID_APP_NAMES,
            });
          } else if (alertCategory === WORKFLOW) {
            const listOfWorkflows = [];
            const workflowListForUser = [];
            itemListForUser.forEach(eachWorkflowRecord => {
              const workflowsInEachWfGrp = eachWorkflowRecord.workflows;
              workflowListForUser.push(workflowsInEachWfGrp);
              workflowsInEachWfGrp.forEach(workflowRecord => {
                listOfWorkflows.push(workflowRecord.workflow_name);
              });
            });
            this.setState({
              alertCategory,
              workflowNameOptions: listOfWorkflows,
              workflowListForUser,
            });
          }
        })
        .catch(error => {
          console.error(error);
          this.setState({ err: `We cannot connect to server at this time to get ${alertCategory} details. Please check if you logged in or try again later!` });
        });
    } else {
      this.setState({ err: 'There is an issue loading page. Please check if you are logged in or try again!' });
    }
  }

  fetchAppConsumerGroup(apiName, appName, userEmail, userAction, appConsGrpValuesForApi) {
    if (apiName !== undefined || appName !== undefined || userEmail !== undefined ||
      userAction !== undefined) {
      const host = config.serverUrl;
      const getConGrpEndPoint = '/get-consumergroup-for-api';
      const queryParams = buildQuery({
        user_email: userEmail,
        user_action: userAction,
        app_name: appName,
        api_name: apiName,
      });
      const uri = `${host}${getConGrpEndPoint}${queryParams}`;
      fetch(uri)
        .then(processStatus)
        .then(response => response.json())
        .then(appConsumerGroups => {
          const applicationConsumerGroupOptions = appConsumerGroups.map(eachConsGroup =>
            eachConsGroup.application_consumer_id);
          if (applicationConsumerGroupOptions.length === 0) {
            applicationConsumerGroupOptions[0] = '';
          }
          this.setState({
            [appConsGrpValuesForApi]: applicationConsumerGroupOptions,
          });
        })
        .catch(error => {
          console.error(error);
          this.setState({ err: 'We cannot connect to server at this time to get the Application consumer group details. Please check your network connection or try again later!' });
        });
    } else {
      this.setState({ err: 'There is an issue fetching application consumer group as atleast one of the required params is undefined. Please check if you are logged in or try again!' });
    }
  }

  getAppNameAppId(e, selectedInstance) {
    const appListForUser = this.state.appListForUser;
    const appNameOptions = this.state.appNameOptions;

    const selectedInstanceIndex = appNameOptions.indexOf(selectedInstance);
    const appForUser = appListForUser[selectedInstanceIndex];

    let selectedAppUserAction = '';
    if (!appForUser.isFromChart) {
      selectedAppUserAction = appForUser.user_action;
      const applicationInstanceId = appForUser.application_instance_id;
      const appName = appForUser.app_name;

      this.setState({
        appName,
        selectedApiName: 'Select Api Name',
        applicationInstanceId,
        isgetAppName: true,
      });

      this.getApplicationApiNames(appName, applicationInstanceId);
    } else {
      const selectedApp = appListForUser.filter(eachAppDetail => {
        return (eachAppDetail.app_name === selectedInstance);
      });
      selectedAppUserAction = selectedApp.user_action;
    }

    this.setState({
      selectedAppUserAction,
    });
  }

  handleAppNameSearch(filter) {
    const regexp = new RegExp(filter);
    const appNameOptions = this.state.EPRID_APP_NAMES.filter(value => regexp.test(value));
    this.setState({ appNameOptions });
  }

  //  handleWorkFlowSearch --- change the function name to make workflow search to work
  han(filter) {
    const exp = new RegExp(filter);
    const workflowNameOptions = this.state.workflowNameOptions.filter(value => exp.test(value));
    this.setState({ workflowNameOptions });
  }

  getSelectedWorkflowDetails(e, selectedInstance) {
    const selectedWorkflowDetail = {};
    const selectedWorkflow = this.state.workflowListForUser.
      filter(workflowRecord => workflowRecord[0].workflow_name === selectedInstance);
    const firstRecrd = selectedWorkflow[0];
    selectedWorkflowDetail.workflow_name = selectedInstance;
    selectedWorkflowDetail.workflow_id = firstRecrd[0].workflow_id;
    const apps = firstRecrd[0].apps;
    const appList = [];
    apps.forEach(app => {
      app.api_names.forEach(apiName => {
        const appDetails = {};
        appDetails.app_name = app.app_name;
        appDetails.application_instance_id = app.application_instance_id;
        appDetails.api_name = apiName;
        appDetails.cgStateName = this.getUniqueConsGroupName(appDetails);
        appDetails.cgOptionsStateName = `${appDetails.cgStateName}.options`;
        // TODO:: Call get-consumergroup-api here and set the below value.
        appDetails.cgOptions = ['dummy-yet-to-be-implemeted'];
        appList.push(appDetails);
      });
    });
    selectedWorkflowDetail.appDetails = appList;
    this.setState({
      workflowName: selectedInstance,
      selectedWorkflowDetail,
    });
  }

  getApplicationApiNames(formAppName, applicationAppInstance) {
    const host = config.serverUrl;
    const endpoint = '/get-api-details';
    const query = buildQuery({
      application_instance_id: applicationAppInstance,
      app_name: formAppName,
      user_email: this.props.userEmail,
    });
    const uri = `${host}${endpoint}${query}`;
    fetch(uri)
      .then(processStatus)
      .then(response => response.json())
      .then(appapis => {
        const appApiNames = [];
        const apiNames = appapis.map(e => {
          appApiNames.push(e.api_name);
          return `${e.api_name}`;
        });
        const listOfApiNames = apiNames.filter((elem, index, originalArray) => {
          return index === originalArray.indexOf(elem);
        });

        const EPRID_API_NAMES = listOfApiNames.filter((elem, index, self) => {
          return index === self.indexOf(elem);
        });

        this.setState({
          apiNameOptions: appapis,
          EPRID_API_NAMES,
          appApiNames,
          apiListForUser: listOfApiNames,
          applicationApiNames: listOfApiNames,
        });
      });
  }

  // handleApiNameSearch -- search filter for api Name function name to be change
  api(filter) {
    const regExpression = new RegExp(filter);
    const applicationApiNames = this.state.EPRID_API_NAMES.filter(value =>
      regExpression.test(value));
    this.setState({ applicationApiNames });
  }

  handleApiFieldOptions(e, selectedInstance) {
    const apiListForUser = this.state.apiListForUser;
    const apiNameOptions = this.state.apiNameOptions;

    const selectedApiInstanceIndex = apiListForUser.indexOf(selectedInstance);
    const apiForUser = apiNameOptions[selectedApiInstanceIndex];

    if (!apiForUser.isFromChart) {
      const apiName = apiForUser.api_name;

      this.setState({
        apiName,
        selectedApiName: selectedInstance,
      });
    }

    const consumerGroupForApi = `cg.name.${this.state.applicationInstanceId}.${selectedInstance}`;
    const appConsGrpValuesForApi = `${consumerGroupForApi}.options`;
    this.fetchAppConsumerGroup(selectedInstance, this.state.appName, this.props.userEmail,
      this.state.selectedAppUserAction, appConsGrpValuesForApi);
  }

  handleInputChange(e, uniqueApiName) {
    const TARGET = e.target;
    const NAME = TARGET.name;
    const VALUE = TARGET.value;
    const OPTION = e.option;
    // NOTE:: The state name is the element name
    if (NAME === 'alertDistributionList') {
      const allEmails = e.target.value.split('\n');
      this.setState({ alertDistributionList: allEmails });
    } else if (NAME === 'alertCategory') {
      this.fetchDataForUserAndSetState(OPTION);
    } else if (NAME === 'responseStatus' || NAME === 'requestResponseParamKey' || NAME === uniqueApiName) {
      this.setState({
        [NAME]: OPTION,
      });
    } else {
      this.setState({
        [NAME]: VALUE,
      });
    }
  }

  handleAlertTypeChange(e) {
    if (this.props.action !== EDIT) {
      this.setState({ alertTypeSelection: e.target.name });
    }
  }

  alertEnableChange(e) {
    let alertEnable = 'N';
    let alertEnableValue = false;

    e.target.checked ?
      (alertEnable = 'Y', alertEnableValue = true) : (alertEnable = 'N', alertEnableValue = false);

    this.setState({ alertEnable, alertEnableValue });
  }

  handleSubmit(e) {
    e.preventDefault();
    const alertDistList = this.state.alertDistributionList;
    const alertThreshold = this.state.alertThreshold;
    const alertComputationInterval = this.state.alertComputationInterval;
    const notificationSuppressionDuration = this.state.notificationSuppressionDuration;
    const appName = this.state.appName;
    const appApiName = this.state.selectedApiName;
    const alertName = this.state.alertName;
    const alertDescription = this.state.alertDescription;
    const workflowName = this.state.workflowName;
    const responseStatus = this.state.responseStatus;

    let allEmails = alertDistList.toString().split(',');
    let emailFieldError = '';
    let alertThresholdFieldError = '';
    let alertComputationIntervalFieldError = '';
    let notificationSuppressionDurationFieldError = '';
    let workflowNameError = '';
    let appNameError = '';
    let appApiNameError = '';
    let alertNameError = '';
    let alertDescriptionError = '';
    let responseStatusError = '';
    let isReadyToSubmit = true;
    let alertCategoryError = '';

    if (this.state.alertCategory === APPLICATION) {
      if (appName === '') {
        appNameError = 'Application Name field cannot be blank.';
        isReadyToSubmit = false;
      }

      if (appApiName === '') {
        appApiNameError = 'Application Api Names field cannot be blank.';
        isReadyToSubmit = false;
      }
    } else {
      if (workflowName === '') {
        workflowNameError = 'Workflow Name field cannot be blank.';
        isReadyToSubmit = false;
      }
    }

    
    if (this.state.alertCategory === '') {
      alertCategoryError = 'Alert category cannot be blank. Select one of the values.';
      isReadyToSubmit = false;
    }

    if (alertName === '') {
      alertNameError = 'Alert Name field cannot be blank.';
      isReadyToSubmit = false;
    }

    if (alertDescription === '') {
      alertDescriptionError = 'Alert Description field cannot be blank.';
      isReadyToSubmit = false;
    }

    allEmails = allEmails.filter(entry => entry.trim() !== '');
    if (allEmails.length === 0) {
      emailFieldError = 'There should be at least one email in Alert Distribution List field.';
      isReadyToSubmit = false;
    }

    const invalidEmails = [];
    allEmails.map(element => {
      if (!common.isEmail(element)) {
        invalidEmails.push(element);
        isReadyToSubmit = false;
      }
    });

    if (invalidEmails.length > 0) {
      emailFieldError = `Invalid Email(s): ${invalidEmails.join()}`;
    }

    const alertType = this.state.alertTypeSelection;
    if (alertType === DURATION || alertType === COUNT) {
      if (alertThreshold <= 0 || alertThreshold === '') {
        alertThresholdFieldError = 'Alert Threshold field cannot be blank or zero.';
        isReadyToSubmit = false;
      }

      if (alertComputationInterval <= 0 || alertComputationInterval === '') {
        alertComputationIntervalFieldError = 'Alert Computation Interval field cannot be blank or zero.';
        isReadyToSubmit = false;
      }

      if (notificationSuppressionDuration <= 0 || notificationSuppressionDuration === '') {
        notificationSuppressionDurationFieldError = 'Alert Frequency Violation field cannot be blank or zero.';
        isReadyToSubmit = false;
      }
    }

    if (responseStatus === '') {
      responseStatusError = 'Response Status cannot be blank. Select one of the values.';
      isReadyToSubmit = false;
    }

    this.setState({ emailFieldError,
                    alertThresholdFieldError,
                    alertComputationIntervalFieldError,
                    notificationSuppressionDurationFieldError,
                    appNameError,
                    appApiNameError,
                    alertNameError,
                    alertDescriptionError,
                    workflowNameError,
                    responseStatusError,
                    alertCategoryError });

    if (isReadyToSubmit) {
      this.sendFormData(e, allEmails);
    }
  }

  sendFormData(e, allEmails) {
    const body = {};
    body.set = function(key, val) {
      body[`${key}`] = val;
    };
    body.get = function(key) {
      return body[`${key}`];
    };

    if (this.state.alertCategory === APPLICATION) {
      body.set('app_name', this.state.appName);
      body.set('api_name', this.state.selectedApiName);
      body.set('application_instance_id', this.state.applicationInstanceId);
      const consumerGroupStateName = this.getUniqueConsGroupName();
      body.set('application_consumer_id', this.state[consumerGroupStateName]);
    } else if (this.state.alertCategory === WORKFLOW) {
      body.set('workflow_name', this.state.workflowName);
      const selectedWorkflow = this.state.selectedWorkflowDetail;
      body.set('workflow_id', selectedWorkflow.workflow_id);
      const selectedApiConsIds = selectedWorkflow.appDetails.map(eachAppDetail => {
        const eachAppConsObj = {};
        eachAppConsObj.app_name = eachAppDetail.app_name;
        eachAppConsObj.application_instance_id = eachAppDetail.application_instance_id;
        eachAppConsObj.api_name = eachAppDetail.api_name;
        eachAppConsObj.application_consumer_id = this.state[eachAppDetail.cgStateName];
        return eachAppConsObj;
      });
      body.set('application_consumer_id', selectedApiConsIds);
    }
    body.set('alert_description', this.state.alertDescription);
    body.set('alert_name', this.state.alertName);
    const alertType = this.state.alertTypeSelection;
    if (alertType === DURATION) {
      body.set('event_criteria_duration', this.state.alertThreshold);
      body.set('event_criteria_operator', GREATOR_OPERATOR);
      body.set('frequency', this.state.alertComputationInterval);
    } else if (alertType === COUNT) {
      body.set('event_criteria_trans_count', this.state.alertThreshold);
      body.set('event_criteria_operator', GREATOR_OPERATOR);
      body.set('frequency', this.state.alertComputationInterval);
    } else if (alertType === PATTERNMATCH) {
      body.set('event_criteria_text', this.state.alertThreshold);
    } else if (alertType === FREQUENCY) {
      body.set('event_threshold_job_count', this.state.minJobCountThForFrequency);
      body.set('criteria_frequency', this.state.alertComputationInterval);
      body.set('event_criteria_operator_jobcount', LESSER_OPERATOR);
    } else if (alertType === FREQUENCYCOUNT) {
      body.set('event_criteria_trans_count', this.state.minJobCountThForFreqCount);
      body.set('timerange_start', this.state.timeRangeStart);
      body.set('timerange_end', this.state.timeRangeEnd);
      body.set('event_criteria_operator', LESSER_OPERATOR);
    }
    body.set('response_status', this.state.responseStatus);
    body.set('is_enabled', this.state.alertEnable);
    body.set('notification_email_id', allEmails.join());
    body.set('notification_suppression_duration', this.state.notificationSuppressionDuration);
    body.set('user_email_id', this.props.userEmail);
    body.set('alert_type', this.state.alertTypeSelection);
    const paramKeyValues = [];
    const eachReqRespKeyValue = { alert_param_key: this.state.requestResponseParamKey,
      alert_param_value: this.state.requestResponseParamValue };
    paramKeyValues.push(eachReqRespKeyValue);
    body.param_key_values = paramKeyValues;

    let method = 'POST';
    let endpoint ;
    if (this.state.alertCategory === APPLICATION) {
      if (this.props.action === EDIT) {
        body.set('notification_id', this.props.notificationId);
        method = 'PUT';
        endpoint = '/put-notification-form-data';
      } else {
        endpoint = '/post-notification-form-data';
      }
    } else if (this.state.alertCategory === WORKFLOW) {
      if (this.props.action === EDIT) {
        body.set('notification_id', this.props.notificationId);
        method = 'PUT';
        endpoint = '/put-workflow-notification-form-data';
      } else {
        endpoint = '/post-workflow-notification-form-data';
      }
    }
    const uri = `${config.serverUrl}${endpoint}`;
    fetch(encodeURI(uri), {
      method,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    }).then(processStatus)
      .then(response => {
        if (response.status === 200) {
          let successMessage = 'Alert is created successfully. The record shall update in the table within 10 secs.';
          if (this.props.action === EDIT) {
            successMessage = 'Alert is updated successfully. The record shall update in the table within 10 secs.';
          }
          this.setState({ success: successMessage });
          this.props.closeButtonHandler('', successMessage);
        } else {
          console.error('Error while submitting the alert config details. Received HTTP status: ', response.status);
          this.props.closeButtonHandler('Error while calling insertion service.', '');
        }
      }
      )
      .catch(err => {
        console.error('Error while submitting the alert config details: ', err);
      });
  }

  resetNotifications() {
    this.setState({ err: '' });
    this.setState({ success: '' });
  }

  getApiField() {
    if (this.state.applicationApiNames.length > 0) {
      return (
        <Select
          name="api_name"
          id="api-name-field"
          className="form-field-inner-tag"
          placeHolder="Please select an API or Search for api name."
          value={this.state.selectedApiName}
          options={this.state.applicationApiNames}
          onChange={e => this.handleApiFieldOptions(e, e.option)}
          onSearch={e => this.handleApiNameSearch(e.target.value)} />
       );
    } else if (this.state.applicationApiNames.length === 0) {
      if (this.state.isgetAppName) {
        return (
          <Label className="grommetux-form-field"> { 'No Api(s) available'} </Label>
        );
      } else {
        return (
          <textarea className="form-field-inner-tag" value={this.state.apiNameSearch}
            name="alertApiSearch" placeholder="Please select an API or Search for api name." />
        );
      }
    }
  }


  getAlertThresholdDiv(isDuration) {
    let labelForThreshold = '';
    if (isDuration) {
      labelForThreshold = '(msec)';
    }

    return (<div>
      <FormField label={`Alert Threshold - ${labelForThreshold} [ ${this.state.alertTypeSelection} ]`}
        error={this.state.alertThresholdFieldError}>
        <textarea name="alertThreshold" value={this.state.alertThreshold}
          placeholder="Provide the violation criteria." onChange={this.handleInputChange} />
      </FormField>
    </div>);
  }

  getAlertComputationIntDiv() {
    return (<div>
      <FormField label="Alert Computation Interval - (mins)"
        error={this.state.alertComputationIntervalFieldError}>
        <textarea name="alertComputationInterval" onChange={this.handleInputChange}
          value={this.state.alertComputationInterval}
          placeholder="Provide a value that controls how frequently the alert needs to be computed." />
      </FormField>
    </div>);
  }

  getLabel(applicationInstanceId, apiName) {
    return `Application Consumer ID for API: ${applicationInstanceId}.${apiName}`;
  }

  getUniqueConsGroupName(eachAppDetail) {
    if (this.state.alertCategory === APPLICATION) {
      return `cg.name.${this.state.applicationInstanceId}.${this.state.selectedApiName}`;
    } else if (this.state.alertCategory === WORKFLOW) {
      return `cg.name.${eachAppDetail.application_instance_id}.${eachAppDetail.api_name}`;
    }
  }

  getApplicationConsumerIdField (labelForFormField, cgStateNameForApi, optionsOrStateName) {
    // TODO:: Handle empty consumer groups for an API.

    let consGroupOptions;
    if (this.state.alertCategory === APPLICATION) {
      consGroupOptions = this.state[optionsOrStateName];
    } else if (this.state.alertCategory === WORKFLOW) {
      consGroupOptions = optionsOrStateName;
    }

    return (<FormField key={cgStateNameForApi} label={labelForFormField} >
      <Select
        id="application-consumerId-field"
        name={cgStateNameForApi}
        className="form-field-inner-tag"
        placeHolder="Please select a consumer group"
        options={consGroupOptions}
        onChange={e => {
          this.handleInputChange(e, cgStateNameForApi);
        }}
        value={this.state[cgStateNameForApi]} />
    </FormField>);
  }

  getAppApiConsIdFields () {
    const labelForFormField = this.getLabel(this.state.applicationInstanceId,
      this.state.selectedApiName);
    const consumerGroupForApi = this.getUniqueConsGroupName();
    const appConsGrpValuesForApi = `${consumerGroupForApi}.options`;
    return this.getApplicationConsumerIdField(labelForFormField, consumerGroupForApi,
      appConsGrpValuesForApi);
  }

  getWfApiConsIdFields (appDetails) {
    return appDetails.map(eachAppDetail => {
      const labelForFormField = this.getLabel(eachAppDetail.application_instance_id,
        eachAppDetail.api_name);
      return this.getApplicationConsumerIdField(labelForFormField, eachAppDetail.cgStateName,
        eachAppDetail.cgOptions);
    });
  }

  render() {
    let applicationField;
    let applicationApiField;
    let applicationConsumerIdField;
    let workflowField;

    if (this.state.alertCategory === APPLICATION) {
      applicationField = (
        <FormField
          label="Application Name" error={this.state.appNameError}>
          <Select
            name="app_name"
            id="app-name-field"
            className="form-field-inner-tag"
            placeHolder="Select the application (You can filter the records in list using the search option based on eprid or application name)."
            value={this.state.appName}
            options={this.state.appNameOptions}
            onChange={e => this.getAppNameAppId(e, e.option)}
            onSearch={e => this.handleAppNameSearch(e.target.value)} />
        </FormField>
      );

      applicationApiField = (
        <FormField
          label="Application Api Names"
          className={this.state.appConsIdField} error={this.state.appApiNameError}>
          { this.getApiField() }
        </FormField>
      );

      if (this.state.apiName !== '') {
        applicationConsumerIdField = this.getAppApiConsIdFields();
      }
    } else if (this.state.alertCategory === WORKFLOW) {
      workflowField = (
        <FormField
          label="Workflow Name" error={this.state.workflowNameError}>
          <Select
            name="workflowName"
            id="workflow-name-field"
            className="form-field-inner-tag"
            placeHolder="Select the workflow (You can filter the records in list using the search option based on worklfow name)."
            value={this.state.workflowName}
            options={this.state.workflowNameOptions}
            onChange={e => this.getSelectedWorkflowDetails(e, e.option)}
            onSearch={e => this.handleWorkFlowSearch(e.target.value)} />
        </FormField>
      );
      if (this.state.selectedWorkflowDetail !== '') {
        const appDetails = this.state.selectedWorkflowDetail.appDetails;
        applicationConsumerIdField = this.getWfApiConsIdFields(appDetails);
      }
    }

    let alertThresholdField = '';
    let alertThresholdCountField = '';
    let alertComputationIntervalField = '';
    let alertFreqCountThresholdField = '';
    let timeRangeStartField = '';
    let timeRangeEndField = '';
    let notificationSuppressionDurationField = (
      <div>
        <FormField label="Alert Frequency Violation - (mins)"
          error={this.state.notificationSuppressionDurationFieldError}>
          <textarea name="notificationSuppressionDuration" onChange={this.handleInputChange}
            value={this.state.notificationSuppressionDuration}
            placeholder="Provide a value that controls how frequently mail notifications shall be sent on alert violation. (This value should be a multiple of 'Alert Computation Interval'). " />
        </FormField>
      </div>);
    const placeHolderMessage = 'Provide the minimum number of job/records to be present (for the computation time range). If the total jobs/records is lesser than this value the alert will be sent.';
    if (this.state.alertTypeSelection === DURATION) {
      alertThresholdField = this.getAlertThresholdDiv(true);
      alertComputationIntervalField = this.getAlertComputationIntDiv();
    } else if (this.state.alertTypeSelection === COUNT) {
      alertThresholdField = this.getAlertThresholdDiv(false);
      alertComputationIntervalField = this.getAlertComputationIntDiv();
    } else if (this.state.alertTypeSelection === PATTERNMATCH) {
      alertThresholdField = (
        <div>
          <FormField label={`Pattern To Search -  [ ${this.state.alertTypeSelection} ]`}>
            <textarea name="alertThreshold" value={this.state.alertThreshold}
              placeholder="Please enter comma seperated values."
              className="form-field-inner-tag" onChange={this.handleInputChange} />
          </FormField>
        </div>);
      notificationSuppressionDurationField = '';
    } else if (this.state.alertTypeSelection === FREQUENCY) {
      alertThresholdCountField = (<div>
        <FormField label={'Minimum Job count Threshold'}
          error={this.state.alertThresholdFieldError}>
          <textarea name="minJobCountThForFrequency" value={this.state.minJobCountThForFrequency}
            placeholder={placeHolderMessage}
            onChange={this.handleInputChange} />
        </FormField>
      </div>);
      alertComputationIntervalField = this.getAlertComputationIntDiv();
    } else if (this.state.alertTypeSelection === FREQUENCYCOUNT) {
      timeRangeStartField = (<div>
        <FormField label="Time Range Start Time">
          <textarea
            name="timeRangeStart"
            className="form-field-inner-tag"
            placeholder="Please provide the start time (in 24 hour format hh:mm, ex: 10:30)"
            onChange={this.handleInputChange}
            value={this.state.timeRangeStart} />
        </FormField>
      </div>);
      timeRangeEndField = (<div>
        <FormField label="Time Range End Time">
          <textarea
            name="timeRangeEnd"
            className="form-field-inner-tag"
            placeholder="Please provide the start time (in 24 hour format hh:mm, ex: 11:30)"
            onChange={this.handleInputChange}
            value={this.state.timeRangeEnd} />
        </FormField>
      </div>);
      alertFreqCountThresholdField = (<div>
        <FormField label={'Minimum Job count Threshold '}
          error={this.state.alertThresholdFieldError}>
          <textarea name="minJobCountThForFreqCount" value={this.state.minJobCountThForFreqCount}
            placeholder={placeHolderMessage}
            onChange={this.handleInputChange} />
        </FormField>
      </div>);
    }

    let errorNotifications;
    if (this.state.err) {
      errorNotifications = (<div>
        <Notification status="critical" message={'Error while creating the alert.'} state={this.state.err} closer="true" onClose={this.resetNotifications} />
      </div>);
    }

    const alertEnableField = (<div>
      <FormField label="Alert Enable">
        <CheckBox label={this.state.alertEnable}
          toggle={true} checked={this.state.alertEnableValue}
          onChange={e => this.alertEnableChange(e)} />
      </FormField>
    </div>);

    const alertDistributionListField = (<div>
      <FormField
        label="Alert Distribution List"
        error={this.state.emailFieldError}>
        <textarea
          name="alertDistributionList"
          placeholder="Please enter comma seperated values (Hit `enter key` to add a comma)."
          value={this.state.alertDistributionList}
          onChange={this.handleInputChange} />
      </FormField>
    </div>);

    const responseStatusField = (<div>
      <FormField
        label="Response Status"
        error={this.state.responseStatusError}>
        <Select
          name="responseStatus"
          id="response-status-field"
          className="form-field-inner-tag"
          placeHolder="Select one of the response status value."
          value={this.state.responseStatus}
          options={['Pass', 'Fail', 'Pass,Fail']}
          onChange={this.handleInputChange} />
      </FormField>
    </div>);

    const requestResponseParamField = (<div>
      <FormField
        label="Request/Response Param Key">
        <Select
          name="requestResponseParamKey"
          id="request-response-param-key-field"
          className="form-field-inner-tag"
          placeHolder="Select one of the request/response param key."
          value={this.state.requestResponseParamKey}
          options={['request_parameter_name1', 'request_parameter_value1', 'request_parameter_name2', 'request_parameter_value2',
                    'request_parameter_name3', 'request_parameter_value3', 'request_parameter_name4', 'request_parameter_value4',
                    'request_parameter_name5', 'request_parameter_value5', 'response_parameter_name1', 'response_parameter_value1',
                    'response_parameter_name2', 'response_parameter_value2', 'response_parameter_name3', 'response_parameter_value3',
                    'response_parameter_name4', 'response_parameter_value4', 'response_parameter_name5', 'response_parameter_value5',
          ]}
          onChange={this.handleInputChange} />
      </FormField>
    </div>);

    const responseParamValueField = (<div>
      <FormField
        label="Request/Response Value to match">
        <textarea name="requestResponseParamValue" value={this.state.requestResponseParamValue}
          placeholder={'Provide a value for the selected Request/Response param value (selected above)'}
          onChange={this.handleInputChange} />
      </FormField>
    </div>);

    const formButtonLabel = SAVE;
    return (
      <div className="alert-formdiv">
        <div id="page-wrap">
          <form name="add_new_alert_form" className="form-style">
            <Header>
              <Heading className="form-header" tag="h3">
                <strong>{this.state.alertFormHeading}</strong>
              </Heading>
            </Header>
            <hr />
            <FormField
              label="Alert Category"
              error={this.state.alertCategoryError}>
              <Select
                name="alertCategory"
                id="alert-category-field"
                className="form-field-inner-tag"
                placeHolder="Select the alert category."
                value={this.state.alertCategory}
                options={this.state.alertCategoryOptions}
                onChange={this.handleInputChange} />
            </FormField>
            {applicationField}
            {applicationApiField}
            {workflowField}
            {applicationConsumerIdField}
            <FormField label="Alert Name" error={this.state.alertNameError}>
              <textarea
                name="alertName"
                className="form-field-inner-tag"
                placeholder="Please provide a valid alert name."
                onChange={this.handleInputChange}
                value={this.state.alertName} />
            </FormField>
            <FormField label="Alert Description" error={this.state.alertDescriptionError}>
              <textarea id="alertDescrip"
                name="alertDescription"
                className="form-field-inner-tag"
                placeholder="Please provide a valid description for the alert."
                onChange={this.handleInputChange}
                value={this.state.alertDescription} />
            </FormField>
            <FormField label="Alert Type"
              className="form-field-default form-field-alerttype">
              <RadioButton id="alerttypeduration"
                name={DURATION}
                label="Duration"
                checked={this.state.alertTypeSelection === DURATION}
                onChange={this.handleAlertTypeChange} />
              <RadioButton id="alerttypecount"
                name={COUNT}
                label="Count"
                checked={this.state.alertTypeSelection === COUNT}
                onChange={this.handleAlertTypeChange} />
              <RadioButton id="alerttypepatternmatch"
                name={PATTERNMATCH}
                label="Pattern Match"
                checked={this.state.alertTypeSelection === PATTERNMATCH}
                onChange={this.handleAlertTypeChange} />
              <RadioButton id="alerttypepatternmatch"
                name={FREQUENCY}
                label="Frequency"
                checked={this.state.alertTypeSelection === FREQUENCY}
                onChange={this.handleAlertTypeChange} />
              <RadioButton id="alerttypepatternmatch"
                name={FREQUENCYCOUNT}
                label="Frequency Count"
                checked={this.state.alertTypeSelection === FREQUENCYCOUNT}
                onChange={this.handleAlertTypeChange} />
            </FormField>
            {requestResponseParamField}
            {responseParamValueField}
            {alertThresholdField}
            {alertThresholdCountField}
            {timeRangeStartField}
            {timeRangeEndField}
            {alertFreqCountThresholdField}
            {alertComputationIntervalField}
            {notificationSuppressionDurationField}
            {responseStatusField}
            {alertDistributionListField}
            {alertEnableField}
            <hr />
            <Button type="submit" label={formButtonLabel} onClick={this.handleSubmit} />
          </form>
          {errorNotifications}
        </div>
      </div>
    );
  }
}

AddAlertForm.propTypes = {
  userEmail: React.PropTypes.string,
  notificationId: React.PropTypes.string,
  appName: React.PropTypes.string,
  applicationApiName: React.PropTypes.string,
  applicationInstanceId: React.PropTypes.string,
  alertName: React.PropTypes.string,
  alertDescription: React.PropTypes.string,
  alertTypeSelection: React.PropTypes.string,
  alertThresholdDuration: React.PropTypes.number,
  alertThresholdCount: React.PropTypes.number,
  alertCriteriaPatternMatch: React.PropTypes.string,
  minJobCountThForFrequency: React.PropTypes.number,
  minJobCountThForFreqCount: React.PropTypes.number,
  timeRangeStart: React.PropTypes.string,
  timeRangeEnd: React.PropTypes.string,
  alertComputationInterval: React.PropTypes.number,
  notificationSuppressionDuration: React.PropTypes.number,
  alertEnable: React.PropTypes.string,
  alertDistributionList: React.PropTypes.string,
  action: React.PropTypes.string,
  isFromChart: React.PropTypes.bool,
  alertCategory: React.PropTypes.string,
  closeButtonHandler: React.PropTypes.func,
  userAction: React.PropTypes.string,
  workflowName: React.PropTypes.string,
  applicationConsumerId: React.PropTypes.string,
  responseStatus: React.PropTypes.string,
  paramKeyValues: React.PropTypes.string,
};

export default connect(props => ({ userEmail: props.userProfile.email }))(AddAlertForm);
