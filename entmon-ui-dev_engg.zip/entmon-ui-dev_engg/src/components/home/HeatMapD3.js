import React, { PropTypes } from 'react';
import * as d3 from 'd3';
const ReactDOM = require('react-dom');
import moment from 'moment';

const dotMinSize = 8; // Smallest heatmap tile size
const dotMaxSize = 40; // Largest heatmap tile size
const dotMinLength = 10; // Heatmap min number of records in data to use dotMaxSize
const dotMaxLength = 1000; // Heatmap max number of records and over in data to use dotMinSize
const margin = { top: 2, right: 30, bottom: 2, left: 30 };
const leftMarginDelta = 58;
const chartResizeDuration = 400;
const chartAnimationDefaultDuration = 750;
const chartAnimationAltDuration = 500;

// JSON structure to store color data for drawing heatmap tiles
const colorList = {
  ok: '#8cc800',
  warn: '#ffd602',
  error: '#ff324d',
  stale: '#a8a8a8',
};
const dateFormat = 'YYYY-MM-DD HH:mm:ss';

let dotSize = dotMinSize;
let width = 0;
let chart;
let chartsvg;

// Define the div for the tooltip
const div = d3.select('body')
  .append('div')
  .attr('class', 'tooltip')
  .style('opacity', 0);

/**
 * Filter data to show only certain rows
 */
function getFilteredJson(jsonData, showRowFilter) {
  const json =
    {
      columns: jsonData.columns,
      index: [],
      threshholds: [],
      data: [],
      generated_time: '',
    };

  json.appName = jsonData.data[3];
  json.report_time = jsonData.data[4];

  for (let i = 0; i < showRowFilter.length; i++) {
    if (showRowFilter[i] === 0) continue;
    json.index.push(jsonData.index[i]);
    json.threshholds.push(jsonData.threshholds[i]);
    json.data.push(jsonData.data[i]);
  }

  return json;
}

/**
 * Get the heatmap element display color
 */
function getColor(d, j, json) {
  if (!d && d !== 0) return colorList.stale; // null means stale data
  if (d >= json.threshholds[j][0]) return colorList.error;
  if (d >= json.threshholds[j][1]) return colorList.warn;
  return colorList.ok;
}

class HeatMapD3 extends React.Component {
  componentDidMount() {
    const winwidth = document.getElementById('content').getBoundingClientRect().width;
    width = winwidth - margin.left - margin.right - leftMarginDelta;
    chartsvg = d3.select(ReactDOM.findDOMNode(this))
      .attr('width', width + margin.left + margin.right + leftMarginDelta);
    chart = chartsvg
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);
    this.renderHeatmap();
  }
  componentDidUpdate() {
    this.renderHeatmap();
  }
  componentWillUnmount() {
    d3.select(window).on('resize', null); // Remove handler
  }
  renderHeatmap() {
    const jsonData = this.props.jsondata;
    const showRowFilter = this.props.rowfilter;

    let newDotSize = dotMinSize; // setting to min size
    let repaintAll = false;

    // Calculate tile size if data set is smaller
    if (jsonData.columns.length < dotMinLength)
      newDotSize = dotMaxSize;
    else  // Calculate tile width on a log scale
      if (jsonData.columns.length < dotMaxLength) {
        let percent =
          ((jsonData.columns.length - dotMinLength) / (dotMaxLength - dotMinLength)) * 100;
        percent = 1 - (percent <= 1 ? 0 : Math.log(percent) / Math.log(100));
        newDotSize = Math.round(percent * (dotMaxSize - dotMinSize) + dotMinSize);
      }

    if (newDotSize !== dotSize) {
      dotSize = newDotSize;
      repaintAll = true;
    }

    const dotEdgeCurve = 2; // Curve factor for tiles
    const dotMargin = 1;  // margin between tiles
    let maxColumns = Math.floor(width / (dotSize + dotMargin));

    const json = getFilteredJson(jsonData, showRowFilter);
    const rowMarginGap = json.index.length === 1 ? 0 : dotSize;
    const data = json.data;
    const dataCountRows = data.length;
    const dataCountCols = data[0].length;
    let chartRows = Math.ceil(dataCountCols / maxColumns);
    let chartCols = dataCountCols > maxColumns ? maxColumns : dataCountCols;

    let labels = new Array(chartRows * dataCountRows);
    for (j = 0; j < chartRows; j++)
      for (let i = 0; i < dataCountRows; i++)
        labels[j * dataCountRows + i] = (dataCountRows === 1 && j > 0) ? '' : json.index[i];

    chartsvg
      .transition()
      .duration(chartResizeDuration)
      .attr('height', dotSize * chartRows * dataCountRows + margin.top + margin.bottom + (chartRows * rowMarginGap));

    let txtLabels =
      chart
        .selectAll('text')
        .data(labels);

    txtLabels
      .enter()
      .append('text')
      .attr('x', 0)
      .attr('opacity', 0)
      .merge(txtLabels)
      .attr('y', (d, i) => rowMarginGap * Math.floor(i / dataCountRows) + i * dotSize + dotSize / 2 + margin.top + 2)
      .text(d => d)
      .transition()
      .duration(chartAnimationDefaultDuration)
      .attr('opacity', 1)
      .attr('x', margin.left - leftMarginDelta);

    txtLabels.exit()
      .transition()
      .duration(chartAnimationAltDuration)
      .attr('x', 0)
      .attr('opacity', 0)
      .remove();

    const rowbar = chart.selectAll('g').data(data);

    const rowcols = rowbar.enter()  // New
      .append('g')
      .merge(rowbar)
      .selectAll('rect')
      .data(d => d);

    let j = -1;
    let j1 = -1;
    rowcols.enter().append('rect') // only for new!!
      .attr('x', '0')
      .attr('width', dotSize - dotMargin)
      .attr('height', dotSize - dotMargin)
      .attr('rx', dotEdgeCurve)
      .attr('ry', dotEdgeCurve)
      .merge(rowcols) // New and update
      .on('mouseover', function (d, i) {
        j = (Math.floor(this.getAttribute('y') / dotSize) - Math.floor(i / maxColumns)) % dataCountRows;
        d3.select(this).style('opacity', '0.9')
          .style('stroke', 'black');
        div.transition()
          .duration(chartResizeDuration / 2)
          .style('opacity', .8);
        div.html(`${json.appName[i] ? `<b>App Name: </b>${json.appName[i]}<br/>` : ''}
                ${json.columns[i] ? `<b>NodeID: </b>${json.columns[i]}<br/>` : ''}
                <b>${json.index[j].toUpperCase()}</b>: ${d === null || isNaN(d) ? 'Stale' : d}<br/>
                ${json.report_time[i] ? `<b>Date (UTC): </b>${moment(json.report_time[i], dateFormat).format(dateFormat)}` : ''}`)
          .style('left', `${d3.event.pageX}px`)
          .style('top', `${d3.event.pageY - 28}px`);
      })
      .on('mousemove', () => div.style('top', `${event.pageY - 10}px`).style('left', `${event.pageX + 10}px`))
      .on('mouseout', function () {
        d3.select(this).style('opacity', '1')
          .style('stroke', 'transparent');
        div.transition()
          .duration(chartAnimationAltDuration)
          .style('opacity', 0);
      })
      .attr('y', (d, i) => {
        if (i === 0) {
          j += 1;
        }
        return ((Math.floor(i / maxColumns)) * rowMarginGap) + j * dotSize +
          (Math.floor(i / maxColumns) * dotSize * dataCountRows);
      })
      .transition()
      .duration(chartAnimationDefaultDuration)
      .attr('fill', (d, i) => {
        if (i === 0) {
          j1 += 1;
        }
        return getColor(d, j1, json);
      })
      .attr('x', (d, i) => Math.floor(i % chartCols) * dotSize);

    rowcols.exit()
      .transition()
      .duration(chartAnimationAltDuration)
      .attr('x', 0)
      .remove();

    if (repaintAll) { // In case a new size cell is detected, we need to refresh all
      rowcols
        .attr('width', dotSize - dotMargin)
        .attr('height', dotSize - dotMargin)
        .attr('rx', dotEdgeCurve)
        .attr('ry', dotEdgeCurve);
    }

    rowbar.exit()
      .transition()
      .selectAll('rect')
      .duration(chartAnimationDefaultDuration)
      .attr('x', 0)
      .remove();

    d3.select(window).on('resize', ResizeChart);

    // Window resized, redraw graph
    function ResizeChart() {
      const winwidth = document.getElementById('content').getBoundingClientRect().width;
      width = winwidth - margin.left - margin.right - leftMarginDelta;
      maxColumns = Math.floor(width / (dotSize + dotMargin));
      chartRows = Math.ceil(dataCountCols / maxColumns);
      chartCols = dataCountCols > maxColumns ? maxColumns : dataCountCols;
      labels = new Array(chartRows * dataCountRows);
      for (j = 0; j < chartRows; j++)
        for (let i = 0; i < dataCountRows; i++)
          labels[j * dataCountRows + i] = (dataCountRows === 1 && j > 0) ? '' : json.index[i];

      chartsvg
        .attr('width', width + margin.left + margin.right + leftMarginDelta)
        .transition()
        .duration(chartResizeDuration)
        .attr('height', dotSize * chartRows * dataCountRows + margin.top + margin.bottom + (chartRows * rowMarginGap));

      txtLabels =
        chart
          .selectAll('text')
          .data(labels);

      txtLabels
        .enter()
        .append('text')
        .attr('y', (d, i) => rowMarginGap * Math.floor(i / dataCountRows) + i * dotSize + dotSize / 2 + margin.top + 2)
        .attr('x', -leftMarginDelta)
        .text(d => d)
        .interrupt()
        .transition()
        .delay(chartResizeDuration)
        .duration(chartAnimationDefaultDuration)
        .attr('x', margin.left - leftMarginDelta);

      txtLabels.exit()
        .interrupt()
        .transition()
        .duration(chartAnimationAltDuration)
        .attr('x', 0)
        .attr('opacity', 0)
        .remove();

      const chartrows = chart.selectAll('g').data(data)
        .selectAll('rect')
        .data(d => d);

      j = -1;
      chartrows // update to the new position
        .merge(chartrows)
        .interrupt()
        .transition()
        .duration(chartAnimationAltDuration)
        .ease(d3.easeBackOut)
        .attr('y', (d, i) => {
          if (i === 0) {
            j += 1;
          }
          return ((Math.floor(i / maxColumns)) * rowMarginGap) + j * dotSize +
            (Math.floor(i / maxColumns) * dotSize * dataCountRows);
        })
        .transition()
        .duration(chartAnimationDefaultDuration)
        .ease(d3.easeBounce)
        .attr('x', (d, i) => Math.floor(i % chartCols) * dotSize);
    }
  }
  render() {
    return React.DOM.svg({
      width: width + margin.left + margin.right,
    });
  }
}

HeatMapD3.propTypes = {
  jsondata: PropTypes.object.isRequired,
  rowfilter: PropTypes.array.isRequired,
};

export default HeatMapD3;
