var $  = require('jquery');
var common = common || {};
import moment from 'moment';
import * as d3 from 'd3';

//common ajax call to get json data
common.makeAjaxCall = function(obj) {
    var deferred = $.Deferred(); //Getting a deferred object
    var xhr = new XMLHttpRequest();
    var url = obj.url;
    var type = obj.type;
    var data = obj.data;
    //var headers = obj.headers;
    xhr.open(type, url, true);
    xhr.setRequestHeader('Accept', 'application/json');
    xhr.send(data);

    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
            if (xhr.status == 200)
                deferred.resolve(xhr.responseText); //Calling resolve() in case of success

            else
                deferred.reject(xhr.responseText); //Calling reject() in case of failure
        }
    }
    return deferred.promise(); //Returning the promise object
};

// Keys for redux actions / reducers to use when getting / retrieving values from storage
common.reduxStorageKeys = {
  autoRefreshEnabled: 'autoRefreshEnabled',
  menuAppNamesSelected: 'menuAppNamesSelected',
  menuWorkflowGroupsSelected: 'menuWorkflowGroupsSelected',
  menuTheme: 'menuTheme',
  menuTimeRange: 'menuTimeRange',
  menuCustomStartTime: 'menuCustomStartTime',
};

/***** messages *****/
common.messages = {
    "nodata": "No data available for selected time range.",
    "searchnodata": "No data available for search criteria.",
    "gettingdata": "Retrieving data...",
    "bothdates": "Please select both the dates",
    "wrongdates": "From date cannot be greater than To date"
};

// Event names for event handling
common.eventNames = {
  resetDashboardTileLayout: 'resetDashboardTileLayout',
  resizeChart: 'resizeChart',
  moveCrosshair: 'moveCrosshair',
  hideCrosshair: 'hideCrosshair',
};

// Takes a start time and an end time and builds a series of n time segments
common.buildTimeRange = function (startTime, endTime, segments) {
  let step = (endTime - startTime) / segments;

  return Array.from({length: segments}, (v, i) => ({
    startTime: moment(startTime).add(i * step),
    endTime: moment(startTime).add((i + 1) * step).subtract(i + 1 === segments ? 0 : 1, 'seconds')
  }));
};

/**
 * Determines an appropriate D3 interval function for use in an axis' ticks function
 * so that x-axis ticks are evenly spaced.
 * @param {number} axisWidth - The width in pixels of the x-axis of the chart
 * @param {Date} startTime - Start time of the chart's x-axis interval
 * @param {Date} endTime - End time of the chart's x-axis interval
 * @return {Function} A D3 interval function for use in in axis' ticks() function
 */
common.getXAxisTicks = function(axisWidth, startTime, endTime) {
  // Try to keep about 2x the text width between labels
  const tickTextMargin = 2;
  const tickTextWidth = 76;
  const scalingFactor = axisWidth / (tickTextWidth * tickTextMargin);

  const timeDifferenceMinutes = (endTime - startTime) / 1000 / 60;
  const timeDifferenceHours = timeDifferenceMinutes / 60;
  const timeDifferenceDays = timeDifferenceHours / 24;

  let ticks = 1;

  // Comparison values in if condition found through experimentation
  if (timeDifferenceMinutes <= 120) {
    // 120 minutes = two hours
    ticks = d3.timeMinute.every(Math.ceil(timeDifferenceMinutes / scalingFactor));
  } else if (timeDifferenceMinutes <= 2880) {
    // 2880 minutes = two days
    ticks = d3.timeHour.every(Math.ceil(timeDifferenceHours / scalingFactor));
  } else {
    ticks = d3.timeDay.every(Math.ceil(timeDifferenceDays / scalingFactor));
  }

  return ticks;
};

/**
 * Hides x-axis tick label text that overlaps another.
 * @param {element} container - DOM element that has the x-axis as a descendent
 */
common.hideOverlappingXAxisTicks = function(container) {
  try {
    const minimumPixelOffset = 10;
    const xAxis = container.getElementsByClassName('x axis')[0];
    const ticks = xAxis.getElementsByClassName('tick');
    let prev = ticks[0].getBoundingClientRect();

    for (let i = 1; i < ticks.length; i++) {
      let cur = ticks[i].getBoundingClientRect();

      if (cur.left < prev.right + minimumPixelOffset) {
        ticks[i].style.display = 'none';
      } else {
        prev = cur;
      }
    }
  } catch (ex) {
    console.error(ex);
  }
};

// Logic for consistent y-axis tick spacing
/**
 * Generate an array containing valid step values for y-axis tick marks
 */
function generateValidSteps() {
  let validSteps = [
    1,
    2,
    3,
    4,
    5,
    6,
    8,
  ];

  const stepFactors = [
    1,
    1.25,
    1.5,
    2,
    2.5,
    3,
    4,
    5,
    6,
    7,
    7.5,
    8,
    9,
  ];

  const base = 10;
  // https://www.youtube.com/watch?v=R2YiKCCDPmA
  const maxPower = 10;

  for (let power = 1; power < maxPower; power += 1) {
    const significantNumber = Math.pow(base, power);
    stepFactors.forEach(factor => {
      // Only add non-decimal numbers to the valid factors list
      if (significantNumber * factor % 1 === 0) {
        validSteps.push(significantNumber * factor);
      }
    });
  }

  // Ensure steps are sorted in ascending order
  return validSteps.sort((a, b) => a - b);
}

const validSteps = generateValidSteps();


/**
 * Determine a valid step value
 * @param {Number} step - Candidate step value
 * @return {Number} The smallest valid step that's greater than or equal to the candidate step value
 */
function getClosestValidStep(step) {
  let closest = validSteps[validSteps.length - 1];

  validSteps.forEach(value => {
    if (value >= step && value < closest) {
      closest = value;
    }
  });

  return closest;
}

/**
 * Generate an array of tick mark values for use by D3 axis logic
 * @param {Number} min - The baseline value in the domain
 * @param {Number} max - The maximum value in the domain
 * @param {Number} count - The maximum number of tick marks
 * @return {Array} An array of tick mark values
 */
common.generateYAxisTickValues = function(min, max, count) {
  let res = [];

  if (max < count) {
    // Add one to max here since the ticks start at zero.
    const len = Math.min(max + 1, count);
    res = Array.from({ length: len }, (v, tick) => tick);
  } else {
    const initialStep = Math.ceil((max - min) / (count - 1));
    const step = getClosestValidStep(initialStep);

    for (let tick = 0; tick < count; tick += 1) {
      res.push(tick * step + min);
    }
  }

  return res;
};

common.sortArrayOfObjectsByKey = function(array, key) {
  array.sort((a, b) => {
    const nameA = a[key].toUpperCase(); // ignore upper and lowercase
    const nameB = b[key].toUpperCase(); // ignore upper and lowercase
    if (nameA < nameB) return -1;
    if (nameA > nameB) return 1;
    return 0;
  });
};

common.colors = {
  tileHeader: '#f5f5f5',
  transactions: {
    line: '#00cceb',
    barColorRange: ['#dc2878'],
  },
  workflow: {
    line: '#4476A0',
    barColorRange: ['#F8B75F', '#6b486b', '#a05d56', '#ff8c00', '#98abc5', '#8a89a6', '#7b6888'],
  },
};

common.getIntersectionOfArrays = function(arrays) {
  return arrays.shift().filter(v => arrays.every(a => a.indexOf(v) !== -1));
};

/**
 * Check email to see if its valid or not
 */
common.isEmail = function(addr) {
    return /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i.test(addr);
};

module.exports = common;
