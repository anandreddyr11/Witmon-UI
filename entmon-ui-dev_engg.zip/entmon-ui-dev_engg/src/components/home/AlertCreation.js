import React from 'react';
import { connect } from 'react-redux';
import { buildQuery, processStatus } from 'grommet/utils/Rest';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import Box from 'grommet/components/Box';
import Spinning from 'grommet/components/icons/Spinning';
import Button from 'grommet/components/Button';
import AddIcon from 'grommet/components/icons/base/Add';
import EditIcon from 'grommet/components/icons/base/Edit';
import Layer from 'grommet/components/Layer';
import AddAlertForm from './AddAlertForm';
import FormPreviousIcon from 'grommet/components/icons/base/FormPrevious';
import Notification from 'grommet/components/Notification';
import Title from 'grommet/components/Title';

const common = require('./common.js');
const config = require(`../../../config.${process.env.NODE_ENV}.json`);
const DURATION = 'duration';
const COUNT = 'count';
const PATTERNMATCH = 'patternMatch';
const FREQUENCY = 'frequency';
const FREQUENCYCOUNT = 'frequencyCount';
const EDIT = 'edit';
const ADD = 'add';
const APPLICATION = 'Application';
const WORKFLOW = 'Workflow';
const WAIT_TO_LOAD_TABLE = 10000;

class AlertCreation extends React.Component {
  constructor(props) {
    super(props);
    this.addNewAlertButtonClickHandler = this.addNewAlertButtonClickHandler.bind(this);
    this.editButtonFormatter = this.editButtonFormatter.bind(this);
    this.getAlertDetails = this.getAlertDetails.bind(this);
    this.clickReturnToTable = this.clickReturnToTable.bind(this);
    this.closeButtonHandler = this.closeButtonHandler.bind(this);
    this.resetNotifications = this.resetNotifications.bind(this);
    this.renderShowsTotal = this.renderShowsTotal.bind(this);

    this.state = {
      showAddAlertModal: false,
      rowData: [],
      currentRowData: {},
      app_name: '',
      alert_name: '',
      showRowDetail: false,
      action: ADD,
      error: '',
      alertFormSuccess: '',
      alertFormError: '',
      updateTotalSize: true,
      totalSize: 0,
      searchSize: 0,
    };
  }

  componentWillMount() {
    this.getAlertDetails();
  }

  // Fetch the alert details and set success/error message.
  closeButtonHandler(error, successmessage) {
    this.setState({
      showAddAlertModal: false,
      alertFormSuccess: successmessage,
      alertFormError: error,
    });
    setTimeout(() => {
      this.getAlertDetails();
    }, WAIT_TO_LOAD_TABLE);
  }

  clickReturnToTable(e) {
    e.preventDefault();
    this.getAlertDetails();
    this.setState({
      showAddAlertModal: false,
    });
  }

  resetNotifications() {
    this.setState({
      alertFormError: '',
      alertFormSuccess: '',
    });
  }

  fetchDataForService(uri, alertCategory, callback) {
    fetch(uri)
      .then(processStatus)
      .then(response => response.json())
      .then(alertListForUser => {
        if (alertCategory === APPLICATION) {
          alertListForUser.map(elem => elem.alertCategory = APPLICATION);
          callback(null, alertListForUser);
        } else if (alertCategory === WORKFLOW) {
          alertListForUser.map(elem => elem.alertCategory = WORKFLOW);
          callback(null, alertListForUser);
        }
      })
      .catch(error => {
        console.error(error);
        this.setState({
          error: 'There is a problem in getting the alert details from the server. Please try again later !!',
          gettingData: false,
        });
      });
  }

  setStateVariablesHelper(self, mergedRecords) {
    self.setState({
      rowData: mergedRecords,
      gettingData: false,
      searchSize: mergedRecords.length,
    });
    if (this.state.updateTotalSize) {
      self.setState({
        totalSize: mergedRecords.length,
      });
    }
  }

  getAlertDetails() {
    this.setState({ gettingData: true });
    const props = this.props;

    const host = config.serverUrl;
    let endpoint;
    let query;

    const self = this;
    if (props.isFromChart) {
      let alertsForChartUri;
      if (props.alertCategory === APPLICATION) {
        endpoint = '/get-notification-details';
        query = buildQuery({
          user_email_id: props.userEmail,
          application_instance_id: props.applicationInstanceId,
          app_name: props.appName,
          api_name: props.applicationApiName,
        });
        alertsForChartUri = `${host}${endpoint}${query}`;
      } else if (props.alertCategory === WORKFLOW) {
        endpoint = '/workflowNotification';
        query = `/${props.userEmail}/${props.workflowName}`;
        alertsForChartUri = `${host}${endpoint}${query}`;
      }
      this.fetchDataForService(alertsForChartUri, props.alertCategory, (error, result) => {
        this.setStateVariablesHelper(self, result);
      });
    } else {
      query = props.userEmail;
      const fetchAllAppAlerts = '/notification/';
      const appAlertUri = `${host}${fetchAllAppAlerts}${query}`;
      let count = 2;
      let mergedRecords = [];
      this.fetchDataForService(appAlertUri, APPLICATION, (error, result) => {
        const currentRow = result;
        count = count - 1;
        currentRow.forEach(row => {
          let paramKeyValuesArray = [];
          if (row.app_name && row.api_name) {
            row.api_name_merged = row.app_name.concat('.', row.api_name);
          }
          if (row.api_name && row.application_consumer_id) {
            row.application_consumer_id_merged = row.api_name.concat('.', row.application_consumer_id);
          }
          paramKeyValuesArray = row.param_key_values.map(paramKeyVal => {
            if (paramKeyVal.alert_param_key && paramKeyVal.alert_param_value) {
              return paramKeyVal.alert_param_key.concat('=', paramKeyVal.alert_param_value);
            }
          });
          row.param_key_values_merged = paramKeyValuesArray.join(', ');
        });
        mergedRecords = mergedRecords.concat(currentRow);
        if (count === 0) {
          this.setStateVariablesHelper(self, mergedRecords);
        }
      });
      const fetchAllWfAlerts = '/workflowNotificationUser/';
      const wfAlertUri = `${host}${fetchAllWfAlerts}${query}`;
      this.fetchDataForService(wfAlertUri, WORKFLOW, (error, result) => {
        const currentRow = result;
        count = count - 1;
        currentRow.forEach(row => {
          let appApiArray = [];
          let apiConsumerIdArray = [];
          let paramKeyValuesArray = [];

          appApiArray = row.application_consumer_id.map(appConsumer => {
            return appConsumer.app_name.concat('.', appConsumer.api_name);
          });
          apiConsumerIdArray = row.application_consumer_id.map(appConsumer => {
            return appConsumer.api_name.concat('.', appConsumer.application_consumer_id);
          });
          paramKeyValuesArray = row.param_key_values.map(paramKeyVal => {
            if (paramKeyVal.alert_param_key && paramKeyVal.alert_param_value) {
              return paramKeyVal.alert_param_key.concat('=', paramKeyVal.alert_param_value);
            }
          });
          row.api_name_merged = appApiArray.join(', ');
          row.application_consumer_id_merged = apiConsumerIdArray.join(', ');
          row.param_key_values_merged = paramKeyValuesArray.join(', ');
        });
        mergedRecords = mergedRecords.concat(currentRow);
        if (count === 0) {
          this.setStateVariablesHelper(self, mergedRecords);
        }
      });
    }
  }

  addNewAlertButtonClickHandler(e) {
    e.preventDefault();
    this.setState({
      showAddAlertModal: true,
      action: ADD,
    });
  }

  getAddAlertModalRender() {
    let addAlertFormField = (<AddAlertForm
      action={ADD}
      closeButtonHandler={this.closeButtonHandler} />);

    if (this.state.action === EDIT) {
      addAlertFormField = (<AddAlertForm
        alertCategory={this.state.currentRowData.alertCategory}
        userEmail={this.state.currentRowData.userEmailId}
        notificationId={this.state.currentRowData.notificationId}
        appName={this.state.currentRowData.appName}
        applicationApiName={this.state.currentRowData.apiName}
        applicationInstanceId={this.state.currentRowData.applicationInstanceId}
        applicationConsumerId={this.state.currentRowData.applicationConsumerId}
        workflowName={this.state.currentRowData.workflowName}
        alertName={this.state.currentRowData.alertName}
        alertDescription={this.state.currentRowData.alertDescription}
        alertTypeSelection= {this.state.currentRowData.alertType}
        paramKeyValues={this.state.currentRowData.paramKeyValues}
        alertThresholdDuration= {this.state.currentRowData.alertThresholdDuration}
        alertThresholdCount= {this.state.currentRowData.alertThresholdCount}
        alertCriteriaPatternMatch= {this.state.currentRowData.alertCriteriaPatternMatch}
        minJobCountThForFrequency= {this.state.currentRowData.minJobCountThForFrequency}
        minJobCountThForFreqCount= {this.state.currentRowData.minJobCountThForFreqCount}
        timeRangeStart= {this.state.currentRowData.timeRangeStart}
        timeRangeEnd= {this.state.currentRowData.timeRangeEnd}
        alertComputationInterval= {this.state.currentRowData.frequency}
        notificationSuppressionDuration= {this.state.currentRowData.notificationSuppressionDuration}
        responseStatus={this.state.currentRowData.responseStatus}
        alertDistributionList= {this.state.currentRowData.alertDistributionList}
        alertEnable= {this.state.currentRowData.isEnabled}
        action= {this.state.action}
        closeButtonHandler={this.closeButtonHandler} />);
    }

    const props = this.props;
    if (props.isFromChart) {
      const boxElement = (
        <Box direction="row" responsive={false} full="horizontal" justify="end">
          <Button filter={{ type: 'TextFilter' }} className="mr-10" icon={<FormPreviousIcon />} label={'Return'}
            href={'#'} onClick={this.clickReturnToTable} />
        </Box>);

      if (this.state.action === ADD) {
        addAlertFormField = (<AddAlertForm
          userEmail={props.userEmail}
          appName={props.appName}
          workflowName={props.workflowName}
          applicationApiName={props.applicationApiName}
          applicationInstanceId={props.applicationInstanceId}
          userAction={props.userAction}
          action={ADD}
          closeButtonHandler={this.closeButtonHandler}
          isFromChart={props.isFromChart}
          alertCategory={props.alertCategory} />);
      }

      return (
        <div>
          {boxElement}
          {addAlertFormField}
        </div>);
    }

    if (this.state.showAddAlertModal) {
      const self = this;
      return (
        <Layer dataSort={true} filter={{ type: 'TextFilter' }} className="layer-style" closer={true} onClose={function onCloseHandler() {
          self.setState({ showAddAlertModal: false });
        }}>
          {addAlertFormField}
        </Layer>
      );
    }
    return null;
  }

  editButtonFormatter(cell, row) {
    const self = this;
    return (<Button filter={{ type: 'TextFilter' }} icon={<EditIcon />} label="Edit" href={'#/AlertCreation'} className="mr-10"
      onClick={function editActionHandler(e) {
        e.preventDefault();
        const currentRowData = {
          notificationId: row.notification_id,
          alertCategory: row.alertCategory,
          workflowName: row.workflow_name,
          appName: row.app_name,
          apiName: row.api_name,
          applicationInstanceId: row.application_instance_id,
          alertName: row.alert_name,
          alertDescription: row.alert_description,
          alertType: row.alert_type,
          isEnabled: row.is_enabled,
          alertDistributionList: row.notification_email_id,
          userEmailId: row.user_email_id,
          applicationConsumerId: row.application_consumer_id_merged,
          responseStatus: row.response_status,
          paramKeyValues: row.param_key_values_merged,
        };

        const alertType = currentRowData.alertType;
        if (alertType === DURATION) {
          currentRowData.alertThresholdDuration = row.event_criteria_duration;
          currentRowData.frequency = row.frequency;
        } else if (alertType === COUNT) {
          currentRowData.alertThresholdCount = row.event_criteria_trans_count;
          currentRowData.frequency = row.frequency;
        } else if (alertType === PATTERNMATCH) {
          currentRowData.alertCriteriaPatternMatch = row.event_criteria_text;
        } else if (alertType === FREQUENCY) {
          currentRowData.minJobCountThForFrequency = row.event_threshold_job_count;
          currentRowData.frequency = row.criteria_frequency;
        } else if (alertType === FREQUENCYCOUNT) {
          currentRowData.minJobCountThForFreqCount = row.event_criteria_trans_count;
          currentRowData.timeRangeStart = row.timerange_start;
          currentRowData.timeRangeEnd = row.timerange_end;
        }

        if (alertType !== PATTERNMATCH) {
          currentRowData.notificationSuppressionDuration = row.notification_suppression_duration;
        }
        self.setState({
          showAddAlertModal: true,
          action: EDIT,
          currentRowData,
        });
      }} />);
  }

  renderShowsTotal(start, to) {
    const message = `Showing ${start} to ${to} of ${this.state.searchSize} (filtered from ${this.state.totalSize} entries)`;
    return (
      <p>
        <strong>{message}</strong>
      </p>
    );
  }

  render() {
    let dataText;
    if (this.state.gettingData) {
      dataText = common.messages.gettingdata;
    } else {
      if (this.state.error === '') {
        dataText = common.messages.searchnodata;
      } else {
        dataText = this.state.error;
      }
    }

    let errorNotifications;
    if (this.state.alertFormError) {
      errorNotifications = (<div>
        <Notification status="critical" message={this.state.alertFormError} closer="true" onClose={this.resetNotifications} />
      </div>);
    }

    let successNotification;
    if (this.state.alertFormSuccess) {
      successNotification = (<div>
        <Notification status="ok" message={this.state.alertFormSuccess} closer="true" onClose={this.resetNotifications} />
      </div>);
    }

    const options = {
      page: 1, // Page you want to show as default
      sizePerPageList: [
        { text: '10', value: 10 },
        { text: '25', value: 25 },
        { text: '30', value: 30 },
        { text: '50', value: 50 },
      ], // Dropdown list values
      sizePerPage: 10, // which size per page you want to display as default
      pageStartIndex: 1, // where to start counting the pages
      paginationSize: 5, // the pagination bar size
      prePage: 'Prev', // Previous page button text
      nextPage: 'Next', // Next page button text
      firstPage: 'First', // First page button text
      lastPage: 'Last', // Last page button text
      noDataText: dataText, // Text for empty table or error scenario
      paginationShowsTotal: this.renderShowsTotal,
    };
    const { isFromChart, alertCategory, applicationApiName, workflowName } = this.props;
    let alertTitle;
    if (alertCategory === APPLICATION) {
      alertTitle = applicationApiName;
    } else if (alertCategory === WORKFLOW) {
      alertTitle = workflowName;
    }
    let titleForAlertLayerFromChart = '';
    if (isFromChart) {
      titleForAlertLayerFromChart = (<Title pad="small">Alert for - {alertTitle} ({alertCategory}) </Title>);
    }

    const rowData = this.state.rowData;
    const menuAppNamesSelected = this.props.menuAppNamesSelected;
    const menuAppnames = this.props.menuAppnames;
    const search = menuAppnames.filter((task, index) => menuAppNamesSelected[index] === true);

    let filteredData;
    if (search.length === menuAppnames.length) {
      filteredData = rowData;
      for (let n = 0; n < filteredData.length; n++) {
        if (filteredData[n].criteria_frequency !== undefined && filteredData[n].frequency === undefined) {
          filteredData[n].frequency = filteredData[n].criteria_frequency;
        } else {
          filteredData[n].frequency;
          filteredData[n].criteria_frequency;
        }
      }
    } else if (search.length !== 0) {
      filteredData = rowData.filter(task => {
        return search.filter((item) => item.appName === task.app_name).length !== 0;
      });
    } else {
      filteredData = [];
    }

    return (
      <div filter={{ type: 'TextFilter' }} className="alert-maindiv">
        <div className="alert-middlebar" hidden={isFromChart} />
        <div filter={{ type: 'TextFilter' }} className="alertmain-rightcontent">
          <div className="bottomPadding">
            {errorNotifications}
            {successNotification}
          </div>
          <div hidden={!this.state.showAddAlertModal}>
            {this.getAddAlertModalRender()}
          </div>
          <div hidden={this.state.showAddAlertModal}>
            <Box direction="row" responsive={false} full="horizontal" justify="start" className="newalert">
              <Button filter={{ type: 'TextFilter' }} className="mr-10" icon={<AddIcon />} label={'Add a new Alert'}
                href={'#'} onClick={this.addNewAlertButtonClickHandler} />
            </Box>
            <div className="bt-none">
              {titleForAlertLayerFromChart}
              <Box direction="row" full="horizontal" justify="end" pad={{ horizontal: 'medium' }}>
                <Spinning style={{ display: this.state.gettingData ? '' : 'none', position: 'relative', left: '-550px' }} />
              </Box>
              <BootstrapTable data={filteredData} bordered={true} condensed={true}
                search={true} searchPlaceholder="Search All Columns" multiColumnSearch={true}
                striped={true} hover={true} pagination={true} options={options} >
                <TableHeaderColumn dataField="action" dataAlign="center" headerAlign="center"
                  width="100" dataFormat={this.editButtonFormatter}>Action (Edit)
                </TableHeaderColumn>
                <TableHeaderColumn dataField="alertCategory" isKey={true} dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="100">Category</TableHeaderColumn>
                <TableHeaderColumn dataField="application_consumer_id_merged" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="200">Application Consumer ID</TableHeaderColumn>
                <TableHeaderColumn dataField="api_name_merged" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="200">API</TableHeaderColumn>
                <TableHeaderColumn dataField="alert_name" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="180">Name</TableHeaderColumn>
                <TableHeaderColumn dataField="alert_description" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="180">Description</TableHeaderColumn>
                <TableHeaderColumn dataField="alert_type" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="80">Type</TableHeaderColumn>
                <TableHeaderColumn dataField="event_criteria_duration" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="120">Duration (ms)</TableHeaderColumn>
                <TableHeaderColumn dataField="event_criteria_trans_count"
                  dataAlign="center" headerAlign="center" dataSort={true}
                  filter={{ type: 'TextFilter' }} className="ClickableExpandableColumn"
                  columnClassName="ClickableExpandableColumn" width="80">Count
                </TableHeaderColumn>
                <TableHeaderColumn dataField="event_criteria_text" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="100">Pattern</TableHeaderColumn>
                <TableHeaderColumn dataField="event_threshold_job_count"
                  dataAlign="center" headerAlign="center" dataSort={true}
                  filter={{ type: 'TextFilter' }} className="ClickableExpandableColumn"
                  columnClassName="ClickableExpandableColumn" width="150">Minimum job count
                </TableHeaderColumn>
                <TableHeaderColumn dataField="timerange_start" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="100">StartTime</TableHeaderColumn>
                <TableHeaderColumn dataField="timerange_end" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="100">EndTime</TableHeaderColumn>
                <TableHeaderColumn dataField="frequency" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="170">Computation Freq(m)</TableHeaderColumn>
                <TableHeaderColumn dataField="notification_suppression_duration" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="150">Notification Freq(m)</TableHeaderColumn>
                <TableHeaderColumn dataField="is_enabled" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="80">Enabled</TableHeaderColumn>
                <TableHeaderColumn dataField="param_key_values_merged" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="200">Request/Response Criteria</TableHeaderColumn>
                <TableHeaderColumn dataField="response_status" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="130">Response Status</TableHeaderColumn>
                <TableHeaderColumn dataField="notification_email_id" dataAlign="center"
                  headerAlign="center" dataSort={true} filter={{ type: 'TextFilter' }}
                  className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn"
                  width="200">Email(s)</TableHeaderColumn>
              </BootstrapTable>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

AlertCreation.propTypes = {
  isFromChart: React.PropTypes.bool,
  appName: React.PropTypes.string,
  applicationApiName: React.PropTypes.string,
  userEmail: React.PropTypes.string,
  applicationInstanceId: React.PropTypes.string,
  alertCategory: React.PropTypes.string,
  userAction: React.PropTypes.string,
  workflowName: React.PropTypes.string,
  menuOptions: React.PropTypes.object.isRequired,
  menuAppNamesSelected: React.PropTypes.array.isRequired,
  menuAppnames: React.PropTypes.array.isRequired,
};

const mapStateToProps = state => ({
  userEmail: state.userProfile.email,
  menuOptions: state.menuOptions,
  menuAppnames: state.menuAppnames,
  menuAppNamesSelected: state.menuAppNamesSelected,
});

export default connect(mapStateToProps)(AlertCreation);


