import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { processLogin, processLogout, loginProcessComplete } from '../../actions/user';
import { dashboardAppsSet } from '../../actions/dashboard';

import UserIcon from 'grommet/components/icons/base/User';
import LoginIcon from 'grommet/components/icons/base/Login';
import LogoutIcon from 'grommet/components/icons/base/Logout';
import UserAddIcon from 'grommet/components/icons/base/UserAdd';
import NotificationIcon from 'grommet/components/icons/base/Notification';
import Button from 'grommet/components/Button';
import Menu from 'grommet/components/Menu';
import List from 'grommet/components/List';
import ListItem from 'grommet/components/ListItem';
import Layer from 'grommet/components/Layer';
import SubscriptionForm from './SubscriptionForm';

const Config = require(`../../../config.${process.env.NODE_ENV}.json`);

class UserProfileMenu extends React.Component {
  static contextTypes() {
    return {
      router: PropTypes.object.isRequired,
    };
  }
  constructor(props){
    super(props);
    this.state={
        layerActiveStatus: false
    };
    this.onClickLayer = this.onClickLayer.bind(this);
    this.onClickNotification = this.onClickNotification.bind(this);
  }

  componentWillMount() {
    /** Load session info when user hard reloads browser page  */
    if (!this.props.userProfile.loggedin && !this.props.loginProcessing && !this.props.loginErrored.hasErrored) {
      let userProfileRespTxt = sessionStorage.getItem("UserProfileRespTxt");
      if (userProfileRespTxt)
        this.props.loginProcessComplete(JSON.parse(userProfileRespTxt));
      else
        this.checkSessionRedirect(this.props);
    }
  }

  componentWillUpdate(nextProps) {
    this.checkSessionRedirect(nextProps);
  }

  onClickLayer(){
    this.setState({layerActiveStatus:true});
  }

  onClickNotification(){
    this.context.router.push({
        pathname: '/AlertCreation',
      });
  }

  checkSessionRedirect(props) {
    // Logic to redirect back to login screen is no session info found
    if (!props.userProfile.loggedin && props.loginProcessing) // no need to continue if login is processing now
      return;
    let currentLoc = window.location.href;
    if (currentLoc.indexOf("/#/?") > 0 || currentLoc.indexOf("/#/logincomplete?") > 0) // we are already on login screen or login processing screen, so no action needed
      return;
    if (currentLoc.indexOf("/#/Registration") > 0 ){
      return;
    }
    if (!props.userProfile.loggedin || props.loginErrored.hasErrored) { // No session & not on the interim or login page, go to login page!
      this.context.router.push({
        pathname: '/',
        query: { parent: window.location.href }
      });
    }
  }

  render() {
    if (!this.props.userProfile.loggedin && this.props.loginProcessing) {
      //console.log("Login processing");
      return (<span>
        <Button icon={<LoginIcon />}
          label="Please Wait..."
          plain={true} />
      </span>
      );
    }
    if (!this.props.userProfile.loggedin || this.props.loginErrored.hasErrored) {
      return (
        window.location.href.indexOf("/#/?") > 0 ? // Check to see of we are on the main login screen
          null :  //If yes, do not render the top right hand menu (as we already have a login button on main window)
          <Button icon={<LoginIcon />}
            label="Login"
            onClick={() => window.location = `${Config.serverUrl}/login?parent=${encodeURIComponent(window.location.href)}`}
            plain={true} />);
    }
    const layer = (this.state.layerActiveStatus)
     ? (<Layer className="layer-style" closer={true} onClose={()=>{this.setState({layerActiveStatus:false});}}>
    <SubscriptionForm/>
    </Layer>)
    : null;
    return (
      <div>
        <Menu
          icon={<UserIcon />}
          label={this.props.userProfile.lname + ", " + this.props.userProfile.fname}
          inline={false}
          primary={true}>
          <List>
            <ListItem justify="between">
              <Button icon={<NotificationIcon />}
                label="Alerts"
                plain={true}
                onClick={this.onClickNotification}/>
            </ListItem>
            <ListItem justify="between">
              <Button icon={<UserAddIcon />}
                label="Add a User to your app group"
                plain={true}
                onClick={this.onClickLayer}/>
            </ListItem>
            <ListItem justify="between">
              <Button icon={<LogoutIcon />}
                label="Logout"
                onClick={() => {
                  this.props.dashboardAppsSet([]);
                  this.props.processLogout(this.props.userProfile);
                }}
                plain={true} />
            </ListItem>
          </List>
        </Menu>
        {layer}
      </div>
    );
  }
}

UserProfileMenu.propTypes = {
  dashboardAppsSet: PropTypes.func.isRequired,
  processLogin: PropTypes.func.isRequired,
  processLogout: PropTypes.func.isRequired,
  loginProcessComplete: PropTypes.func.isRequired,
  userProfile: PropTypes.object.isRequired,
  loginErrored: PropTypes.object,
  loginProcessing: PropTypes.bool.isRequired,
};

UserProfileMenu.contextTypes = {
  router: React.PropTypes.object.isRequired,
};

const mapStateToProps = state => ({
  userProfile: state.userProfile,
  loginErrored: state.loginErrored,
  loginProcessing: state.loginIsProcessing,
});

const mapDispatchToProps = dispatch => ({
  dashboardAppsSet: array => dispatch(dashboardAppsSet(array)),
  processLogin: token => dispatch(processLogin(token)),
  processLogout: user => dispatch(processLogout(user)),
  loginProcessComplete: user => dispatch(loginProcessComplete(user)),
});

export default connect(mapStateToProps, mapDispatchToProps)(UserProfileMenu);
