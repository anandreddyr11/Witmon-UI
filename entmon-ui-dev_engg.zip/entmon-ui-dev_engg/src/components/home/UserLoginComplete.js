import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { processLogin, processLogout } from '../../actions/user';
import Notification from 'grommet/components/Notification';

let redirectparam = "";

/**
 * SAML Login entry point after successful login.
 */
class UserLoginComplete extends React.Component {
  static contextTypes() {
    return {
      router: PropTypes.object.isRequired,
    };
  }
  componentDidMount() {
    let token = decodeURIComponent(location.hash.split('token=')[1]);
    redirectparam = decodeURIComponent(location.hash.split('parent=')[1]);
    if (redirectparam) {
      redirectparam = redirectparam.split('&token=')[0];
      if (redirectparam) {
        let param = redirectparam.replace('#/', '/').split('?');
        redirectparam = param[0];
        if (redirectparam.lastIndexOf('/Registration', 0) === 0)
          redirectparam += `?${param[1]}`;
      }
    }
    else
      redirectparam = "/";
      if (redirectparam.lastIndexOf('/logincomplete', 0) === 0)
        redirectparam = "/";
      this.props.processLogin(token);
  }

  render() {
    if (!this.props.userProfile.loggedin && this.props.loginProcessing) {
      return (
        <Notification status="disabled"
          message="Please wait for login to process"
          timestamp={new Date()} />
      );
    }
    if (!this.props.userProfile.loggedin && this.props.loginErrored.hasErrored) {
      return (
        <Notification status="Critical"
          message={this.props.loginErrored.errorText}
          timestamp={new Date()} />
      );
    }
    if (this.props.userProfile.loggedin) {
      this.context.router.push(redirectparam);
    }
    return (
      <div>
        <Notification status="disabled"
          message="You will be redirected shortly. If seeing this message for a long time, please use links below to navigate"
          timestamp={new Date()} /> <br />
        <a href={redirectparam}>Redirect</a>&nbsp;
                <a href="/#/TxnDashboard">Dashboard</a>
      </div>
    );
  }
}

UserLoginComplete.propTypes = {
  processLogin: PropTypes.func.isRequired,
  processLogout: PropTypes.func.isRequired,
  userProfile: PropTypes.object.isRequired,
  loginErrored: PropTypes.object,
  loginProcessing: PropTypes.bool.isRequired
};

UserLoginComplete.contextTypes = {
  router: React.PropTypes.object.isRequired
};

const mapStateToProps = (state) => {
  return {
    userProfile: state.userProfile,
    loginErrored: state.loginErrored,
    loginProcessing: state.loginIsProcessing
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    processLogin: (token) => dispatch(processLogin(token)),
    processLogout: (user) => dispatch(processLogout(user))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(UserLoginComplete);
