import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import {
  menuShowAppnamesSet,
  menuShowTimeRangeSet,
} from '../../actions/menu';
import moment from 'moment';

import HeatMapD3 from '../home/HeatMapD3';
import CheckBox from 'grommet/components/CheckBox';
import Box from 'grommet/components/Box';
import NumberInput from 'grommet/components/NumberInput';
import Notification from 'grommet/components/Notification';
import Animate from 'grommet/components/Animate';
import Label from 'grommet/components/Label';
import Spinning from 'grommet/components/icons/Spinning';
import AppsIcon from 'grommet/components/icons/base/Apps';
import Menu from 'grommet/components/Menu';
import List from 'grommet/components/List';
import ListItem from 'grommet/components/ListItem';

const common = require('../home/common.js');
const Config = require('Config');
const dateFormat = 'YYYY-MM-DD HH:mm:ss';

const defaultDemoDataSize = 510;
const filterLastMinsMIN = 1;
const filterLastMinsMAX = 44640;

const dataIndex =
  {
    cpu: 0,
    mem: 1,
    conn: 2,
    appName: 3,
    reportTime: 4,
  };

const filterOptions = { cpu: 0, mem: 1, conn: 2, demo: 3 };

class HeatMap extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      jsondata: {
        columns: [],
        index: ['cpu', 'mem', 'conn', 'appname', 'report_time'],
        threshholds: [
          ['40', '20'], // Demo thresholds
          ['60', '40'],
          ['3000', '2000'],
        ],
        data: [[], [], [], [], []],
        generated_time: '',
      },
      rowfilter: [1, 1, 1],
      jsonDataSize: defaultDemoDataSize,
      filterLastNumMins: 5,
      selectedAppNames: ['All Apps'],
      restCallErrMsg: null,
      restCallInProgress: false,
      showDemoData: false,
      showDemoDataCountInput: false,
    };

    this.populateData = this.populateData.bind(this);
    this.showData = this.showData.bind(this);
    this.rePopulateData = this.rePopulateData.bind(this);
    this.getFilteredData = this.getFilteredData.bind(this);
    this.updateDataSize = this.updateDataSize.bind(this);
    this.handleChkBox = this.handleChkBox.bind(this);
    this.handleAppCheckBox = this.handleAppCheckBox.bind(this);
    this.handleFilterMinsChanged = this.handleFilterMinsChanged.bind(this);
    this.getAppLabel = this.getAppLabel.bind(this);
    this.getHeatmapDataFromServer = this.getHeatmapDataFromServer.bind(this);
    this.allAppNames = [];
    // Map these to rows (ex: cpu, mem, conn) and detemine
    // if a metric row will display or not? 1=show, 0 dont show
    this.showRowFilter = [...this.state.rowfilter];
    // store data; from rest call or randomized demo data
    this.jsondata = this.state.jsondata;
  }

  componentDidMount() {
    this.populateData();
    this.props.menuShowTimeRangeSet(false);
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.menuRefreshNow !== nextProps.menuRefreshNow)
      this.populateData();
  }

  componentWillUnmount() {
    this.props.menuShowTimeRangeSet(true);
  }

  showData() {
    this.setState({
      jsondata: this.jsondata,
      rowfilter: this.showRowFilter,
      jsonDataSize: this.jsondata.columns.length,
    });
  }

  populateData() {
    if (this.state.showDemoData) {
      this.jsondata.columns = Array(this.state.jsonDataSize);
      this.jsondata.data[dataIndex.cpu] = Array(this.state.jsonDataSize);
      this.jsondata.data[dataIndex.mem] = Array(this.state.jsonDataSize);
      this.jsondata.data[dataIndex.conn] = Array(this.state.jsonDataSize);

      for (let i = 0; i < this.state.jsonDataSize; i++) {
        this.jsondata.columns[i] = `node${i}`;
        // 1 in 10 is null
        this.jsondata.data[dataIndex.cpu][i] = Math.floor(
          (Math.random() * 10) + 1) === 1 ? null : Math.floor(Math.random() * 50) + 1;
        this.jsondata.data[dataIndex.mem][i] = Math.floor(
          (Math.random() * 10) + 1) === 1 ? null : Math.floor(Math.random() * 70) + 1;
        this.jsondata.data[dataIndex.conn][i] = Math.floor(
          (Math.random() * 10) + 1) === 1 ? null : Math.floor(Math.random() * 3500) + 1;
        this.jsondata.data[dataIndex.appName][i] = `App name #${Math.floor(Math.random() * this.state.jsonDataSize / 2)}`;
        this.jsondata.data[dataIndex.reportTime][i] = moment().subtract(Math.floor(Math.random() * 60 * 60) + 1, 'seconds')
          .utc()
          .format();
      }
      this.allAppNames = ['All Apps', ...new Set(this.jsondata.data[dataIndex.appName])];
      this.showData();
    } else
      this.getHeatmapDataFromServer();
  }

  rePopulateData(newSize) {
    let delta = this.jsondata.columns.length - newSize;
    let i = this.jsondata.columns.length;

    if (delta > 0) {
      this.jsondata.columns.length = newSize;
      this.jsondata.data[dataIndex.cpu].length = newSize;
      this.jsondata.data[dataIndex.mem].length = newSize;
      this.jsondata.data[dataIndex.conn].length = newSize;
    } else {
      while (delta < 0) {
        this.jsondata.columns.push(`node${i}`);
        this.jsondata.data[dataIndex.cpu].push(
          Math.floor((Math.random() * 10) + 1) === 1 ? null : Math.floor(Math.random() * 50) + 1);
        this.jsondata.data[dataIndex.mem].push(
          Math.floor((Math.random() * 10) + 1) === 1 ? null : Math.floor(Math.random() * 70) + 1);
        this.jsondata.data[dataIndex.conn].push(
          Math.floor((Math.random() * 10) + 1) === 1 ? null : Math.floor(Math.random() * 4000) + 1);
        this.jsondata.data[dataIndex.appName].push(`App name #${Math.floor(Math.random() * this.state.jsonDataSize / 2)}`);
        this.jsondata.data[dataIndex.reportTime].push(
          moment().subtract(Math.floor(Math.random() * 60 * 60) + 1, 'seconds')
            .utc()
            .format());
        i += 1;
        delta += 1;
      }
    }
    this.allAppNames = ['All Apps', ...new Set(this.jsondata.data[dataIndex.appName])];
  }

  updateDataSize(event) {
    const datasize = event.target.value;
    this.rePopulateData(datasize);
    this.showData();
  }

  getFilteredData() {
    let filteredJSON;
    if (this.state.selectedAppNames.length === 0) { // nothing selected
      filteredJSON = {
        columns: [],
      };
    } else {
      filteredJSON = { // Copy current data
        columns: [...this.jsondata.columns],
        index: this.jsondata.index,
        threshholds: this.jsondata.threshholds,
        data: [
          [...this.jsondata.data[dataIndex.cpu]],
          [...this.jsondata.data[dataIndex.mem]],
          [...this.jsondata.data[dataIndex.conn]],
          [...this.jsondata.data[dataIndex.appName]],
          [...this.jsondata.data[dataIndex.reportTime]],
        ],
        generated_time: this.jsondata.generated_time,
      };
      if (!this.state.selectedAppNames.includes('All Apps')) { // if 'All Apps' present, no need to filter further
        const appNamesToFilterOut = this.allAppNames
          .filter(x => this.state.selectedAppNames.indexOf(x) === -1); // apps not needed
        appNamesToFilterOut.splice(0, 1); // remove 'All Apps' from list

        for (let i = this.jsondata.data[dataIndex.appName].length - 1; i >= 0; i--) {
          if (appNamesToFilterOut.includes(this.jsondata.data[dataIndex.appName][i])) {
            filteredJSON.columns.splice(i, 1);
            filteredJSON.data[dataIndex.cpu].splice(i, 1);
            filteredJSON.data[dataIndex.mem].splice(i, 1);
            filteredJSON.data[dataIndex.conn].splice(i, 1);
            filteredJSON.data[dataIndex.appName].splice(i, 1);
            filteredJSON.data[dataIndex.reportTime].splice(i, 1);
          }
        }
      }
    }
    // filter based on time picked
    if (filteredJSON.columns.length > 0) {
      const dateDataGenerated = moment(filteredJSON.generated_time);
      for (let i = 0; i < filteredJSON.columns.length; i++) {
        if (dateDataGenerated.diff(moment(filteredJSON.data[dataIndex.reportTime][i]), 'minutes') >
          this.state.filterLastNumMins) {
          filteredJSON.data[dataIndex.cpu][i] = null;
          filteredJSON.data[dataIndex.mem][i] = null;
          filteredJSON.data[dataIndex.conn][i] = null;
        }
      }
    }
    return filteredJSON;
  }

  handleChkBox(event) {
    let selected = 0;
    const chk = event.target;
    if (Number(chk.value) === filterOptions.demo) {
      this.setState({
        showDemoData: chk.checked,
        showDemoDataCountInput: chk.checked,
      });
      if (chk.checked) {
        this.setState({ jsonDataSize: defaultDemoDataSize, restCallErrMsg: null });
        this.rePopulateData(defaultDemoDataSize);
        this.showData();
      } else
        this.getHeatmapDataFromServer();
      return;
    }

    for (let i = filterOptions.cpu; i <= filterOptions.conn; i++)
      selected += this.showRowFilter[i];

    if (selected === 1 && !chk.checked)
      chk.checked = true;

    for (let i = filterOptions.cpu; i <= filterOptions.conn; i++)
      if (Number(chk.value) === i) this.showRowFilter[i] = chk.checked ? 1 : 0;

    this.showData();
  }

  getAppLabel() {
    switch (this.state.selectedAppNames.length) {
      case 0: return 'No Apps';
      case 1: return this.state.selectedAppNames[0];
      default: return 'Multiple Apps';
    }
  }

  handleFilterMinsChanged(event) {
    let newFilterMin = Number(event.target.value);
    if (newFilterMin < filterLastMinsMIN)
      newFilterMin = filterLastMinsMIN;
    else if (newFilterMin > filterLastMinsMAX)
      newFilterMin = filterLastMinsMAX;
    this.setState({ filterLastNumMins: newFilterMin });
    this.showData();
  }

  handleAppCheckBox(event) {
    const selectedIndex = Number(event.target.value);
    let appSelectedCopy = [];
    if (selectedIndex !== 0) { // Clicked something other than 'All Apps'
      if (this.state.selectedAppNames.includes('All Apps')) { // 'All apps' was checked (from last list of selections)
        appSelectedCopy = [...this.allAppNames]; // make a copy of all app names
        appSelectedCopy.splice(selectedIndex, 1); // remove user clicked menu option.
        appSelectedCopy.splice(0, 1); // Remove 'All Apps' at index 0 of copy
        // We now return all app names except 'All Apps' & user clicked
      } else {
        appSelectedCopy = [...this.state.selectedAppNames]; // current list of app names selected
        const index = appSelectedCopy.indexOf(this.allAppNames[selectedIndex]); // user clicked indx
        if (index > -1) // option was already selected
          appSelectedCopy.splice(index, 1); // remove it
        else
          appSelectedCopy.push(this.allAppNames[selectedIndex]); // add as newly selected
      }
      if (appSelectedCopy.length === this.allAppNames.length - 1)
        appSelectedCopy = ['All Apps']; // if all names are selected, we can return 'All Apps'
    } else  // 'All Apps' is clicked
      if (!this.state.selectedAppNames.includes('All Apps'))
        appSelectedCopy = ['All Apps']; // 'All Apps was unchecked, so now we are going to enable it

    this.setState({ selectedAppNames: appSelectedCopy }); // Saving the new selections
    this.showData();
  }

  getHeatmapDataFromServer() {
    const obj = {
      dataType: 'json',
      contentType: 'application/json; charset=utf-8',
      url: `${Config.serverUrl}/get-heatmap-data?user_email=${encodeURIComponent(this.props.userProfile.email)}`,
      type: 'GET',
    };
    this.setState({ restCallInProgress: true, restCallErrMsg: null });
    common.makeAjaxCall(obj)
      .then(response => {
        const dataReceived = JSON.parse(response);
        // sort the data as server data is not guaranteed to be sorted
        const sortIndex = [];
        // Populate sort index. Data will be sorted based on app name concatenated with nodeID
        dataReceived.data[dataIndex.appName].forEach(
          (value, index) => sortIndex.push([`${value} ${dataReceived.columns[index]}`, index]));
        sortIndex.sort((a, b) => a[0].localeCompare(b[0])); // do the sort
        const columnSorted = []; // init blank columns array
        const dataSorted = [[], [], [], [], []]; // init blank data array
        sortIndex.forEach(value => {
          columnSorted.push(dataReceived.columns[value[1]]);
          dataSorted[dataIndex.cpu].push(dataReceived.data[dataIndex.cpu][value[1]]);
          dataSorted[dataIndex.mem].push(dataReceived.data[dataIndex.mem][value[1]]);
          dataSorted[dataIndex.conn].push(dataReceived.data[dataIndex.conn][value[1]]);
          dataSorted[dataIndex.appName].push(dataReceived.data[dataIndex.appName][value[1]]);
          dataSorted[dataIndex.reportTime].push(dataReceived.data[dataIndex.reportTime][value[1]]);
        });
        dataReceived.columns = columnSorted;
        dataReceived.data = dataSorted;
        this.jsondata = dataReceived;
        this.allAppNames = ['All Apps', ...new Set(this.jsondata.data[dataIndex.appName])];
        this.showData();
        this.setState({ restCallInProgress: false });
      })
      .catch(err => {
        this.setState({
          restCallInProgress: false,
          restCallErrMsg: `Error getting data: ${err ? err.message : 'No further information availabe'}`,
        });
      });
  }

  render() {
    if (!this.props.userProfile.loggedin) {
      return (
        <Box align="start" pad="medium">
          Please login
        </Box>
      );
    }
    const appnamesList = [];
    const allAppsSelected = this.state.selectedAppNames.includes('All Apps');
    for (let i = 0; i < this.allAppNames.length; i++) {
      appnamesList.push(
        <ListItem justify="between" key={i}>
          <CheckBox
            id={this.allAppNames[i]}
            label={this.allAppNames[i]}
            value={i}
            checked={allAppsSelected ?
              true : this.state.selectedAppNames.includes(this.allAppNames[i])
            }
            onChange={this.handleAppCheckBox} />
        </ListItem>
      );
    }
    const dataToRender = this.getFilteredData();
    return (
      <div id="content">
        <Animate enter={{ animation: 'slide-right', duration: 500, delay: 0 }}
          leave={{ animation: 'slide-left', duration: 600, delay: 0 }} keep={true} visible={true}>
          <Box className="filter-containerdiv">
            <Box direction="row" style={{ borderTop: '1px solid #ddd' }}>
              <Box full="horizontal" direction="row">
                <Box direction="row" style={{ paddingTop: '5px' }}>
                  <Box pad={{ horizontal: 'medium' }} />
                  <CheckBox label="CPU" defaultChecked={true} value={filterOptions.cpu} onChange={this.handleChkBox} />
                  <CheckBox label="MEM" defaultChecked={true} value={filterOptions.mem} onChange={this.handleChkBox} />
                  <CheckBox label="CONN" defaultChecked={true} value={filterOptions.conn} onChange={this.handleChkBox} />
                </Box>
                <Animate enter={{ animation: 'slide-right', duration: 500, delay: 0 }}
                  leave={{ animation: 'slide-right', duration: 600, delay: 0 }}
                  keep={false} visible={appnamesList.length > 0}>
                  <Menu icon={<AppsIcon />} closeOnClick={false} label={this.getAppLabel()}>
                    <List selectable={true}>
                      {appnamesList}
                    </List>
                  </Menu>
                </Animate>
                <Box pad={{ horizontal: 'small' }} style={{ paddingTop: '5px' }}>Filter by</Box>
                <Box style={{ paddingTop: '5px' }}>
                  <input type="number"
                    value={this.state.filterLastNumMins}
                    min={filterLastMinsMIN}
                    max={filterLastMinsMAX}
                    style={{ width: '66px', padding: '2px' }}
                    onChange={this.handleFilterMinsChanged} />
                </Box>
                <Box pad={{ horizontal: 'small' }} style={{ paddingTop: '5px' }}>minutes</Box>
              </Box>
              <Box direction="row" full="horizontal" justify="end">
                <Box direction="row" style={{ paddingTop: '5px' }}>
                  <CheckBox label="Use Demo Data" defaultChecked={this.state.showDemoData} value={filterOptions.demo} onChange={this.handleChkBox} />
                </Box>
              </Box>
            </Box>
          </Box>
          <Animate enter={{ animation: 'slide-down', duration: 1000, delay: 0 }}
            leave={{ animation: 'slide-up', duration: 600, delay: 0 }}
            keep={false} visible={this.state.showDemoDataCountInput}>
            <Box full="horizontal" direction="row" align="center">
              <Box pad="small" />
              <NumberInput
                value={this.state.jsonDataSize} min={0} max={30000}
                onChange={this.updateDataSize} />
            </Box>
          </Animate>
        </Animate>
        <Animate enter={{ animation: 'slide-right', duration: 500, delay: 500 }}
          leave={{ animation: 'slide-right', duration: 600, delay: 0 }}
          keep={false} visible={!this.state.showDemoData && this.state.restCallErrMsg !== null}>
          <Box full="horizontal" direction="row" align="center">
            <Notification status="critical"
              message={this.state.restCallErrMsg ? this.state.restCallErrMsg : ''}
              timestamp={new Date()} />
          </Box>
        </Animate>
        <Box direction="row">
          {
            this.state.jsondata.generated_time ?
              <Box direction="row" full="horizontal">
                <Box pad={{ horizontal: 'large' }}>
                  <Label className="time-range-label">
                    <b>Last Refreshed: </b>{
                      moment(this.state.jsondata.generated_time).utc()
                        .format(dateFormat)} (Etc/UTC GMT +0)
                  </Label>
                </Box>
              </Box> : null
          }
          <Box direction="row" full="horizontal" justify="end" pad="small">
            <Animate enter={{ animation: 'fade', duration: 500, delay: 0 }}
              leave={{ animation: 'fade', duration: 500, delay: 0 }}
              keep={true} visible={this.state.restCallInProgress}>
              <Spinning size="small" />
            </Animate>
          </Box>
        </Box>
        <Animate enter={{ animation: 'slide-up', duration: 500, delay: 400 }}
          leave={{ animation: 'slide-down', duration: 600, delay: 0 }}
          keep={false}
          visible={this.state.restCallErrMsg === null && dataToRender.columns.length > 0}>
          <Box full="horizontal" direction="row" align="center" pad={{ horizontal: 'medium' }}>
            <HeatMapD3 jsondata={dataToRender} rowfilter={this.state.rowfilter} />
          </Box>
        </Animate>
        <Animate enter={{ animation: 'slide-up', duration: 500, delay: 400 }}
          leave={{ animation: 'slide-down', duration: 600, delay: 0 }}
          keep={false}
          visible={this.state.restCallErrMsg === null && dataToRender.columns.length === 0}>
          <div className="nodatadiv" style={{ marginTop: '0px' }}>
            No applications have been selected
          </div>
        </Animate>
      </div>
    );
  }
}

HeatMap.propTypes = {
  userProfile: PropTypes.object.isRequired,
  menuOptions: PropTypes.object.isRequired,
  menuRefreshNow: PropTypes.object.isRequired,
  menuShowTimeRangeSet: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  userProfile: state.userProfile,
  menuOptions: state.menuOptions,
  menuRefreshNow: state.menuRefreshNow,
});

const mapDispatchToProps = dispatch => ({
  menuShowAppnamesSet: bool => dispatch(menuShowAppnamesSet(bool)),
  menuShowTimeRangeSet: bool => dispatch(menuShowTimeRangeSet(bool)),
});

export default connect(mapStateToProps, mapDispatchToProps)(HeatMap);
