// (C) Copyright 2014-2016 Hewlett Packard Enterprise Development LP

/*
PageMill Sample Application

This is the PageMill "shell" application. This can be used either to start an application or simply as reference
for using the HPE IT Millstone ReactJS components.

Header, Footer and Primary Navigation is provided by PageMill. The <AppWrap> component is
responsible for rendering all this on the web page.

The links to display in the Primary Navigation are passed into AppWrap. The React components passed in
as "menuItems" are then used to populate the navigation menu.

Grommet components are utilized and installed with this application.

This sample application also makes use of react-router (https://github.com/reactjs/react-router) to simplify the
navigation between multiple application pages. However, it is not mandatory that you use react-router with
the sample application components.

Redux files are included but not currently being used. They must be configured if desired.
*/

// React Components
import React, { PropTypes } from 'react';
import ReactDOM from 'react-dom';
//Redux store for the application
import { Provider } from 'react-redux';
import configureStore from '../../store/configureStore';
const store = configureStore();
import UserProfileMenu from './UserProfileMenu';
import ErrorNotifications from '../ErrorNotifications';
import TopMenuBar from './TopMenuBar';

require("!style!css!../../styles/main.css");

// React-router Components
//import { Link } from 'react-router';

// Available Themed Layouts (pick *ONE*)
//---------------------------------------------------------------------------------------------------------------------------
// Internal Branding
//import AppWrap from '@hpe/millstone/components/internal/sidebar/AppWrap';
import AppWrap from '@hpe/millstone/components/internal/nosidebar/AppWrap';
//import AppWrap from '@hpe/millstone/components/internal/fixedsidebar/AppWrap';
//---------------------------------------------------------------------------------------------------------------------------
// External Branding
//import AppWrap from '@hpe/millstone/components/external/sidebar/AppWrap';
//import AppWrap from '@hpe/millstone/components/external/nosidebar/AppWrap';
//import AppWrap from '@hpe/millstone/components/external/fixedsidebar/AppWrap';

//---------------------------------------------------------------------------------------------------------------------------
// Sample Application Shell
//
// This is an example application
//

class AppHome extends React.Component {

  constructor(props) {
    super(props);
    this.handleScroll = this.handleScroll.bind(this);
  }

  componentDidMount() {
    window.addEventListener('scroll', this.handleScroll);
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
  }

  handleScroll(event) {
    let scrollTop = event.srcElement.body.scrollTop;
    let node = ReactDOM.findDOMNode(this.refs.filterContainer);
    if (scrollTop > 78) {
      node.classList.add('filtercontainer-fixed');
    } else {
      node.classList.remove('filtercontainer-fixed');
    }
  }


  //------------------------------------------------------------------------------------------------------------------------------------
  // Function to populate array of Navigation links to pass to AppWrap
  setMenuItems() {
    let menuItems = [];

    //----------------
    // Example 1: Manually assign Menu Items

    // menuItems.push(<Link key="0" to="dashboard" activeClassName="active">Dashboard</Link>);	// example react-router link (app navigation)
    // menuItems.push(<Link key="1" to="page2" activeClassName="active">Page 2</Link>);
    // menuItems.push(<Link key="2" to="page3" activeClassName="active">Page 3</Link>);

    // You can add anchors to URLs outside of your application too
    //menuItems.push(<Anchor key="3" href="http://www.hpe.com/" target="blank">Hewlett Packard Enterprise</Anchor>);	// example Grommet anchor

    //----------------
    // Example 2: Assemble Menu Items retrieved from a web service
    //
    //	// Retrieve JSON object "jsonMenu" via REST call
    //	// e.g.:  [ {"href" : "http:///www.hpe.com/", "text" : "Hewlett Packard Enterprise"}  ]
    //
    //	for (var i=0; i < jsonMenu.length; i++)  {
    //			menuItems.push(<Anchor href={jsonMenu[i].href}>{jsonMenu[i].text}</Anchor>);
    //	}

    return (menuItems);
  }

  //------------------------------------------------------------------------------------------------------------------------------------
  // Function to populate array of objects to render in H`eader
  navMenu() {

  }

  setHeaderItems() {
    let headerItems = [];
    let currentPathName = this.props.location.pathname;

    if (currentPathName.includes("AppDashboard")) {
      headerItems.push(null); // Hiding user Icon and menu for API central dashboard
    }
    else
      headerItems.push(<UserProfileMenu key={new Date().valueOf()} />);

    return (headerItems);
  }

  render() {

    //------------------------------------------------------------------------------------------------------------------------------------
    // Primary Navigation to pass to AppWrap
    let menuItems = this.setMenuItems();

    //------------------------------------------------------------------------------------------------------------------------------------
    // Objects to appear in Header
    let headerItems = this.setHeaderItems();

    //------------------------------------------------------------------------------------------------------------------------------------
    // react-router populates the props.children based on the user clicking on <Link> navigation components
    //
    // Set the parameters passed to AppWrap in order to customize the display of your header and menu
    //

    // use require() function to properly reference and load images (see https://github.com/webpack/file-loader)
    let appIcon = require('../../images/hpe-rectangle.png');
    let menuIcon = require('../../images/hpe-logo.png');

    return (
      <Provider store={store}>
        <AppWrap
          appTitle="Enterprise Monitor"
          appIcon={appIcon}
          menuIcon={menuIcon}
          menuItems={menuItems}
          headerItems={headerItems}>
          <ErrorNotifications />
          <div className="filter-containerdiv" ref="filterContainer">
            <TopMenuBar />
          </div>
          {this.props.children}
        </AppWrap>
      </Provider>
    );
  }
}

//------------------------------------------------------------------------------------------------------------------------------------
// PropType validation
AppHome.propTypes = {
  children: PropTypes.node,
  location: PropTypes.object
};

export default AppHome;
