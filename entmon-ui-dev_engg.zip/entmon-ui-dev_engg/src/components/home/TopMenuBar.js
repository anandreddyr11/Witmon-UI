import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import {
  menuCurrentPageSet,
  menuTimeRangeSet,
  menuCustomTimeRangeStartTimeSet,
  menuThemeSet,
  menuRefreshNow,
  menuAutoRefreshSet,
  menuAppnameSet,
  menuAppNamesSelectedSet,
  menuWorkflowGroupsSelectedSet,
} from '../../actions/menu';
import moment from 'moment';
import $ from 'jquery';

import Box from 'grommet/components/Box';
import List from 'grommet/components/List';
import ListItem from 'grommet/components/ListItem';
import Search from 'grommet/components/Search';
import Anchor from 'grommet/components/Anchor';
import Menu from 'grommet/components/Menu';
import Title from 'grommet/components/Title';
import NumberInput from 'grommet/components/NumberInput';
import Layer from 'grommet/components/Layer';
import Button from 'grommet/components/Button';
import DateTime from 'grommet/components/DateTime';
import Form from 'grommet/components/Form';
import FormField from 'grommet/components/FormField';
import FormFields from 'grommet/components/FormFields';
import Footer from 'grommet/components/Footer';
import Accordion from 'grommet/components/Accordion';
import AccordionPanel from 'grommet/components/AccordionPanel';
import CheckBox from 'grommet/components/CheckBox';
import HomeIcon from 'grommet/components/icons/base/Home';
import CalendarIcon from 'grommet/components/icons/base/Calendar';
import RefreshIcon from 'grommet/components/icons/base/Refresh';
import ClockIcon from 'grommet/components/icons/base/Clock';
import AppsIcon from 'grommet/components/icons/base/Apps';
import Animate from 'grommet/components/Animate';
import BrushIcon from 'grommet/components/icons/base/Brush';

const dateTimeFormat = 'D MMM YYYY, h:mm a';
const refreshIntervalDurationKey = 'refreshIntervalDuration';
const refreshIntervalLabelKey = 'refreshIntervalLabel';
const customTimeRangeLabel = 'Custom Range';

const MENU_MAIN_LABEL_INDEX = 0;
const MENU_TIMERANGE_LABEL_INDEX = 1;
const MENU_AUTOREFRESH_LABEL_INDEX = 2;
const MENU_REFRESHINTERVAL_LABEL_INDEX = 3;
const MENU_APPNAME_LABEL_INDEX = 4;
const MENU_WORKFLOWNAME_LABEL_INDEX = 5;
const MENU_THEME_LABEL_INDEX = 6;
const UNREASONABLE_MENU_BAR_WIDTH = 2000;

class TopMenuBar extends React.Component {
  constructor(props) {
    super(props);

    // default refresh rate of one min for timer
    const refreshIntervalDuration = Number(localStorage.getItem(refreshIntervalDurationKey)) || 1;
    const refreshIntervalLabel = localStorage.getItem(refreshIntervalLabelKey) || '1 Min';

    // Time range label
    const timeRangeHours = props.menuOptions.menuTimeRange;
    const timeRangeStart = props.menuOptions.menuCustomStartTime;
    const timeRangeLabel = this.getTimeRangeLabel(timeRangeHours, timeRangeStart);

    if (props.menuTheme === 'Dark Theme') {
      this.themeChanged(1);
    }

    this.state = { /* initial states */
      menuLabelTimeRange: timeRangeLabel,
      menuLabelAutoRefresh: props.menuAutoRefresh ? 'On' : 'Off',
      menuLabelRefreshInterval: refreshIntervalLabel,
      menuRefreshInterval: refreshIntervalDuration,
      showCustomTimeRangeOptions: false,
      customTimeRangeHrs: 0.5, // temp placeholder for custom timerange value
      customTimeRangeStartTime: null, // temp placeholder for custom timerange start value
      customTimeRangeEndTime: null, // temp placeholder for custom timerange end value
      customTimeRangeActivePanel: 0, // temp placeholder to find the active panel
      customTimeRangeEnableUTCEntry: false, // temp placeholder to find the active panel
      interval: refreshIntervalDuration * 60 * 1000,
      intervalId: null,
      intervalIdProgress: null,
      isApiCentralDashboard: false,
      whichShowMenuLabel: [true, true, true, true, true, true, true],
      appFilterInput: props.appFilterInput || '',
      workflowGroupFilterInput: '',
    };

    this.timeRangeChanged = this.timeRangeChanged.bind(this);
    this.autoRefreshChanged = this.autoRefreshChanged.bind(this);
    this.menuAutoRefreshChanged = this.menuAutoRefreshChanged.bind(this);
    this.getAppLabel = this.getAppLabel.bind(this);
    this.stopAutoRefresh = this.stopAutoRefresh.bind(this);
    this.startAutoRefresh = this.startAutoRefresh.bind(this);
    this.setupAutoRefresh = this.setupAutoRefresh.bind(this);
    this.showRefreshProgress = this.showRefreshProgress.bind(this);
    this.refreshIntervalChanged = this.refreshIntervalChanged.bind(this);
    this.handleAutoRefreshIntervalChanged = this.handleAutoRefreshIntervalChanged.bind(this);
    this.setcustomTimeRangeOptions = this.setcustomTimeRangeOptions.bind(this);
    this.setcustomTimeRangeValidateTime = this.setcustomTimeRangeValidateTime.bind(this);
    this.themeChanged = this.themeChanged.bind(this);
    this.handleAppCheckBox = this.handleAppCheckBox.bind(this);
    this.handleWorkflowGroupCheckBox = this.handleWorkflowGroupCheckBox.bind(this);
    this.handleMenuResize = this.handleMenuResize.bind(this);
  }

  componentDidMount() {
    // Set up whether auto refresh is enabled
    this.props.menuAutoRefreshSet(this.props.menuAutoRefresh);
    this.autoRefreshChanged(this.props.menuAutoRefresh ? 0 : 1);

    window.addEventListener('resize', this.handleMenuResize);
    this.pollForProperSize();

    this.props.menuCurrentPageSet(this.getCurrentPage());
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.menuAutoRefresh !== nextProps.menuAutoRefresh)
      this.autoRefreshChanged(nextProps.menuAutoRefresh ? 0 : 1);
  }

  componentDidUpdate() {
    if (this.getMenuBarWidth() < UNREASONABLE_MENU_BAR_WIDTH) {
      this.handleMenuResize();
    }
  }

  componentWillUnmount() {
    this.stopAutoRefresh();
    window.removeEventListener('resize', this.handleMenuResize);
  }

  pollForProperSize() {
    if (this.getMenuBarWidth() > UNREASONABLE_MENU_BAR_WIDTH) {
      setTimeout(() => {
        this.pollForProperSize();
      }, 5);
    } else {
      this.handleMenuResize();
    }
  }

  handleMenuResize() {
    if (this.state.windowWidth < $(window).width()) {
      // Window has been enlarged. Set all labels to show then shrink back down.
      this.setState ({
        windowWidth: $(window).width(),
        whichShowMenuLabel: this.state.whichShowMenuLabel.map(() => true),
      });
    } else if ($(window).width() < this.getMenuBarWidth() &&
      this.state.whichShowMenuLabel.some(bool => bool)) {
      const whichShowMenuLabel = [...this.state.whichShowMenuLabel];
      let labelToToggle;
      if (this.state.whichShowMenuLabel.every(bool => bool)) {
        labelToToggle = this.state.whichShowMenuLabel.length - 1;
      } else {
        labelToToggle = this.state.whichShowMenuLabel.indexOf(false) - 1;
      }
      whichShowMenuLabel[labelToToggle] = false;
      this.setState({
        windowWidth: $(window).width(),
        whichShowMenuLabel,
      });
    }
  }

  getMenuBarWidth() {
    let totalWidth = 0;
    $('#top-menu-parent').children()
      .each((i, e) => {
        $(e).children()
          .each((i, e) => {
            totalWidth += $(e).width();
          });
      });
    return totalWidth;
  }

  /**
   * Stop autorefresh and start again with new interval
   * @param {number} interval
   */
  startAutoRefresh(interval) {
    this.stopAutoRefresh(); // stop first
    // store intervalId in the state so it can be accessed later:
    this.setState({
      intervalId: setInterval(this.props.menuRefreshNow, interval),
      intervalIdProgress: setInterval(this.showRefreshProgress, interval / 100),
    });
  }

  showRefreshProgress() {
    this.currentProgressTick += 1;
    if (this.currentProgressTick > 100)
      this.currentProgressTick = 1;
    if (this.progressRef)
      this.progressRef.style.width = `${this.currentProgressTick}%`;
  }

  /**
   * Stop the timer
   */
  stopAutoRefresh() {
    if (this.state.intervalId !== null) {// if timer on, reset it
      clearInterval(this.state.intervalId);
      this.setState({ intervalId: null });
    }
    if (this.state.intervalIdProgress !== null) {// if progress timer on, reset it
      clearInterval(this.state.intervalIdProgress);
      this.setState({ intervalIdProgress: null });
    }

    this.currentProgressTick = -1; // reset Progressbar;
    this.showRefreshProgress();
  }

  /**
   * Enable or disable autorefresh. This also resets the counter
   * @param {boolean} enable
   */
  setupAutoRefresh(enable) {
    if (enable) {
      this.stopAutoRefresh();
      this.startAutoRefresh(this.state.interval);
    } else this.stopAutoRefresh();
  }

  /**
   * A selection was made in the menu with new autorefresh value in millisecond
   * @param {number} newInterval
   */
  handleAutoRefreshIntervalChanged(newInterval) { // Input assumed to be in ms
    if (newInterval < 300) // we do not support less than one third a second
      return false;
    this.setState({ interval: newInterval }); // Set the new interval
    if (this.state.intervalId !== null)
      this.startAutoRefresh(newInterval);
  }

  /**
   * Autorefresh enable/disable. This should be the entry point to make any autorefresh changes
   * @param {number} selected
   */
  autoRefreshChanged(selected) {
    let menuLabel;
    switch (selected) {
      case 0: menuLabel = 'On'; break;
      case 1: menuLabel = 'Off'; break;
      case 2: this.props.menuRefreshNow(); return; // "Refresh Now" No need to change label!
      default: menuLabel = 'Auto Refresh';
    }
    this.setState({ menuLabelAutoRefresh: menuLabel });
    this.setupAutoRefresh(selected === 0);
  }

  menuAutoRefreshChanged(selected) {
    if (selected === 2)
      this.props.menuRefreshNow();
    else
      this.props.menuAutoRefreshSet(selected === 0);
  }

  getCurrentPage() {
    const href = window.location.href;
    if (href.includes('/#/AppDashboard')) {
      return 'App Dashboard';
    } else if (href.includes('/#/TxnDashboard')) {
      return 'Dashboard';
    } else if (href.includes('/#/heatmap')) {
      return 'Heat Map';
    } else if (href.includes('/#/opsdashboard')) {
      return 'Ops Dashboard';
    } else if (href.includes('/#/WorkflowsDashboard')) {
      return 'Workflows';
    } else if (href.includes('/#/chartDetail')) {
      return 'Chart Details';
    } else {
      return 'Dashboard';
    }
  }

  getAppLabel() {
    if (this.props.menuAppnames === undefined || this.props.menuAppnames.length === 0) return;
    switch (this.props.menuAppNamesSelected.reduce((acc, val) => acc + val, 0)) {
      case 0: return 'No Apps';
      case 1: return this.props.menuAppnames[this.props.menuAppNamesSelected.indexOf(true)].appName;
      case this.props.menuAppNamesSelected.length: return 'All Apps';
      default: return 'Multiple Apps';
    }
  }

  getWorkflowLabel() {
    if (this.props.menuWorkflowGroups === undefined || this.props.menuWorkflowGroups.length === 0) return;
    switch (this.props.menuWorkflowGroupsSelected.reduce((acc, val) => acc + val, 0)) {
      case 0: return 'No Workflow Groups';
      case 1: return this.props.menuWorkflowGroups[this.props.menuWorkflowGroupsSelected.indexOf(true)].workflow_group_name;
      case this.props.menuWorkflowGroups.length: return 'All Workflow Groups';
      default: return 'Multiple Workflow Groups';
    }
  }

  getTimeRangeLabel(timeRange, customStartTime) {
    if (customStartTime) {
      return customTimeRangeLabel;
    }

    let label;
    switch (timeRange) {
      case (1 / 6): label = 'Last 10 Minutes'; break;
      case 0.5: label = 'Last 30 Minutes'; break;
      case 1: label = 'Last 1 Hour'; break;
      case 6: label = 'Last 6 Hours'; break;
      case 24: label = 'Last 1 Day'; break;
      case (3 * 24): label = 'Last 3 Days'; break;
      case (7 * 24): label = 'Last 1 Week'; break;
      case (2 * 7 * 24): label = 'Last 2 Weeks'; break;
      case (30 * 24): label = 'Last 1 Month'; break;
      default: label = customTimeRangeLabel;
    }

    return label;
  }

  timeRangeChanged(selected) {
    let timeRangeHours;
    switch (selected) {
      case 0: timeRangeHours = 1 / 6; break;
      case 1: timeRangeHours = 0.5; break;
      case 2: timeRangeHours = 1; break;
      case 3: timeRangeHours = 6; break;
      case 4: timeRangeHours = 24; break;
      case 5: timeRangeHours = 3 * 24; break;
      case 6: timeRangeHours = 7 * 24; break;
      case 7: timeRangeHours = 2 * 7 * 24; break;
      case 8: timeRangeHours = 30 * 24; break;
      case 9: break; // show modal popup for further input
      default: timeRangeHours = 1;
    }
    if (selected === 9) {
      this.setState({
        showCustomTimeRangeOptions: true,
        customTimeRangeHrs: this.props.menuOptions.menuTimeRange,
      });
    } else {
      const menuLabel = this.getTimeRangeLabel(timeRangeHours);
      this.setState({
        menuLabelTimeRange: menuLabel,
        customTimeRangeStartTime: null,
        customTimeRangeEndTime: null,
      });
      this.props.menuTimeRangeSet(this.props.menuOptions, timeRangeHours);
    }
  }

  setcustomTimeRangeOptions() {
    if (this.state.customTimeRangeActivePanel === 1) { // if last n hours was selected
      const menuLabel = this.getTimeRangeLabel(this.state.customTimeRangeHrs);

      this.setState({
        showCustomTimeRangeOptions: false,
        menuLabelTimeRange: menuLabel,
        customTimeRangeStartTime: null,
        customTimeRangeEndTime: null,
      });
      this.props.menuTimeRangeSet(this.props.menuOptions, this.state.customTimeRangeHrs);
    }
    else  // If a time range was selected
      if (!this.setcustomTimeRangeValidateTime(true) &&
        !this.setcustomTimeRangeValidateTime(false)) { // Validate start and end  dates!
        const startTime = moment(
          this.state.customTimeRangeStartTime ?
            this.state.customTimeRangeStartTime :
            moment().subtract(this.props.menuOptions.menuTimeRange, 'hours'),
          dateTimeFormat);
        const endTime = moment(
          this.state.customTimeRangeEndTime ?
            this.state.customTimeRangeEndTime : moment(new Date(), dateTimeFormat),
          dateTimeFormat);

        this.props.menuCustomTimeRangeStartTimeSet(
          this.props.menuOptions,
          moment.duration(endTime.diff(startTime)).asHours(),
          this.state.customTimeRangeEnableUTCEntry ?
            startTime.toDate() : moment(startTime.utc().format(dateTimeFormat),
              dateTimeFormat).toDate());
        this.setState({
          showCustomTimeRangeOptions: false,
          menuLabelTimeRange: customTimeRangeLabel,
        });
      }
  }

  setcustomTimeRangeValidateTime(isStartTime) {
    const startTime = moment(
      this.state.customTimeRangeStartTime ?
        this.state.customTimeRangeStartTime :
        moment().subtract(this.props.menuOptions.menuTimeRange, 'hours'),
      dateTimeFormat, true);
    const endTime = moment(
      this.state.customTimeRangeEndTime ?
        this.state.customTimeRangeEndTime : moment(new Date(), dateTimeFormat),
      dateTimeFormat, true);
    const timeToCheck = isStartTime ? startTime : endTime;
    if (!timeToCheck.isValid())
      return 'Not a valid date time';

    if ((this.state.customTimeRangeEnableUTCEntry && timeToCheck >
      moment(moment.utc().format(dateTimeFormat), dateTimeFormat)) ||
      (!this.state.customTimeRangeEnableUTCEntry && timeToCheck >
        moment(new Date(), dateTimeFormat)))
      return `${isStartTime ? 'Start' : 'End'} time must be less than current ${this.state.customTimeRangeEnableUTCEntry ? 'UTC ' : ''}time`;

    if (isStartTime && endTime.isValid() && startTime > endTime)
      return 'Start time must be less than end time';
    if (!isStartTime && endTime.isValid() && startTime > endTime)
      return 'End time must be greater than start time';

    return null;
  }

  refreshIntervalChanged(selected) {
    let menuLabel;
    let refreshInt;
    switch (selected) {
      case 0: menuLabel = '30 Secs'; refreshInt = 0.5; break;
      case 1: menuLabel = '1 Min'; refreshInt = 1; break;
      case 2: menuLabel = '2 Mins'; refreshInt = 2; break;
      case 3: menuLabel = '5 Mins'; refreshInt = 5; break;
      default: menuLabel = 'Refresh Interval'; refreshInt = 1;
    }

    localStorage.setItem(refreshIntervalDurationKey, refreshInt);
    localStorage.setItem(refreshIntervalLabelKey, menuLabel);

    this.setState({
      menuLabelRefreshInterval: menuLabel,
      menuRefreshInterval: refreshInt,
    });

    this.handleAutoRefreshIntervalChanged(refreshInt * 60 * 1000);
  }

  handleAppCheckBox(event) {
    const appNamesSelected = [...this.props.menuAppNamesSelected];
    // If 'All apps' was toggled
    if (parseInt(event.target.value) === 0) {
      // If 'All apps' was selected
      if (this.props.menuAppNamesSelected[0] === true) {
        // Set all to unselected
        this.props.menuAppNamesSelectedSet(this.props.menuAppnames,
          appNamesSelected.map(() => false));
      } else {
        // Else Set all to selected
        this.props.menuAppNamesSelectedSet(this.props.menuAppnames,
          appNamesSelected.map(() => true));
      }
    } else {
      // Else If 'All apps' was selected and we unselected an appName
      if (this.props.menuAppNamesSelected[0] === true &&
        appNamesSelected[event.target.value] === true) {
        appNamesSelected[0] = false;
        appNamesSelected[event.target.value] = false;
        // Set new selected app names
        this.props.menuAppNamesSelectedSet(this.props.menuAppnames, appNamesSelected);
      } else {
        // Else toggle appName
        appNamesSelected[event.target.value] =
          !appNamesSelected[event.target.value];
        // Check if toggling appName makes all appNames selected. Reselect 'All apps' if so.
        const isAllAppNamesSelected = appNamesSelected.every((element, index) =>
          index === 0 || element);
        if (isAllAppNamesSelected) appNamesSelected[0] = true;
        // Set new selected app names
        this.props.menuAppNamesSelectedSet(this.props.menuAppnames, appNamesSelected);
      }
    }
  }

  handleWorkflowGroupCheckBox(event) {
    const workflowGroupsSelected = [...this.props.menuWorkflowGroupsSelected];
    workflowGroupsSelected[event.target.value] = !workflowGroupsSelected[event.target.value];
    this.props.menuWorkflowGroupsSelectedSet(this.props.menuAppnames, workflowGroupsSelected);
  }

  themeChanged(event) {
    let themeLabeltext;
    switch (event) {
      case 0: themeLabeltext = 'Light Theme'; break;
      case 1: themeLabeltext = 'Dark Theme'; break;
    }
    this.props.menuThemeSet(themeLabeltext);
    let mainhtml;
    if (event === 1) {
      mainhtml = document.getElementsByTagName('html')[0]; // '0' to assign the first (and only `HTML` tag)
      mainhtml.setAttribute('class', 'dark-theme');
    } else {
      mainhtml = document.getElementsByTagName('html')[0]; // '0' to assign the first (and only `HTML` tag)
      mainhtml.removeAttribute('class', 'dark-theme');
    }
  }

  getNavigationItemsRender() {
    const navItems = [
      { page: 'Dashboard', href: '/#/TxnDashboard' },
      { page: 'Heat Map', href: '/#/heatmap' },
      { page: 'Workflows', href: '/#/WorkflowsDashboard' },
    ];
    return navItems.map((navItem, i) =>
      <Anchor key={i} href={navItem.href}
        onClick={() => this.props.menuCurrentPageSet(navItem.page)}>
        {navItem.page}
      </Anchor>
    );
  }

  getAppMenuRender() {
    return (
      <Menu id="apps-menu" icon={<AppsIcon />} closeOnClick={false}
        label={this.getMenuItemLabel(MENU_APPNAME_LABEL_INDEX)}>
        {!this.state.isApiCentralDashboard ? <Title pad="small">Select App</Title> : null}
        <Box margin={{ horizontal: 'small' }} pad={'none'}>
          <Search placeHolder={'Filter Apps'} inline={true} responsive={true} size={'medium'}
            value={this.state.appFilterInput} fill={true}
            onDOMChange={e => this.setState({ appFilterInput: e.target.value })} />
        </Box>
        <List selectable={true}>
          {this.getAppNamesListItems()}
        </List>
      </Menu>
    );
  }

  getWorkflowGroupsMenuRender() {
    return (
      <Menu icon={<AppsIcon />} closeOnClick={false}
        label={this.getMenuItemLabel(MENU_WORKFLOWNAME_LABEL_INDEX)}>
        <Title pad="small">Select Workflow Group</Title>
        <Box margin={{ horizontal: 'small' }} pad={'none'}>
          <Search placeHolder={'Filter Workflow Groups'} inline={true} responsive={true}
            value={this.state.workflowGroupFilterInput} fill={true} size={'medium'}
            onDOMChange={e => this.setState({ workflowGroupFilterInput: e.target.value })} />
        </Box>
        <List>
          {this.getWorkflowGroupListItems()}
        </List>
      </Menu>
    );
  }

  getAppNamesListItems() {
    // Find duplicated names so we can append the app instance id to duplicated app names later.
    const duplicatedNames = this.props.menuAppnames.map(x => x.appName)
      .reduce((acc, el, i, arr) => {
        if (arr.indexOf(el) !== i && acc.indexOf(el) < 0) acc.push(el); return acc;
      }, []);
    // Filter apps by app name filter input
    const regExp = new RegExp(this.state.appFilterInput.toLowerCase());
    const filteredApps = this.props.menuAppnames.map((app, i) => {
      const modifiedApp = { ...app };
      modifiedApp.originalIndex = i;
      modifiedApp.checked = this.props.menuAppNamesSelected[i];
      return modifiedApp;
    }).filter(app => regExp.test(app.appName.toLowerCase()));
    return filteredApps.map((app, i) =>
      <ListItem justify="between" key={i}>
        <CheckBox
          id={app.appName}
          label={duplicatedNames.includes(app.appName) ? `${app.appName} (${app.appInstanceId})` : app.appName}
          checked={app.checked}
          value={app.originalIndex}
          onChange={this.handleAppCheckBox} />
      </ListItem>
    );
  }

  getWorkflowGroupListItems() {
    // Filter workflow groups by workflow groups name filter input
    const regExp = new RegExp(this.state.workflowGroupFilterInput.toLowerCase());
    const filteredWorkflowGroups = this.props.menuWorkflowGroups.map((workflowGroup, i) => {
      const modifiedWorkflowGroup = { ...workflowGroup };
      modifiedWorkflowGroup.originalIndex = i;
      modifiedWorkflowGroup.checked = this.props.menuWorkflowGroupsSelected[i];
      return modifiedWorkflowGroup;
    }).filter(workflowGroup => regExp.test(workflowGroup.workflow_group_name.toLowerCase()));

    return filteredWorkflowGroups.map((workflowGroup, i) =>
      <ListItem justify="between" key={i}>
        <CheckBox
          label={workflowGroup.workflow_group_name}
          checked={workflowGroup.checked}
          value={workflowGroup.originalIndex}
          onChange={this.handleWorkflowGroupCheckBox} />
      </ListItem>
    );
  }

  getMenuItemLabel(index) {
    if (this.state.whichShowMenuLabel[index]) {
      switch (index) {
        case MENU_MAIN_LABEL_INDEX:
          return this.props.menuCurrentPage;
        case MENU_TIMERANGE_LABEL_INDEX:
          return this.state.menuLabelTimeRange;
        case MENU_AUTOREFRESH_LABEL_INDEX:
          return this.state.menuLabelAutoRefresh;
        case MENU_REFRESHINTERVAL_LABEL_INDEX:
          return this.state.menuLabelRefreshInterval;
        case MENU_APPNAME_LABEL_INDEX:
          return this.getAppLabel();
        case MENU_WORKFLOWNAME_LABEL_INDEX:
          return this.getWorkflowLabel();
        case MENU_THEME_LABEL_INDEX:
          return this.props.menuTheme;
      }
    } else {
      return undefined;
    }
  }

  render() {
    if (!this.props.userProfile.loggedin || !this.props.menuShowMenu) {
      return null;
    }
    return (
      <Animate enter={{ animation: 'slide-right', duration: 1000, delay: 0 }}
        leave={{ animation: 'slide-left', duration: 600, delay: 0 }}
        keep={false}>
        <Box>
          <Box direction="row" responsive={false} id="top-menu-parent">
            <Box direction="row" responsive={false} full="horizontal">
              <Menu icon={<HomeIcon />} label={this.getMenuItemLabel(MENU_MAIN_LABEL_INDEX)}>
                {this.getNavigationItemsRender()}
              </Menu>
              <Animate enter={{ animation: 'slide-right', duration: 600, delay: 0 }}
                leave={{ animation: 'slide-left', duration: 400, delay: 0 }}
                keep={false} visible={this.props.menuShowTimeRange}>
                <Menu icon={<CalendarIcon />}
                  label={this.getMenuItemLabel(MENU_TIMERANGE_LABEL_INDEX)}>
                  <Title pad="small">Time Range</Title>
                  <List selectable={true} onSelect={this.timeRangeChanged}>
                    <ListItem justify="between">Last 10 Minutes - Real Time</ListItem>
                    <ListItem justify="between">Last 30 Minutes</ListItem>
                    <ListItem justify="between">Last 1 Hour</ListItem>
                    <ListItem justify="between">Last 6 Hours</ListItem>
                    <ListItem justify="between">Last 1 Day</ListItem>
                    <ListItem justify="between">Last 3 Days</ListItem>
                    <ListItem justify="between">Last 1 Week</ListItem>
                    <ListItem justify="between">Last 2 Weeks</ListItem>
                    <ListItem justify="between">Last 1 Month</ListItem>
                    <ListItem justify="between">Custom</ListItem>
                  </List>
                </Menu>
              </Animate>
              <span className="progress-parent">
                <span className="progress-filling" ref={(c) => this.progressRef = c} />
                <Menu icon={<RefreshIcon />}
                  label={this.getMenuItemLabel(MENU_AUTOREFRESH_LABEL_INDEX)}>
                  <Title pad="small">Auto Refresh</Title>
                  <List selectable={true} onSelect={this.menuAutoRefreshChanged}>
                    <ListItem justify="between">On</ListItem>
                    <ListItem justify="between">Off</ListItem>
                    <ListItem justify="between">Refresh Now</ListItem>
                  </List>
                </Menu>
              </span>
              <Menu icon={<ClockIcon />}
                label={this.getMenuItemLabel(MENU_REFRESHINTERVAL_LABEL_INDEX)}>
                <Title pad="small">Refresh Interval</Title>
                <List selectable={true} onSelect={this.refreshIntervalChanged}>
                  <ListItem justify="between">30 Secs</ListItem>
                  <ListItem justify="between">1 Min</ListItem>
                  <ListItem justify="between">2 Mins</ListItem>
                  <ListItem justify="between">5 Mins</ListItem>
                </List>
              </Menu>
              {this.props.menuCurrentPage === 'Dashboard' ? this.getAppMenuRender() : undefined}
              {this.props.menuCurrentPage === 'Workflows' ? this.getWorkflowGroupsMenuRender() : undefined}
            </Box>
            <Box className="theme-button" direction="row" responsive={false} full="horizontal" justify="end">
              <Menu icon={<BrushIcon />} label={this.getMenuItemLabel(MENU_THEME_LABEL_INDEX)}>
                <Title pad="small">Select Theme</Title>
                <List selectable={true} onSelect={this.themeChanged}>
                  <ListItem justify="between">Light Theme</ListItem>
                  <ListItem justify="between">Dark Theme</ListItem>
                </List>
              </Menu>
            </Box>
          </Box>
          <Layer hidden={!this.state.showCustomTimeRangeOptions} align="top">
            <Title pad="small">Custom Options</Title>
            <Box pad="small">
              <Form>
                <Accordion active={0}
                  onActive={(panel) => { this.setState({ customTimeRangeActivePanel: panel }); }}>
                  <AccordionPanel heading="TimeRange">
                    <FormFields>
                      <FormField
                        label={`Start Time (${this.state.customTimeRangeEnableUTCEntry ? 'UTC' : 'Local'})`}
                        error={this.setcustomTimeRangeValidateTime(true)} >
                        <DateTime
                          format={dateTimeFormat}
                          onChange={(datetime) => {
                            this.setState({ customTimeRangeStartTime: datetime });
                          }}
                          value={this.state.customTimeRangeStartTime ?
                            this.state.customTimeRangeStartTime :
                            moment().subtract(this.props.menuOptions.menuTimeRange, 'hours')} />
                      </FormField>
                      <FormField
                        label={`End Time (${this.state.customTimeRangeEnableUTCEntry ? 'UTC' : 'Local'})`}
                        error={this.setcustomTimeRangeValidateTime(false)} >
                        <DateTime
                          format={dateTimeFormat}
                          onChange={(datetime) => {
                            this.setState({ customTimeRangeEndTime: datetime });
                          }}
                          value={this.state.customTimeRangeEndTime ?
                            this.state.customTimeRangeEndTime : moment()} />
                      </FormField>
                      <FormField
                        help="Enable to make the time selections above in UTC. Disable to enter in the user's local time. In this case, the dashboard will convert the Time Range to UTC."
                        label="UTC Time">
                        <CheckBox
                          toggle={true}
                          checked={this.state.customTimeRangeEnableUTCEntry}
                          onChange={(event) => {
                            this.setState({ customTimeRangeEnableUTCEntry: event.target.checked });
                          }} />
                      </FormField>
                    </FormFields>
                  </AccordionPanel>
                  <AccordionPanel heading="Hours">
                    <FormFields>
                      <FormField label="Last x Hours">
                        <NumberInput id="numhrs"
                          value={this.state.customTimeRangeHrs} min={1} max={10 * 365 * 24}
                          onChange={(event) => {
                            this.setState({ customTimeRangeHrs: Number(event.target.value) });
                          }} />
                      </FormField>
                    </FormFields>
                  </AccordionPanel>
                </Accordion>
                <Footer pad={{ vertical: 'medium' }}>
                  <Button onClick={this.setcustomTimeRangeOptions} label="OK" /> &nbsp;
                  <Button label="Cancel"
                    onClick={() => {
                      this.setState({ showCustomTimeRangeOptions: false });
                    }} />
                </Footer>
              </Form>
            </Box >
          </Layer >
        </Box >
      </Animate>
    );
  }
}

TopMenuBar.propTypes = {
  menuCurrentPage: PropTypes.string,
  menuCurrentPageSet: PropTypes.func.isRequired,
  appFilterInput: PropTypes.string,
  userProfile: PropTypes.object.isRequired,
  menuOptions: PropTypes.object.isRequired,
  menuTheme: PropTypes.string.isRequired,
  menuAppnames: PropTypes.array.isRequired,
  menuWorkflowGroups: PropTypes.array.isRequired,
  menuAppNamesSelected: PropTypes.array.isRequired,
  menuWorkflowGroupsSelected: PropTypes.array.isRequired,
  menuAppNamesSelectedSet: PropTypes.func.isRequired,
  menuWorkflowGroupsSelectedSet: PropTypes.func.isRequired,
  menuTimeRangeSet: PropTypes.func.isRequired,
  menuShowTimeRange: PropTypes.bool.isRequired,
  menuCustomTimeRangeStartTimeSet: PropTypes.func.isRequired,
  menuThemeSet: PropTypes.func.isRequired,
  menuAppnameSet: PropTypes.func.isRequired,
  menuRefreshNow: PropTypes.func.isRequired,
  menuAutoRefresh: PropTypes.bool.isRequired,
  menuAutoRefreshSet: PropTypes.func.isRequired,
  menuShowMenu: PropTypes.bool.isRequired,
};

const mapStateToProps = state => ({
  menuCurrentPage: state.menuCurrentPage,
  appFilterInput: state.appFilterInput,
  userProfile: state.userProfile,
  menuOptions: state.menuOptions,
  menuTheme: state.menuTheme,
  menuAutoRefresh: state.menuAutoRefresh,
  menuAppnames: state.menuAppnames,
  menuAppNamesSelected: state.menuAppNamesSelected,
  menuWorkflowGroupsSelected: state.menuWorkflowGroupsSelected,
  menuWorkflowGroups: state.menuWorkflowGroups,
  menuShowTimeRange: state.menuShowTimeRange,
  menuShowMenu: state.menuShowMenu,
});

const mapDispatchToProps = dispatch => ({
  menuCurrentPageSet: page => dispatch(menuCurrentPageSet(page)),
  menuTimeRangeSet: (menu, timeRange) => dispatch(menuTimeRangeSet(menu, timeRange)),
  menuCustomTimeRangeStartTimeSet: (menu, timeRange, startTime) =>
    dispatch(menuCustomTimeRangeStartTimeSet(menu, timeRange, startTime)),
  menuThemeSet: themeLabel => dispatch(menuThemeSet(themeLabel)),
  menuAppnameSet: (menu, appNameList, appSelected) =>
    dispatch(menuAppnameSet(menu, appNameList, appSelected)),
  menuAppNamesSelectedSet: (appNames, appNamesSelected) =>
    dispatch(menuAppNamesSelectedSet(appNames, appNamesSelected)),
  menuWorkflowGroupsSelectedSet: (workflowGroups, workflowGroupsSelected) =>
    dispatch(menuWorkflowGroupsSelectedSet(workflowGroups, workflowGroupsSelected)),
  menuRefreshNow: () => dispatch(menuRefreshNow()),
  menuAutoRefreshSet: bool => dispatch(menuAutoRefreshSet(bool)),
});

export default connect(mapStateToProps, mapDispatchToProps)(TopMenuBar);
