import React from 'react';
import Heading from 'grommet/components/Heading';
import Header from 'grommet/components/Header';
import FormField from 'grommet/components/FormField';
import Button from 'grommet/components/Button';
import Select from 'grommet/components/Select';
import { connect } from 'react-redux';
import { buildQuery, processStatus } from 'grommet/utils/Rest';
import Toast from 'grommet/components/Toast';
import Status from 'grommet/components/icons/Status';
import List from 'grommet/components/List';
import ListItem from 'grommet/components/ListItem';
import TextInput from 'grommet/components/TextInput';
import CheckBox from 'grommet/components/CheckBox';
import Spinning from 'grommet/components/icons/Spinning';
import Layer from 'grommet/components/Layer';
import Label from 'grommet/components/Label';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import FormTrashIcon from 'grommet/components/icons/base/FormTrash';
import Notification from 'grommet/components/Notification';
import AddIcon from 'grommet/components/icons/base/Add';


const config = require(`../../../config.${process.env.NODE_ENV}.json`);
process.env.NODE_ENV !== 'test' ? require('!style!css!../../styles/form-style.css') : undefined;
const common = require('../home/common');
let applicationApiNames = [];
let self;
const CREATOR = 'creator';
const SUBSCRIBER = 'subscriber';

class AddApiConsumer extends React.Component {
  constructor(props) {
    super(props);
    // Change the page title
    document.title = 'Add Consumer/Owner to app';
    this.state = {
      tableData: [],
      isChecked: false,
      app_name: '',
      user_action: '',
      user_email: [],
      applicationAllAppname: '',
      application_instance_id: '',
      application_consumer_id: '',
      customApplicationConsumerId: '',
      appNameOptions: [],
      selectedAppuserType: '',
      appInstanceIdStatus: true,
      EPRID_APP_NAMES: [],
      API_NAMES: [],
      applicationInstanceIdField: [],
      applicationConsumerIdOptions: [],
      allEmails: [],
      createCustomConsIDFieldStatus: false,
      tableRows: [],
      emailFieldError: '',
      failureNotification: false,
      allApiSelected: [],
      err: '',
      userActionError: '',
      appConsIdError: '',
      appConsIdError1: '',
      appConsIdError2: '',
      appConsIdError3: '',
      appConsIdError4: '',
      appConsIdError5: '',
      appApiError: '',
      appApiError1: '',
      appApiError2: '',
      appApiError3: '',
      appApiError4: '',
      appApiError5: '',
      customAppConsIdError: '',
      multiApiSelected: [],
      appNameField: 'form-field-default',
      userTypeFieldBorder: 'form-field-default',
      appConsIdField: 'form-field-default',
      consumerEmailFieldBorder: 'consumer-email-field-default',
      spinnerStatus: true,
      applicationApiNameSelected: [],
      shouldFieldBeHidden: false,
      newUserAddedAlert: '',
      displayAddIcon: false,
      addNewAppNameField: false,
      addedfieldCount: 1,
      newFieldAdded1: false,
      newFieldAdded2: false,
      newFieldAdded3: false,
      newFieldAdded4: false,
      newFieldAdded5: false,
      appApiName: '',
      appApiName1: '',
      appApiName2: '',
      appApiName3: '',
      appApiName4: '',
      appApiName5: '',
      appConsId: '',
      appConsId1: '',
      appConsId2: '',
      appConsId3: '',
      appConsId4: '',
      appConsId5: '',
      appApiNameList: [],
      appConsIdList: [],
      app_api_name: '',
      appCustomConsIdList: [],
      apiLength: 0,
    };

    self = this;
    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleFieldOptions = this.handleFieldOptions.bind(this);
    this.handleSelectOption = this.handleSelectOption.bind(this);
    this.handleAppCheckBox = this.handleAppCheckBox.bind(this);
    this.getAppLabel = this.getAppLabel.bind(this);
    this.getapplicationApiNames = this.getapplicationApiNames.bind(this);
    this.renderShowsTotal = this.renderShowsTotal.bind(this);
    this.deleteButtonFormatter = this.deleteButtonFormatter.bind(this);
    this.resetNotifications = this.resetNotifications.bind(this);
    this.addAppNameField = this.addAppNameField.bind(this);
    this.addApiField = this.addApiField.bind(this);
    this.addConsumerField = this.addConsumerField.bind(this);
    this.handleSelectForConsumerId = this.handleSelectForConsumerId.bind(this);
    this.getAppApiNamesList = this.getAppApiNamesList.bind(this);
    this.getConsIdList = this.getConsIdList.bind(this);
  }

  componentDidMount() {
    this.fetchData(`${config.serverUrl}/get-app-details`);
  }

  componentWillUnmount() {
    document.title = 'EntMon Dashboard';
  }

  getConsIdList() {
    if (this.state.appConsId) {
      this.state.appConsIdList.push(this.state.appConsId);
    }
    if (this.state.appConsId1) {
      this.state.appConsIdList.push(this.state.appConsId1);
    }
    if (this.state.appConsId2) {
      this.state.appConsIdList.push(this.state.appConsId2);
    }
    if (this.state.appConsId3) {
      this.state.appConsIdList.push(this.state.appConsId3);
    }
    if (this.state.appConsId4) {
      this.state.appConsIdList.push(this.state.appConsId4);
    }
    if (this.state.appConsId5) {
      this.state.appConsIdList.push(this.state.appConsId5);
    }
  }
  getAppApiNamesList() {
    if (this.state.appApiName) {
      this.state.appApiNameList.push(this.state.appApiName);
    }
    if (this.state.appApiName1) {
      this.state.appApiNameList.push(this.state.appApiName1);
    }
    if (this.state.appApiName2) {
      this.state.appApiNameList.push(this.state.appApiName2);
    }
    if (this.state.appApiName3) {
      this.state.appApiNameList.push(this.state.appApiName3);
    }
    if (this.state.appApiName4) {
      this.state.appApiNameList.push(this.state.appApiName4);
    }
    if (this.state.appApiName5) {
      this.state.appApiNameList.push(this.state.appApiName5);
    }
  }

  fetchData(url) {
    if (this.props.userEmail !== undefined) {
      const INPUT_GET_APP_DETAILS = { user_email: this.props.userEmail };
      const INPUT_GET_APP_DETAILS_URL = `${url}${buildQuery(INPUT_GET_APP_DETAILS)}`;
      const request = new Request(INPUT_GET_APP_DETAILS_URL, { method: 'get' });
      fetch(request)
        .then(processStatus)
        .then(response => response.json())
        .then(userDetails => {
          const duplicatedNames = userDetails.map(x => x.app_name)
              .reduce((acc, el, i, arr) => {
                if (arr.indexOf(el) !== i && acc.indexOf(el) < 0)
                  acc.push(el);
                return acc;
              }, []);

          const allAppNames = userDetails.map(element => {
            if (duplicatedNames.includes(element.app_name)) {
              return `${element.eprid}-${element.app_name} (${element.application_instance_id})`;
            } else {
              return `${element.eprid}-${element.app_name}`;
            }
          });

          const EPRID_APP_NAMES = allAppNames.filter((elem, index, self) => {
            return index === self.indexOf(elem);
          });

          this.setState({
            EPRID_APP_NAMES,
            userDetails,
            appNameOptions: EPRID_APP_NAMES,
            appNameField: 'form-field-next',
            spinnerStatus: false,
            error: undefined,
          });
        })
        .catch(error => {
          const errorMsg = 'We cannot connect to server at this time to get profile details. Please check if you logged in or try again later!';
          console.error(error);
          this.setState({ userDetails: undefined,
            error: errorMsg,
            err: errorMsg,
         });
        });
    } else {
      this.setState({ err: 'There is an issue loading page. Please check if you are logged in and try again!' });
    }
  }

  resetNotifications() {
    this.setState({
      newUserAddedAlert: '',
    });
  }

  handleInputChange(event) {
    const TARGET = event.target;
    const VALUE = TARGET.value;
    const NAME = TARGET.name;

    if (NAME === 'user_email') {
      const allEmails = event.target.value.split('\n');
      this.setState({ consumerEmailFieldBorder: 'consumer-email-field-default', allEmails });
    }

    if (NAME === 'customApplicationConsumerId') {
      this.setState({ consumerEmailFieldBorder: 'consumer-email-field-next', customAppConsId: 'form-field-default' });
    }
    this.setState({
      [NAME]: VALUE,
      emailFieldError: '',
      customAppConsIdError: '',
      failureNotification: false,
    });
  }

  handleSubmit(event) {
    event.preventDefault();
    let failureNotification = false;
    let err = '';
    const applicationApiNameSelected = this.state.applicationApiNameSelected;
    const shouldTheFieldBeHidden = this.state.shouldFieldBeHidden;
    const userAction = (this.state.selectedAppuserType === SUBSCRIBER) ?
      SUBSCRIBER : this.state.user_action;
    if (userAction === SUBSCRIBER && applicationApiNameSelected.length === 0
      && shouldTheFieldBeHidden) {
      failureNotification = true;
      err = 'Adding subscriber is not allowed as there are no APIs for the selected application.';
    }

    if (this.props.userEmail === undefined) {
      err = 'There is an issue with user profile. Please try again!';
    } else {
      let anyFieldHasErrored = false;
      let userEnteredSameEmail = false;
      let allEmails = this.state.allEmails;
      let userActionError = '';
      let appConsIdError = '';
      let appConsIdError1 = '';
      let appConsIdError2 = '';
      let appConsIdError3 = '';
      let appConsIdError4 = '';
      let appConsIdError5 = '';
      let appApiError = '';
      let appApiError1 = '';
      let appApiError2 = '';
      let appApiError3 = '';
      let appApiError4 = '';
      let appApiError5 = '';
      let customAppConsIdError = '';
      let emailFieldError = '';
      allEmails = allEmails.filter(entry => entry.trim() !== '');
      if (!userAction) {
        anyFieldHasErrored = true;
        userActionError = 'User Type cannot be empty';
      }
      if (!this.state.application_consumer_id && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        appConsIdError = 'Application Consumer ID cannot be empty';
      }
      if (!this.state.appConsId && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        appConsIdError = 'Application Consumer ID cannot be empty';
      }
      if (this.state.newFieldAdded1 && !this.state.appConsId1 && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        appConsIdError1 = 'Application Consumer ID cannot be empty';
      }
      if (this.state.newFieldAdded2 && !this.state.appConsId2 && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        appConsIdError2 = 'Application Consumer ID cannot be empty';
      }
      if (this.state.newFieldAdded3 && !this.state.appConsId3 && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        appConsIdError3 = 'Application Consumer ID cannot be empty';
      }
      if (this.state.newFieldAdded4 && this.state.appConsId4 && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        appConsIdError4 = 'Application Consumer ID cannot be empty';
      }
      if (this.state.newFieldAdded5 && !this.state.appConsId5 && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        appConsIdError5 = 'Application Consumer ID cannot be empty';
      }
      if (this.state.application_consumer_id === 'Enter a custom value' && !this.state.customApplicationConsumerId && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        customAppConsIdError = 'Custom Application Consumer ID cannot be empty';
      }
      if (!this.state.appConsId && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        appApiError = 'Application API cannot be empty';
      }
      if (this.state.newFieldAdded1 && !this.state.appApiName1 && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        appApiError1 = 'Application API cannot be empty';
      }
      if (this.state.newFieldAdded2 && !this.state.appApiName2 && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        appApiError2 = 'Application API cannot be empty';
      }
      if (this.state.newFieldAdded3 && !this.state.appApiName3 && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        appApiError3 = 'Application API cannot be empty';
      }
      if (this.state.newFieldAdded4 && this.state.appApiName4 && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        appApiError4 = 'Application API cannot be empty';
      }
      if (this.state.newFieldAdded5 && !this.state.appApiName5 && userAction !== CREATOR) {
        anyFieldHasErrored = true;
        appApiError5 = 'Application API cannot be empty';
      }
      if (allEmails.length === 0) {
        anyFieldHasErrored = true;
        emailFieldError = 'There should be at least one email in user E-mail Address field.';
      }
      this.setState({
        userActionError,
        appConsIdError,
        appConsIdError1,
        appConsIdError2,
        appConsIdError3,
        appConsIdError4,
        appConsIdError5,
        appApiError,
        appApiError1,
        appApiError2,
        appApiError3,
        appApiError4,
        appApiError5,
        customAppConsIdError,
        emailFieldError,

      });
      if (document.getElementById('show-member-check-box').checked !== true) {
        document.getElementById('show-member-check-box').checked = true;
        this.showTableStatus();
      }
      if (!anyFieldHasErrored) {
        const INPUT_GET_DUPLICATE_EMAIL = { application_instance_id: this.state.application_instance_id };
        const INPUT_GET_DUPLICATE_EMAIL_URL = `${config.serverUrl}/get-app-details${buildQuery(INPUT_GET_DUPLICATE_EMAIL)}`;
        const getTableDetailsRequest = new Request(INPUT_GET_DUPLICATE_EMAIL_URL, { method: 'get' });
        fetch(getTableDetailsRequest)
          .then(processStatus)
          .then(response => response.json())
          .then(duplicateEmailResponse => {
            const len = duplicateEmailResponse.length;
            let isReadyToSubmit = true;
            const allEmailLength = allEmails.length;
            for (let j = 0; j < allEmailLength; j++) {
              for (let l = j + 1; l < allEmailLength; l++) {
                if (allEmails[l] === allEmails[j]) {
                  isReadyToSubmit = false;
                  userEnteredSameEmail = true;
                  this.setState({ emailFieldError: `There is more than one "${allEmails[j]}". Please check the e-mails list.` });
                  break;
                }
              }

              if (!common.isEmail(allEmails[j]) && !userEnteredSameEmail) {
                isReadyToSubmit = false;
                this.setState({ emailFieldError: `"${allEmails[j]}" is not a valid e-mail.` });
                break;
              }

              for (let i = 0; i < len; i++) {
                if (duplicateEmailResponse[i].user_email === allEmails[j] &&
                    duplicateEmailResponse[i].user_action === CREATOR) {
                  isReadyToSubmit = false;
                  this.setState({ emailFieldError: `"${allEmails[j]}" already exists as ${duplicateEmailResponse[i].user_action} for "${this.state.form_app_name}` });
                  break;
                }
              }
            }

            if (isReadyToSubmit) {
              this.sendFormData(allEmails, userAction);
              this.setState({ spinnerStatus: true });
            }
          })
          .catch(error => this.setState({ error, err: 'We cannot connect to server to check duplicate subscribers E-mail at this time. Please try again later! ' }));
      }
    }
    this.setState({ err, failureNotification });
  }

  sendFormData(allEmails, userAction) {
    this.getAppApiNamesList();
    this.getConsIdList();
    // Prepare form parameters for submitting the form.
    if (this.state.createCustomConsIDFieldStatus) {
      this.state.appConsIdList.push(this.state.customApplicationConsumerId);
    }
    const applicationConsumerId = this.state.appConsIdList;

    const formData = new FormData();
    formData.append('eprid', this.state.eprid);
    formData.append('app_name', this.state.form_app_name);
    formData.append('user_email', allEmails);
    formData.append('user_action', userAction);
    formData.append('application_consumer_id', applicationConsumerId);
    formData.append('api_name', this.state.appApiNameList);
    formData.append('application_instance_id', this.state.application_instance_id);
    formData.append('is_new_consumer_id', this.state.createCustomConsIDFieldStatus);

    const request = new Request(`${config.serverUrl}/post-app-subscription-form-data`, {
      method: 'post',
      body: formData,
    });

    fetch(request)
      .then(processStatus)
      .then(response => response.text())
      .then(result => this.showAddedUsersTable(result))
      .catch(error => this.setState({ err: 'Error in adding the user to the Application.', error, failureNotification: true }));
  }
  addConsumerField(consumerId, setConsumerId) {
    let consError;
    if (setConsumerId === 'appConsId') {
      consError = this.state.appConsIdError;
    }

    if (setConsumerId === 'appConsId1') {
      consError = this.state.appConsIdError1;
    }
    if (setConsumerId === 'appConsId2') {
      consError = this.state.appConsIdError2;
    }
    if (setConsumerId === 'appConsId3') {
      consError = this.state.appConsIdError3;
    }
    if (setConsumerId === 'appConsId4') {
      consError = this.state.appConsIdError4;
    }
    if (setConsumerId === 'appConsId5') {
      consError = this.state.appConsIdError5;
    }
    return (
      <FormField error={consError}
        label="Application Consumer ID"
        className={this.state.appConsIdField}
        hidden={this.state.shouldFieldBeHidden}>
        <Select
          name="application_consumer_id"
          id="application-consumer-id-field"
          placeholder="Please select Application Consumer ID or create a cutom value"
          placeHolder="Search for Application Consumer ID "
          className="form-field-inner-tag"
          options={this.state.applicationConsumerIdOptions}
          value={consumerId}
          onChange={e => this.handleSelectForConsumerId(e, e.option, setConsumerId)}
          onSearch={e => this.handleAppConsumerIdSearch(e.target.value)} />
      </FormField>
    );
  }
  addApiField(appName, setAppApiName) {
    let apiError;
    if (setAppApiName === 'appApiName') {
      apiError = this.state.appApiError;
    }

    if (setAppApiName === 'appApiName1') {
      apiError = this.state.appApiError1;
    }
    if (setAppApiName === 'appApiName2') {
      apiError = this.state.appApiError2;
    }
    if (setAppApiName === 'appApiName3') {
      apiError = this.state.appApiError3;
    }
    if (setAppApiName === 'appApiName4') {
      apiError = this.state.appApiError4;
    }
    if (setAppApiName === 'appApiName5') {
      apiError = this.state.appApiError5;
    }
    return (
      <FormField
        error={apiError}
        label="Application Api Names"
        className={this.state.appConsIdField}
        hidden={this.state.shouldFieldBeHidden}>
        { applicationApiNames.length > 0 ? <Select
          name="app_api_name"
          id="applicationApiNames"
          className="application-api-name"
          placeholder="Please select an application API name"
          value={appName}
          options={applicationApiNames}
          onChange={e => this.handleAppCheckBox(e.option, setAppApiName)} /> : <Label margin="small"> { 'No Api(s) available'} </Label> }
      </FormField>
    );
  }

  addAppNameField() {
    const count = this.state.addedfieldCount;
    this.setState({ addNewAppNameField: true, addedfieldCount: count + 1 });
    if (this.state.addedfieldCount === 1) {
      this.setState({ newFieldAdded1: true });
    }

    if (this.state.addedfieldCount === 2) {
      this.setState({ newFieldAdded2: true,
        });
    }

    if (this.state.addedfieldCount === 3) {
      this.setState({ newFieldAdded3: true,
          });
    }

    if (this.state.addedfieldCount === 4) {
      this.setState({ newFieldAdded4: true,
            });
    }

    if (this.state.addedfieldCount === 5) {
      this.setState({ newFieldAdded5: true,
            });
    }
  }

  deleteButtonFormatter() {
    return (<Button filter={{ type: 'TextFilter' }}
      icon={<FormTrashIcon />} disabled="disabled" label="Delete" href={'#/AlertCreation'} className="mr-10"
      onClick={function deleteActionHandler(e) {
        e.preventDefault();
      }} />
    );
  }

  showAddedUsersTable(result) {
    if (result === 'Record(s) inserted successfully') {
      this.setState({ spinnerStatus: false, newUserAddedAlert: 'User is added to your app group successfully.' });
      this.showTableStatus();
    } else {
      this.setState({ err: 'Error in adding the consumer to Application group', failureNotification: true });
    }
  }

  getapplicationApiNames(allApis, selectedInstance) {
    let applicationAppInstance;
    let formAppName;
    const formAppNameTruncated = selectedInstance.substring(selectedInstance.indexOf('-') + 1, selectedInstance.length);

    this.setState({ displayAddIcon: false });

    if (selectedInstance.indexOf('(') > -1) {
      applicationAppInstance = selectedInstance.match(/\((.*)\)/i)[1];
      formAppName = formAppNameTruncated.replace(formAppNameTruncated.substring(formAppNameTruncated.indexOf(' ('), formAppNameTruncated.length), '');
    } else {
      formAppName = formAppNameTruncated;
      const filterAppname = allApis.filter(eachapi => eachapi.app_name === formAppName);
      applicationAppInstance = filterAppname[0].application_instance_id;
    }

    const host = config.serverUrl;
    const endpoint = '/get-api-details';
    const query = buildQuery({
      application_instance_id: applicationAppInstance,
      app_name: formAppName,
      user_email: this.props.userEmail,
    });
    const uri = `${host}${endpoint}${query}`;
    fetch(uri)
      .then(processStatus)
      .then(response => response.json())
      .then(appapis => {
        if (applicationApiNames.length > 0) {
          applicationApiNames = [];
        }
        appapis.map(e => applicationApiNames.push(e.api_name));
        let shouldTheFieldBeHidden = false;

        // set the lenth of api to restrict the display of add icon
        this.setState({ apiLength: applicationApiNames.length });

        if (applicationApiNames.length === 0) {
          shouldTheFieldBeHidden = true;
          this.setState({
            shouldFieldBeHidden: true,
          });
        }
        if (this.state.selectedAppuserType === SUBSCRIBER) {
          this.setState({
            user_action: SUBSCRIBER,
          });
          if (applicationApiNames.length > 0) {
            this.setState({
              shouldFieldBeHidden: false,
            });
          }
          if (applicationApiNames.length > 1) {
            this.setState({
              displayAddIcon: true,
            });
          }
        }
        if (this.state.selectedAppuserType === CREATOR) {
          if (applicationApiNames.length > 1 && this.state.user_action !== '') {
            this.setState(
              {
                displayAddIcon: true,
              });
          }
        }
        this.setState({ shouldTheFieldBeHidden });
        self.forceUpdate();
      });
  }

  handleSelectOption(e, value) {
    const TARGET = e.target;
    const NAME = TARGET.name;
    this.setState({
      userActionError: '',
      appConsIdError: '',
      customAppConsIdError: '',
      failureNotification: false,
    });
    if (NAME === 'user_action') {
      if (value === CREATOR) {
        if (document.getElementById('show-member-check-box').checked !== true) {
          document.getElementById('show-member-check-box').checked = true;
          this.showTableStatus();
        }
        this.setState({
          userTypeFieldBorder: 'form-field-default',
          consumerEmailFieldBorder: 'consumer-email-field-next',
          createCustomConsIDFieldStatus: false,
          application_consumer_id: '',
          displayAddIcon: false,
          shouldFieldBeHidden: true,
        });
      } else {
        if (this.state.apiLength > 1) {
          this.setState({ displayAddIcon: true });
        }
        if (this.state.apiLength > 0) {
          this.setState({ shouldFieldBeHidden: false });
        }
        this.setState({ userTypeFieldBorder: 'form-field-default', appConsIdField: 'form-field-next' });
      }
    }
    this.setState({ [NAME]: value });
  }

  handleSelectForConsumerId(e, value, setConsumerId) {
    const TARGET = e.target;
    const NAME = TARGET.name;
    if (NAME === 'application_consumer_id') {
      if (setConsumerId === 'appConsId1') {
        this.setState({
          appConsId1: value,
          application_consumer_id: value,
        });
      }
      if (setConsumerId === 'appConsId') {
        this.setState({
          appConsId: value,
          application_consumer_id: value,
        });
      }
      if (setConsumerId === 'appConsId2') {
        this.setState({
          appConsId2: value,
          application_consumer_id: value,
        });
      }
      if (setConsumerId === 'appConsId3') {
        this.setState({
          appConsId3: value,
          application_consumer_id: value,
        });
      }
      if (setConsumerId === 'appConsId4') {
        this.setState({
          appConsId4: value,
          application_consumer_id: value,
        });
      } 
      if (setConsumerId === 'appConsId5') {
        this.setState({
          appConsId5: value,
          application_consumer_id: value,
        });
      }
      if (document.getElementById('show-member-check-box').checked !== true) {
        document.getElementById('show-member-check-box').checked = true;
        this.showTableStatus();
      }
      if (value === 'Enter a custom value') {
        this.setState({
          createCustomConsIDFieldStatus: true,
          appConsIdField: 'form-field-default',
          customAppConsId: 'form-field-next',
        });
      } else {
        this.setState({
          createCustomConsIDFieldStatus: false,
          appConsIdField: 'form-field-default',
          consumerEmailFieldBorder: 'consumer-email-field-next',
        });
      }
    }
  }

  handleAppCheckBox(option, setAppApiName) {
    if (setAppApiName === 'appApiName1') {
      this.setState({
        appApiName1: option,
      });
    }
    if (setAppApiName === 'appApiName') {
      this.setState({
        appApiName: option,
      });
    }
    if (setAppApiName === 'appApiName2') {
      this.setState({
        appApiName2: option,
      });
    }
    if (setAppApiName === 'appApiName3') {
      this.setState({
        appApiName3: option,
      });
    }
    if (setAppApiName === 'appApiName4') {
      this.setState({
        appApiName4: option,
      });
    }
    if (setAppApiName === 'appApiName5') {
      this.setState({
        appApiName5: option,
      });
    }
    const truncAppname = this.state.app_name.substring(this.state.app_name.indexOf('-') + 1, this.state.app_name.length);
    const INPUT_GET_CONSUMERID = { user_email: this.props.userEmail,
    user_type: this.state.user_action,
    app_name: truncAppname,
    api_name: option };
    const INPUT_GET_CONSUMERID_URL = `${config.serverUrl}/get-consumergroup-for-api${buildQuery(INPUT_GET_CONSUMERID)}`;
    const inputGetConsumerIdRequest = new Request(INPUT_GET_CONSUMERID_URL, { method: 'get' });
    fetch(inputGetConsumerIdRequest)
      .then(processStatus)
      .then(response => response.json())
      .then(appConsumerIdDetails => {
        const APP_CONS_ID = appConsumerIdDetails.map(element => element.application_consumer_id);
        APP_CONS_ID.push('Enter a custom value');

        this.setState({
          appConsumerIdDetails,
          APP_CONS_ID,
          applicationConsumerIdOptions: APP_CONS_ID,
          spinnerStatus: false,
          error: undefined,
        });
      })
      .catch(error => this.setState({ appConsumerIdDetails: undefined, error, err: 'We cannot connect to server at this time to get application consumer groups. Please check if you logged in or try again later!' }));
    this.forceUpdate();
  }

  getAppLabel() {
    const allLabels = this.state.applicationApiNameSelected;
    return this.state.applicationApiNameSelected.length > 0 ? allLabels.join(', ') : 'Please select Application Api name(s)';
  }

  handleFieldOptions(e, value) {
    this.setState({
      user_action: '',
      application_instance_id: '',
      appInstanceIdStatus: true,
      app_instance_id: '',
      user_email: '',
      failureNotification: false,
      emailFieldError: '',
      err: '',
      allEmails: [],
      API_NAMES: [],
      appNameField: 'form-field-default',
      userTypeFieldBorder: 'form-field-next',
      application_consumer_id: '',
      customAppConsId: '',
      customApplicationConsumerId: '',
      createCustomConsIDFieldStatus: false,
      spinnerStatus: false,
      displayAddIcon: false,
      appApiName: '',
      appApiName1: '',
      appApiName2: '',
      appApiName3: '',
      appApiName4: '',
      appApiName5: '',
      appConsId: '',
      appConsId1: '',
      appConsId2: '',
      appConsId3: '',
      appConsId4: '',
      appConsId5: '',
      apiLength: 0,
      addedfieldCount: 1,
      newFieldAdded1: false,
      newFieldAdded2: false,
      newFieldAdded3: false,
      newFieldAdded4: false,
      newFieldAdded5: false,
    });

    let selectedAppuserType;
    let app_instance_id;
    let form_app_name;
    let selectedEprIdAppValue;
    const truncatedAppname = value.substring(value.indexOf('-') + 1, value.length);
    if (truncatedAppname.indexOf('(') > -1) {
      form_app_name = truncatedAppname.replace(truncatedAppname.substring(truncatedAppname.indexOf(' ('), truncatedAppname.length), '');
      selectedEprIdAppValue = value.replace(value.substring(value.indexOf('(') - 1, value.length), '');
    } else {
      form_app_name = truncatedAppname;
      selectedEprIdAppValue = value;
    }

    this.setState({
      form_app_name,
      app_name: selectedEprIdAppValue,
    });
    for (let i = 0; i < this.state.userDetails.length; i++) {
      const selectedAppName = `${this.state.userDetails[i].eprid}-${this.state.userDetails[i].app_name}`;
      if (selectedEprIdAppValue === selectedAppName) {
        this.setState({
          eprid: this.state.userDetails[i].eprid,
          application_instance_id: this.state.userDetails[i].application_instance_id,
          selectedAppName,
        });
        app_instance_id = this.state.userDetails[i].application_instance_id;
        selectedAppuserType = (this.state.userDetails[i].user_action === CREATOR) ? CREATOR : SUBSCRIBER;
        if (this.state.userDetails[i].application_instance_id !== '') {
          this.setState({ appInstanceIdStatus: false });
        }
      }
    }


    if (selectedAppuserType === SUBSCRIBER) {
      this.setState({ appConsIdField: 'form-field-next' });
    }

    this.setState({ selectedAppuserType });

    this.getapplicationApiNames(this.state.userDetails, value);
    this.setState({ applicationApiNameSelected: [] });

    if (this.state.isChecked === true && value !== this.state.app_name) {
      document.getElementById('table-records').style.display = 'none';
      this.setState({ spinnerStatus: true });
      this.fetchTableRows(app_instance_id);
    }
  }

  fetchTableRows(appInstanceId) {
    const INPUT_GET_TABLE_DETAILS = { application_instance_id: appInstanceId };
    const INPUT_GET_TABLE_DETAILS_URL = `${config.serverUrl}/get-app-details${buildQuery(INPUT_GET_TABLE_DETAILS)}`;
    fetch(INPUT_GET_TABLE_DETAILS_URL)
      .then(processStatus)
      .then(response => response.json())
      .then(tableDetails => {
        this.setState(
          { tableData: tableDetails }
        );
        return this.showTableRows();
      })
      .then(() => {
        document.getElementById('table-records').style.display = 'block';
      })
      .catch(error => {
        const errorMsg = 'We cannot connect to server at this time for table details. Please check if you logged in or try again later!';
        console.error(error);
        this.setState({
          gettingData: false,
          spinnerStatus: false,
          tableDetails: undefined,
          error: errorMsg,
          err: errorMsg,
        });
      });
  }

  showTableStatus() {
    if (document.getElementById('show-member-check-box').checked === true) {
      this.setState({ spinnerStatus: true,
        isChecked: true });
      this.fetchTableRows(this.state.application_instance_id);
    } else {
      this.setState({ isChecked: false });
      document.getElementById('table-records').style.display = 'none';
    }
  }

  showTableRows() {
    this.setState({
      spinnerStatus: false,
      error: undefined,
    });
  }

  handleAppNameSearch(filter) {
    const regexp = new RegExp(filter);
    const appNameOptions = this.state.EPRID_APP_NAMES.filter(value => regexp.test(value));
    this.setState({ appNameOptions });
  }

  handleAppConsumerIdSearch(filter) {
    const regexp = new RegExp(filter);
    const applicationConsumerIdOptions = this.state.APP_CONS_ID.filter(value => regexp.test(value));
    this.setState({ applicationConsumerIdOptions });
  }

  closeErrorNotifications() {
    this.setState({ err: '' });
  }

  tableOnSelect() {
    document.getElementById('table-header').style.backgroundColor = '#EAEAEA';
    document.getElementById('table-records').style.backgroundColor = '#FFF';
  }

  renderShowsTotal(start, to) {
    const message = `Showing ${start} to ${to} of ${this.state.tableData.length} entries.`;
    return (
      <p>
        <strong>{message}</strong>
      </p>
    );
  }
  render() {
    let dataText;
    if (this.state.gettingData) {
      dataText = common.messages.gettingdata;
    } else {
      if (this.state.error === '') {
        dataText = common.messages.searchnodata;
      } else {
        dataText = this.state.error;
      }
    }

    let applicationInstanceIdField;
    let invalidEmailNotification;
    let emptyEmailNotification;
    let createCustomConsIDField;
    let failureNotificationShow;
    let errorNotifications;
    let applicationApiAndConsField;
    let consumerEmailField;
    let userTypeField = null;
    let table;
    let userAddedAlert;
    let newAppNameandConsumerId1;
    let newAppNameandConsumerId2;
    let newAppNameandConsumerId3;
    let newAppNameandConsumerId4;
    let newAppNameandConsumerId5;


    const options = {
      page: 1, // Page you want to show as default
      sizePerPageList: [
        { text: '10', value: 10 },
        { text: '25', value: 25 },
        { text: '30', value: 30 },
        { text: '50', value: 50 },
      ], // Dropdown list values
      sizePerPage: 10, // which size per page you want to display as default
      pageStartIndex: 1, // where to start counting the pages
      paginationSize: 5, // the pagination bar size
      prePage: 'Prev', // Previous page button text
      nextPage: 'Next', // Next page button text
      firstPage: 'First', // First page button text
      lastPage: 'Last', // Last page button text
      noDataText: dataText, // Text for empty table or error scenario
      paginationShowsTotal: this.renderShowsTotal,
    };

    const spinnerLayer = (this.state.spinnerStatus) ? (
      <Layer id="spinnig-layer">
        <Spinning id="spinner" />
      </Layer>
        ) : null;

    if (this.state.err) {
      errorNotifications = (<div className="email-error-toast">
        <Toast onClose={this.closeErrorNotifications.bind(this)} >
          <Status value="critical" size="medium" />
          <strong> {this.state.err} </strong></Toast>
      </div>);
    }
    if (this.state.newUserAddedAlert) {
      userAddedAlert = (<div className="new-user-alert">
        <Notification status="ok" message={this.state.newUserAddedAlert} closer="true" onClose={this.resetNotifications} />
      </div>);
    }

    if (this.state.createCustomConsIDFieldStatus && this.state.user_action !== CREATOR) {
      createCustomConsIDField = (
        <div>
          <FormField
            label="Custom Application Consumer ID"
            className={this.state.customAppConsId}
            error={this.state.customAppConsIdError}
            hidden={this.state.shouldFieldBeHidden && this.state.user_action === SUBSCRIBER}>
            <textarea className="form-field-inner-tag"
              name="customApplicationConsumerId"
              placeholder="Please enter the custom value"
              value={this.state.customApplicationConsumerId}
              onChange={this.handleInputChange} />
          </FormField>
          <br />
        </div>);
    }

    if (this.state.failureNotification) {
      failureNotificationShow = (<font color="red" >Something went wrong! New user(s) have not been added.</font>);
    }

    if (this.state.selectedAppuserType === CREATOR && this.state.app_name !== '') {
      userTypeField = (
        <div>
          <FormField
            label="User Type"
            className={this.state.userTypeFieldBorder}
            error={this.state.userActionError}>
            <Select
                name="user_action"
                id="user-type-field"
                className="form-field-inner-tag"
                placeholder="Please select a user type"
                value={this.state.user_action}
                options={['subscriber', 'creator']}
                onChange={e => this.handleSelectOption(e, e.option)} />
          </FormField>
          <br />
        </div>);
    }
    else if (this.state.selectedAppuserType === SUBSCRIBER && this.state.app_name !== '') {
      userTypeField = (
        <div>
          <FormField
            label="User Type"
            className="form-field-default">
            <TextInput
                name="user_action"
                className="form-field-inner-tag"
                value="subscriber"
                disabled={true} />
          </FormField>
          <br />
        </div>);
    }
    if (this.state.selectedAppuserType !== '') {
      if (this.state.appInstanceIdStatus) {
        applicationInstanceIdField = (
          <div>
            <FormField label="Application Instance ID" className="form-field-default" >
                <TextInput
                  name="application_instance_id"
                  className="form-field-inner-tag"
                  placeholder="Please enter a valid Application Consumer Group ID"
                  value={this.state.application_instance_id}
                  onChange={this.handleInputChange} />
              </FormField>
          </div>);
      } else {
        applicationInstanceIdField = (
          <div>
            <FormField
                label="Application Instance ID"
                className="form-field-default">
                <TextInput
                  name="application_instance_id"
                  className="form-field-inner-tag"
                  value={this.state.application_instance_id}
                  disabled={true} />
              </FormField>
          </div>);
      }

      if (this.state.user_action === SUBSCRIBER) {
        applicationApiAndConsField = (<div>
          {this.addApiField(this.state.appApiName, 'appApiName')}
          {this.addConsumerField(this.state.appConsId, 'appConsId')}
        </div>);
      }
      consumerEmailField = (
        <div>
          <FormField
            className={this.state.consumerEmailFieldBorder}
            label="User E-mail Address"
            error={this.state.emailFieldError}
            hidden={this.state.shouldFieldBeHidden && this.state.user_action === SUBSCRIBER}>
            <textarea rows="4" cols="100"
                id="user-email-textarea"
                name="user_email"
                placeholder="Please enter one email per line"
                value={this.state.user_email}
                onChange={this.handleInputChange} />
          </FormField>
          <br />
          <Button type="submit" label="Add User" onClick={this.handleSubmit} />
          <br />
        </div>
        );
      table = (
        <List selectable="multiple" onSelect={this.tableOnSelect.bind(this)} id="members-table">
          <ListItem id="table-header">
            <span id="list-header-name" >
              <strong />
            </span>
            <span id="show-member-span">
              <CheckBox label="Show members" id="show-member-check-box"
                reverse={true}
                toggle={true}
                defaultChecked={false}
                onChange={this.showTableStatus.bind(this)} />
            </span>
          </ListItem>
          <div id="table-records">
            {this.state.isChecked && <BootstrapTable data={this.state.tableData} options={options} bordered={true} condensed={true} search={true} striped={true} hover={true} pagination={true} searchPlaceholder="Search All Columns" multiColumnSearch={true}>
              <TableHeaderColumn dataField="user_email" isKey={true} dataSort={true} filter={{ type: 'TextFilter' }}
                className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn">User E-mail Address</TableHeaderColumn>
              <TableHeaderColumn dataField="user_action" dataSort={true} filter={{ type: 'TextFilter' }}
                className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn">User Type</TableHeaderColumn>
              <TableHeaderColumn dataField="application_consumer_id" dataSort={true} filter={{ type: 'TextFilter' }}
                className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn">Application Consumer ID</TableHeaderColumn>
              <TableHeaderColumn dataField="action" dataAlign="center" headerAlign="center"
                width="250" dataFormat={this.deleteButtonFormatter}>Action (Disabled)
              </TableHeaderColumn>
            </BootstrapTable>}
          </div>
        </List>
        );
    }

    if (this.state.newFieldAdded1) {
      newAppNameandConsumerId1 = (<div>
        {this.addApiField(this.state.appApiName1, 'appApiName1')}
        {this.addConsumerField(this.state.appConsId1, 'appConsId1')}
      </div>);
    }
    if (this.state.newFieldAdded2) {
      newAppNameandConsumerId2 = (<div>
        {this.addApiField(this.state.appApiName2, 'appApiName2')}
        {this.addConsumerField(this.state.appConsId2, 'appConsId2')}
      </div>);
    }
    if (this.state.newFieldAdded3) {
      newAppNameandConsumerId3 = (<div>
        {this.addApiField(this.state.appApiName3, 'appApiName3')}
        {this.addConsumerField(this.state.appConsId3, 'appConsId3')}
      </div>);
    }
    if (this.state.newFieldAdded4) {
      newAppNameandConsumerId4 = (<div>
        {this.addApiField(this.state.appApiName4, 'appApiName4')}
        {this.addConsumerField(this.state.appConsId4, 'appConsId4')}
      </div>);
    }
    if (this.state.newFieldAdded5) {
      newAppNameandConsumerId5 = (<div>
        {this.addApiField(this.state.appApiName5, 'appApiName5')}
        {this.addConsumerField(this.state.appConsId5, 'appConsId5')}
      </div>);
    }

    return (
      <div id="page-wrap" >
        <div className="subscription-form">
          <form name="subscription_form" className="form-style">
            <Header>
                <Heading className="form-header" align="center" tag="h3">
                <strong>Add a User to your app group</strong>
              </Heading>
              </Header>
            <hr />
            <FormField
                label="Application Name"
                className={this.state.appNameField}>
                <Select
                name="app_name"
                id="app-name-field"
                className="form-field-inner-tag"
                placeholder="Please select an application"
                placeHolder="Search for eprid or application name"
                value={this.state.app_name}
                options={this.state.appNameOptions}
                onChange={e => this.handleFieldOptions(e, e.option)}
                onSearch={e => this.handleAppNameSearch(e.target.value)} />
              </FormField><br />
            {userTypeField}
            {applicationInstanceIdField}
            {applicationApiAndConsField}
            {newAppNameandConsumerId1}
            {newAppNameandConsumerId2}
            {newAppNameandConsumerId3}
            {newAppNameandConsumerId4}
            {newAppNameandConsumerId5}
            {createCustomConsIDField}
            {consumerEmailField}
            {spinnerLayer}
          </form>
          {this.state.displayAddIcon && <Button className="add-icon"
            icon={<AddIcon type="status" size="medium" colorIndex="brand" />}
            onClick={this.addAppNameField} />}
        </div>
        {invalidEmailNotification}
        {emptyEmailNotification}
        {failureNotificationShow}
        {errorNotifications}
        {userAddedAlert}
        {table}
      </div>
        );
  }
  }

AddApiConsumer.propTypes = {
  userEmail: React.PropTypes.string,
};

export default connect(props => ({ userEmail: props.userProfile.email }))(AddApiConsumer);
