import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import moment from 'moment';
import _ from 'lodash';
import { buildQuery, processStatus } from 'grommet/utils/Rest';
import WorkflowForm from './workflows/WorkflowForm';
import DashboardTile from './DashboardTile';
import PinchBar from '../chart/pinchbar';
import Label from 'grommet/components/Label';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import Layer from 'grommet/components/Layer';
import Spinning from 'grommet/components/icons/Spinning';
import AddIcon from 'grommet/components/icons/base/Add';
import { EventEmitter } from 'fbemitter';

require('!style!css!react-grid-layout/css/styles.css');
require('!style!css!react-resizable/css/styles.css');

import {
  appErrorsSet,
} from '../../actions/app';
import {
  menuAutoRefreshSet,
  menuAppnamesSet,
  menuAppNamesSelectedSet,
  menuWorkflowGroupsSet,
  menuWorkflowGroupsSelectedSet,
} from '../../actions/menu';
import {
  dashboardAppsSet,
  duplicateApiSet,
  showWorkflowFormSet,
  isWorkflowFormUpdateSet,
  workflowFormDataSet,
} from '../../actions/dashboard';

const config = require(`../../../config.${process.env.NODE_ENV}.json`);
const common = require('../home/common');
const dateFormat = 'YYYY-MM-DD HH:mm:ss';

let emitter;

function processUserCharts(dashboardApps) {
  const charts = _.cloneDeep(dashboardApps);
  const ops = [];
  let trans;
  const allcharts = [];
  const transdata = [];
  const appnames = [];
  const duplicateApiJSON = [];
  const duplicateApiObject = {};
  const deDuplicatedArray = [];

  charts.forEach(cur => {
    let instanceIdIndex;
    const consumerGroups = [];
    function checkIfInstanceIdExists (arr, newId) {
      return arr.some(e => {
        if (e.appInstanceId === newId) {
          instanceIdIndex = arr.map(e => e.appInstanceId).indexOf(newId);
        }
        return e.appInstanceId === newId;
      });
    }

    // Handle empty string return from when no APIs exist
    const apinames = cur.api_names === '' ? [] : cur.api_names;
    if (apinames.length > 0) {
      apinames.forEach(eachapi => {
        trans = Object.assign({}, eachapi);
        consumerGroups.push(cur.appconsumerid);
        transdata.push(trans);
        if (cur.user_action === 'subscriber') {
          const temp = {};
          temp.api_name = eachapi;
          temp.appconsumerid = cur.appconsumerid;
          duplicateApiJSON.push(temp);
        }
      });
    }

    if (cur.user_action === 'creator') {
      appnames.push({ appName: cur.app_name, appInstanceId: cur.appinstanceid });
      allcharts.push(cur);
      ops.push(cur);
    } else {
      if (!checkIfInstanceIdExists(appnames, cur.appinstanceid)) {
        appnames.push({ appName: cur.app_name, appInstanceId: cur.appinstanceid });
        allcharts.push(cur);
        ops.push(cur);
      } else {
        allcharts[instanceIdIndex].api_names = allcharts[instanceIdIndex]
          .api_names.concat(cur.api_names);
      }
    }

    if (allcharts[allcharts.length - 1].consumerGroups &&
      allcharts[allcharts.length - 1].consumerGroups.length > 0) {
      allcharts[allcharts.length - 1].consumerGroups = allcharts[allcharts.length - 1]
        .consumerGroups.concat(consumerGroups);
    } else {
      allcharts[allcharts.length - 1].consumerGroups = consumerGroups;
    }
  });

  for (let i = 0; i < duplicateApiJSON.length; i++) {
    if (duplicateApiObject[duplicateApiJSON[i].api_name.api_name] === undefined) {
      duplicateApiObject[duplicateApiJSON[i].api_name.api_name] = '';
    }

    if (duplicateApiObject[duplicateApiJSON[i].api_name.api_name] !== '') {
      if (duplicateApiObject[duplicateApiJSON[i].api_name.api_name]
        .indexOf(duplicateApiJSON[i].appconsumerid) === -1) {
        duplicateApiObject[duplicateApiJSON[i].api_name.api_name] += ',';
      }
    }

    if (duplicateApiObject[duplicateApiJSON[i].api_name.api_name]
      .indexOf(duplicateApiJSON[i].appconsumerid) === -1) {
      duplicateApiObject[duplicateApiJSON[i].api_name.api_name] +=
        duplicateApiJSON[i].appconsumerid;
    }
  }

  for (const i in duplicateApiObject) {
    const tempObject = {};
    tempObject.api_name = i.toString();
    tempObject.appconsumerid = duplicateApiObject[i];
    deDuplicatedArray.push(tempObject);
  }

  appnames.unshift({ appName: 'All Apps', appInstanceId: '' });
  const data = {};
  data.ops = ops;
  data.transdata = transdata;
  data.appnames = appnames;
  data.allcharts = allcharts;
  data.deDuplicatedArray = deDuplicatedArray;
  return data;
}

class Dashboard extends React.Component {
  constructor(props) {
    super(props);
    const storeStartTime = this.props.menuOptions ?
      moment.utc().subtract(this.props.menuOptions.menuTimeRange, 'Hours')
        .format(dateFormat) :
      moment.utc().subtract(0.5, 'Hours')
        .format(dateFormat);

    const processedChartInfo = processUserCharts(this.props.dashboardApps);

    this.state = {
      allcharts: processedChartInfo.allcharts,
      charts: processedChartInfo.allcharts,
      opscharts: processedChartInfo.ops,
      transcharts: processedChartInfo.transdata,
      appnames: processedChartInfo.appnames,
      startTime: storeStartTime,
      endTime: moment.utc().format(dateFormat),
      timeRange: this.props.menuOptions ? this.props.menuOptions.menuTimeRange : 0.5,
      gettingData: processedChartInfo.allcharts.length === 0,
    };

    emitter = new EventEmitter();
    this.previousAutoRefreshState = this.props.menuAutoRefresh;
    this.clickAddNewWorkflowButton = this.clickAddNewWorkflowButton.bind(this);
    this.handleAddNewWorkflowButton = this.handleAddNewWorkflowButton.bind(this);
    this.handlePinchbarChanged = this.handlePinchbarChanged.bind(this);
    this.loadingData = false;
    this.isChartAdded = true;
    this.chartLength = 0;
  }

  componentDidMount() {
    if (this.props.dashboardType === 'transactions' || this.props.dashboardType === 'workflows') {
      this.getAppsData();
    }
    if (this.props.dashboardType === 'workflows') {
      this.getWorkflowGroupsData();
    }
  }

  componentDidUpdate() {
    if (this.loadingData === false) {
      this.componentDidMount();
    }
  }

  componentWillReceiveProps(nextProps) {
    this.previousAutoRefreshState = this.props.menuAutoRefresh;
    if (nextProps.menuOptions && this.props.menuAutoRefresh === nextProps.menuAutoRefresh) {
      // Handle custom time range
      if (nextProps.menuOptions.menuCustomStartTime && nextProps.menuOptions.menuTimeRange) {
        this.setTimesForCustomMenu(nextProps.menuOptions.menuCustomStartTime,
          nextProps.menuOptions.menuTimeRange);
      } else if (nextProps.menuOptions.menuTimeRange) {
        this.setTimes(nextProps.menuOptions.menuTimeRange);
      }
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    if (nextState.error !== undefined) {
      return true;
    } else if (nextProps.dashboardApps.length === 0) {
      return false;
    } else {
      return (this.props.menuAutoRefresh === nextProps.menuAutoRefresh);
    }
  }

  clickAddNewWorkflowButton() {
    this.props.showWorkflowFormSet(true);
  }

  getWorkflowGroupsData() {
    const uri = `${config.serverUrl}/get-my-workflows${buildQuery({ user_email: this.props.userProfile.email })}`;
    const request = new Request(uri, { method: 'get' });
    fetch(request)
      .then(processStatus)
      .then(response => response.json())
      .then(workflowGroups => {
        common.sortArrayOfObjectsByKey(workflowGroups, 'workflow_group_name');
        this.props.menuWorkflowGroupsSet(workflowGroups);
        // If user's workflow group list has changed, create new menuWorkflowGroupsSelected array
        // and enable all workflow groups.
        if (this.props.menuWorkflowGroupsSelected.length !== workflowGroups.length) {
          this.props.menuWorkflowGroupsSelectedSet(workflowGroups,
            workflowGroups.map(() => true));
        }
        this.setState({
          workflowGroups,
          gettingData: false,
        });
      })
      .catch(error => {
        const appErrors = this.props.appErrors.concat([`Error (${error.toString()})`]);
        this.props.appErrorsSet(appErrors);
        console.error(error);
        this.setState({ error });
      });
  }

  getAppsData() {
    if (this.loadingData === true) {
      return;
    }
    this.loadingData = true;
    const uri = `${config.serverUrl}/get-my-chart?user_email=${this.props.userProfile.email}`;
    fetch(encodeURI(uri))
      .then(processStatus)
      .then(response => response.json())
      .then(result => processUserCharts(result))
      .then(result => {
        /* Order results by app name */
        // Because result.appnames[0] is 'All apps', we need to handle that case.
        const allAppsAppName = result.appnames.shift();
        common.sortArrayOfObjectsByKey(result.appnames, 'appName');
        result.appnames.unshift(allAppsAppName);
        common.sortArrayOfObjectsByKey(result.allcharts, 'app_name');
        common.sortArrayOfObjectsByKey(result.ops, 'app_name');

        if (this.state.allcharts.length !== result.allcharts.length || this.state.transcharts.length !== result.transdata.length) {
          if (this.state.allcharts.length != 0 || this.state.transcharts.length != 0) {
            this.isChartAdded = true;
          } else {
            this.isChartAdded = false;
          }
          this.chartLength = `${result.allcharts.length + result.transdata.length}`;
          this.setState({
            charts: result.allcharts,
            allcharts: result.allcharts,
            opscharts: result.ops,
            transcharts: result.transdata,
            gettingData: false,
            appnames: result.appnames,
          });
          this.props.duplicateApiSet(result.deDuplicatedArray);
          this.props.menuAppnamesSet(result.appnames);
        // If user's app list has changed, create new menuAppNamesSelected array
        // and enable all apps.
          if (this.props.menuAppNamesSelected.length !== result.appnames.length) {
            this.props.menuAppNamesSelectedSet(result.appnames, result.appnames.map(() => true));
          }
          this.props.dashboardAppsSet(result.allcharts);
        }
        this.loadingData = false;
      })
      .catch(err => {
        this.loadingData = false;
        console.error(err);
        this.setState({ error: err });
      });
  }

  setTimesForCustomMenu(menuCustomStartTime, timeRange) {
    const startTime = moment(menuCustomStartTime).format(dateFormat);
    const endTime = moment(menuCustomStartTime).add(timeRange, 'Hours')
      .format(dateFormat);
    this.setState({ startTime, endTime, timeRange, pinchbarSelected: false });
  }

  setTimes(timeRange) {
    const endTime = moment.utc().format(dateFormat);
    const startTime = moment.utc().subtract(timeRange, 'Hours')
      .format(dateFormat);
    this.setState({ startTime, endTime, timeRange, pinchbarSelected: false });
  }

  handlePinchbarChanged(pinchStart, pinchEnd, pinchbarSelected) {
    if (pinchStart && pinchEnd) {
      this.previousAutoRefreshState = this.props.menuAutoRefresh;
      this.props.menuAutoRefreshSet(false); // Turn off Auto Refresh
    } else {
      const timeRange = this.props.menuOptions.menuTimeRange;
      if (this.props.menuOptions.menuCustomStartTime) { // For custom time range
        pinchStart = moment(this.props.menuOptions.menuCustomStartTime).format(dateFormat);
        pinchEnd = moment(this.props.menuOptions.menuCustomStartTime).add(timeRange, 'Hours')
          .format(dateFormat);
      } else {
        pinchEnd = moment.utc().format(dateFormat);
        pinchStart = moment.utc().subtract(timeRange, 'Hours')
          .format(dateFormat);
      }
      this.props.menuAutoRefreshSet(this.previousAutoRefreshState);
    }
    this.setState({
      startTime: pinchStart,
      endTime: pinchEnd,
      pinchbarSelected,
    });
  }

  handleAddNewWorkflowButton() {
    this.props.workflowFormDataSet({});
    this.props.isWorkflowFormUpdateSet(false);
    this.props.showWorkflowFormSet(true);
  }

  getAppTilesRender() {
    const appCounts = {};
    this.state.allcharts.forEach(chart => {
      appCounts[chart.app_name] ? appCounts[chart.app_name] += 1 : appCounts[chart.app_name] = 1;
    });
    return this.state.charts.filter((element, i) =>
      this.props.menuAppNamesSelected[i + 1]).map(item =>
        <DashboardTile key={item.appinstanceid + this.chartLength} isChartAdded={this.isChartAdded} app={item} opscharts={this.state.opscharts}
          startTime={this.state.startTime} endTime={this.state.endTime} emitter={emitter}
          deDuplicatedArray={this.state.deDuplicatedArray} tileType={'transactions'}
          showInstanceOnTitle={appCounts[item.app_name] > 1} id={item.appinstanceid} />
      );
  }

  getWorkflowFormRender() {
    return (
      <Layer className="layer-style" closer={true}
        onClose={() => this.props.showWorkflowFormSet(false)}>
        <WorkflowForm apps={this.state.allcharts}
          workflowGroups={this.state.workflowGroups} />
      </Layer>
    );
  }

  getWorkflowGroupTilesRender() {
    return this.state.workflowGroups
      .filter((ele, index) => this.props.menuWorkflowGroupsSelected[index])
      .map(workflowGroup =>
        <DashboardTile isChartAdded={this.isChartAdded} endTime={this.state.endTime} emitter={emitter}
          key={workflowGroup.workflow_group_name + this.chartLength} tileType={'workflow'}
          startTime={this.state.startTime} workflowGroup={workflowGroup}
          id={workflowGroup.workflow_group_name} />
      );
  }

  getNoDataRender() {
    return (
      <div className="nodatadiv">
        No data has been selected
      </div>
    );
  }

  getDashboardContentRender() {
    if (this.state.error !== undefined) {
      return (
        <div className="nodatadiv">
          An internal error has occurred:
          <br />
          <span className="c-red">{this.state.error.toString()}</span>
        </div>
      );
    } else if (this.state.gettingData) {
      return (
        <div className="nodatadiv">
          <Spinning size="small" />
          <br />
          Please wait... Retrieving data
        </div>
      );
    } else if (this.props.dashboardType === 'transactions' && this.state.charts !== undefined) {
      return (
        <div className="txn-chartcontainer">
          {this.getAppTilesRender()}
        </div>
      );
    } else if (this.props.dashboardType === 'workflows') {
      const tileRender = this.state.workflowGroups !== undefined ?
        this.getWorkflowGroupTilesRender() :
        this.getNoDataRender();
      return (
        <div className="txn-chartcontainer">
          <Box direction="row" responsive={false} full="horizontal" justify="end">
            <Button className="mr-10" icon={<AddIcon />} label={'Add a new Workflow'}
              onClick={this.handleAddNewWorkflowButton} />
          </Box>
          {tileRender}
        </div>
      );
    }
  }

  getDashboardModalRender() {
    if (this.props.showWorkflowForm) {
      return this.getWorkflowFormRender();
    }
  }

  render() {
    return (
      <div className="dashboard transaction-dashboard">
        <div className="pinchbar-container" id="pinchbar-container">
          <Label className="time-range-label"><b>Time Range:</b> {this.state.startTime} ~ {this.state.endTime} (Etc/UTC GMT +0)</Label>
          <PinchBar {...this.state} timeRange={this.props.menuOptions.menuTimeRange}
            handlePinchbarChanged={this.handlePinchbarChanged} />
        </div>
        {this.getDashboardContentRender()}
        {this.getDashboardModalRender()}
      </div>
    );
  }
}

Dashboard.propTypes = {
  appErrors: PropTypes.array.isRequired,
  appErrorsSet: PropTypes.func.isRequired,
  userProfile: PropTypes.object.isRequired,
  menuOptions: PropTypes.object.isRequired,
  menuRefreshNow: PropTypes.object.isRequired,
  menuAutoRefreshSet: PropTypes.func.isRequired,
  menuShowAppnames: PropTypes.bool.isRequired,
  menuAppnames: PropTypes.array.isRequired,
  menuAppnamesSet: PropTypes.func.isRequired,
  menuAppNamesSelected: PropTypes.array.isRequired,
  menuAppNamesSelectedSet: PropTypes.func.isRequired,
  menuWorkflowGroupsSet: PropTypes.func.isRequired,
  menuWorkflowGroupsSelected: PropTypes.array.isRequired,
  menuWorkflowGroupsSelectedSet: PropTypes.func.isRequired,
  menuAutoRefresh: PropTypes.bool.isRequired,
  dashboardAppsSet: PropTypes.func,
  dashboardApps: PropTypes.array,
  dashboardType: PropTypes.string.isRequired,
  duplicateApiSet: PropTypes.func,
  dashboardDuplicateApis: PropTypes.array,
  showWorkflowForm: PropTypes.bool.isRequired,
  showWorkflowFormSet: PropTypes.func.isRequired,
  workflowFormDataSet: PropTypes.func.isRequired,
  isWorkflowFormUpdateSet: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  appErrors: state.appErrors,
  userProfile: state.userProfile,
  menuOptions: state.menuOptions,
  menuRefreshNow: state.menuRefreshNow,
  menuShowAppnames: state.menuShowAppnames,
  menuAppnames: state.menuAppnames,
  menuAppNamesSelected: state.menuAppNamesSelected,
  menuWorkflowGroupsSelected: state.menuWorkflowGroupsSelected,
  menuAutoRefresh: state.menuAutoRefresh,
  dashboardApps: state.dashboardApps,
  dashboardDuplicateApis: state.dashboardDuplicateApis,
  showWorkflowForm: state.showWorkflowForm,
});

const mapDispatchToProps = dispatch => ({
  appErrorsSet: appErrors => dispatch(appErrorsSet(appErrors)),
  menuAutoRefreshSet: bool => dispatch(menuAutoRefreshSet(bool)),
  menuAppnamesSet: array => dispatch(menuAppnamesSet(array)),
  duplicateApiSet: array => dispatch(duplicateApiSet(array)),
  menuAppNamesSelectedSet: (appNames, appNamesSelected) =>
  dispatch(menuAppNamesSelectedSet(appNames, appNamesSelected)),
  menuWorkflowGroupsSet: array => dispatch(menuWorkflowGroupsSet(array)),
  menuWorkflowGroupsSelectedSet: (workflowGroups, workflowGroupsSelected) =>
  dispatch(menuWorkflowGroupsSelectedSet(workflowGroups, workflowGroupsSelected)),
  dashboardAppsSet: array => dispatch(dashboardAppsSet(array)),
  showWorkflowFormSet: bool => dispatch(showWorkflowFormSet(bool)),
  isWorkflowFormUpdateSet: bool => dispatch(isWorkflowFormUpdateSet(bool)),
  workflowFormDataSet: object => dispatch(workflowFormDataSet(object)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
