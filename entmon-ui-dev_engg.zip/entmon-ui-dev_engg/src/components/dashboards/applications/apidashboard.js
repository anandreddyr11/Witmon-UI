import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { menuAutoRefreshSet, menuAppnamesSet } from '../../../actions/menu';
import moment from 'moment';
import { processStatus } from 'grommet/utils/Rest';
import ChartTile from '../../chart/ChartTile';
import PinchBar from '../../chart/pinchbar';
import Label from 'grommet/components/Label';
let config = require('Config');

let dateFormat = 'YYYY-MM-DD HH:mm:ss';
let self;

function processUserCharts(charts) {
  let ops;
  let trans;
  let allcharts = [];
  let transdata = [];
  let appnames = [];
  charts.forEach(cur => {
    appnames.push(cur.app_name);
    allcharts.push(cur);
    if (cur.default === 1) {
      ops = Object.assign({}, cur);
      let apinames = cur.api_names;
      if (apinames.length > 0) {
        apinames.forEach(eachapi => {
          trans = Object.assign({}, eachapi);
          transdata.push(trans);
        });
      }
    }
  });

  let data = {};
  data.ops = ops;
  data.transdata = transdata;
  data.appnames = appnames;
  data.allcharts = allcharts;
  return data;
}

class ApiDashboard extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      charts: [],
      transcharts: [],
      appnames: [],
      startTime: "",
      endTime: "",
      timeRange: this.props.menuOptions ? this.props.menuOptions.menuTimeRange : 0.5,
      isTimeRangeAlreadySet: false
    };
    self = this;
  }

  componentDidMount() {
    // Get time range from query string and split it into startTime and endTime
    let timeRange = this.context.location.query.time_range;
    let startTime = timeRange.substring(0, timeRange.indexOf("~"));
    let endTime = timeRange.substring(timeRange.indexOf("~") + 1);
    this.setState({ startTime: startTime });
    this.setState({ endTime: endTime });

    let duration = moment.duration(moment(endTime).diff(moment(startTime)));
    let timeRangeInHrs = duration.asHours();
    this.setState({ timeRange: timeRangeInHrs });
    this.setState({ isTimeRangeAlreadySet: true });

    this.getChartData();
  }


  /* Backup url - https://api.myjson.com/bins/d1sft */
  getChartData() {
    let useremail = this.context.location.query.user_email;
    let appInstanceid = this.context.location.query.application_instance_id;

    let getchartsurl = `${config.serverUrl}/get-my-chart?user_email=${useremail}`;
    fetch(encodeURI(getchartsurl))
      .then(processStatus)
      .then(response => response.json())
      .then(result => processUserCharts(result))
      .then(result => {
        let allcharts = result.allcharts;
        let appNames = [];
        let appCharts = [];
        let apiNames = [];

        for (let chartIndex = 0; chartIndex < allcharts.length; chartIndex++) {
          if (allcharts[chartIndex].appinstanceid == appInstanceid) {
            appNames.push({ appName: allcharts[chartIndex].app_name, appInstanceId: allcharts[chartIndex].appinstanceid });
            appCharts.push(allcharts[chartIndex]);
            let allApiNames = allcharts[chartIndex].api_names;

            for (let apiIndex = 0; apiIndex < allApiNames.length; apiIndex++) {
              apiNames.push({ "api_name": allApiNames[apiIndex].api_name });
            }
          }
        }

        this.setState({ chartData: appCharts[0] });
        this.setState({ transcharts: apiNames });
        this.setState({ appnames: appNames });
        this.props.menuAppnamesSet(appNames);
        this.setState({ charts: appCharts });
      })
      .catch(error => this.setState({ result: undefined, error: error }));
  }


  componentWillReceiveProps(nextProps) {
    if (this.props.menuOptions && nextProps.menuOptions.menuTimeRange) {
      // Don't reset if start time, end time and time range has set using query string
      if (!this.state.isTimeRangeAlreadySet) {
        this.setTimes(nextProps.menuOptions.menuTimeRange);
      }
      else {
        this.setState({ isTimeRangeAlreadySet: false });
        self.props.menuAutoRefreshSet(false); // Turn off Auto Refresh
      }
    }
  }

  setTimes(timeRange) {
    let endTime = moment.utc().format(dateFormat);
    let startTime = moment.utc().subtract(timeRange, "Hours").format(dateFormat);
    this.setState({ startTime, endTime, timeRange });
  }

  handlePinchbarChanged(pinchStart, pinchEnd) {
    if (pinchStart !== "" && pinchEnd !== "") {
      let startTime = pinchStart;
      let endTime = pinchEnd;
      self.props.menuAutoRefreshSet(false); // Turn off Auto Refresh
      self.setState({ startTime, endTime });
    } else {
      let timeRange = self.props.menuOptions.menuTimeRange;
      let endTime = moment.utc().format(dateFormat);
      let startTime = moment.utc().subtract(timeRange, "Hours").format(dateFormat);
      self.props.menuAutoRefreshSet(true);
      self.setState({ startTime, endTime });
    }
  }

  selectChart(item) {
    if (item) {
      let res;
      console.log(item);
      res = (
        <ChartTile {...item}
          startTime={this.state.startTime}
          endTime={this.state.endTime}
          showDrilldownLink={true}
          refreshInterval={this.state.interval}
          chartdata={this.state.chartData}
          chartType={'transactions'}
        />
      );

      return res;
    }
  }

  render() {
    let transchartsall = this.state.transcharts || [];

    return (
      <div className="transaction-dashboard">
        <div className="pinchbar-container" id="pinchbar-container">
          <Label className="time-range-label"><b>Time Range:</b> {this.state.startTime} ~ {this.state.endTime} (Etc/UTC GMT +0)</Label>
          <PinchBar {...this.state} handlePinchbarChanged={this.handlePinchbarChanged} />
        </div>
        <div className="txn-chartcontainer">
          {transchartsall.map(item => this.selectChart(item))}
        </div>
      </div>
    );
  }
}

ApiDashboard.propTypes = {
  userProfile: PropTypes.object.isRequired,
  menuOptions: PropTypes.object.isRequired,
  menuRefreshNow: PropTypes.object.isRequired,
  menuAutoRefreshSet: PropTypes.func.isRequired,
  menuShowAppnames: PropTypes.bool.isRequired,
  menuAppnames: PropTypes.array.isRequired,
  menuAppnamesSet: PropTypes.func.isRequired
};

ApiDashboard.contextTypes = {
  location: React.PropTypes.object
};

const mapStateToProps = (state) => {
  return {
    userProfile: state.userProfile,
    menuOptions: state.menuOptions,
    menuRefreshNow: state.menuRefreshNow,
    menuShowAppnames: state.menuShowAppnames,
    menuAppnames: state.menuAppnames,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    menuAutoRefreshSet: (bool) => dispatch(menuAutoRefreshSet(bool)),
    menuAppnamesSet: (array) => dispatch(menuAppnamesSet(array))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ApiDashboard);
