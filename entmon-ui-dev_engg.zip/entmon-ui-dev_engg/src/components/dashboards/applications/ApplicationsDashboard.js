import React from 'react';
import ApiDashboard from './apidashboard';

export default class ApplicationsDashboard extends React.Component {
  render() {
    return (
      <div className="app-dashboard">
        <ApiDashboard />
      </div>
    );
  }
}
