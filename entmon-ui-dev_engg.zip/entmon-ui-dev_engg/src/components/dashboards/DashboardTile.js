import React from 'react';
import { connect } from 'react-redux';
import { Responsive, WidthProvider } from 'react-grid-layout';
import ChartTile from '../chart/ChartTile';
import Box from 'grommet/components/Box';
import Menu from 'grommet/components/Menu';
import Title from 'grommet/components/Title';
import Search from 'grommet/components/Search';
import Button from 'grommet/components/Button';
import MenuIcon from 'grommet/components/icons/base/Menu';
import GridIcon from 'grommet/components/icons/base/Grid';
import Pagination from 'react-js-pagination';

const Config = require(`../../../config.${process.env.NODE_ENV}.json`);
const common = require('../home/common');

let layouts = [];
let eventArgument = null;
let chartResized = false;

/* eslint-disable */
const ResponsiveReactGridLayout = WidthProvider(Responsive);
/* eslint-enable */
const CHART_HEIGHT = 2;
const MINIMUM_CHART_WIDTH = 3;
const NUMBER_OF_COLUMNS_FOR_XXLG = 12;
const NUMBER_OF_COLUMNS_FOR_LG = 9;
const NUMBER_OF_COLUMNS_FOR_MD = 6;
const NUMBER_OF_COLUMNS_FOR_XS = 3;

class DashboardTile extends React.Component {
  constructor(props) {
    super(props);

    // Define the tile object.
    let tileObject;
    if (props.tileType === 'transactions') {
      tileObject = props.app;
    } else if (props.tileType === 'workflow') {
      tileObject = props.workflowGroup;
    } else if (props.tileType === 'operations-nodes') {
      tileObject = props.operationsNodes;
    }

    // Define the tile item keys and which tile item to display.
    let keys;
    let whichShowTileItem;

    // Account for ops & exception chart. (i + 1)
    let MIN_CHARTS = 1;

    if (this.props.tileType === 'transactions') {
      if (props.app.user_action === 'creator') {
        MIN_CHARTS = 2;
      }
      keys = props.app.api_names.map((apiName, i) => i + MIN_CHARTS);
      let len = keys.length;
      props.app.api_names.map((apiName, i) => keys.push((i + MIN_CHARTS) + len));
      len = keys.length;
      props.app.api_names.map((apiName, i) => keys.push((i + MIN_CHARTS) + len));
      whichShowTileItem = props.app.api_names.map(() => true);
      props.app.api_names.map(() => whichShowTileItem.push(true));
      props.app.api_names.map(() => whichShowTileItem.push(true));
    } else if (this.props.tileType === 'workflow') {
      keys = props.workflowGroup.workflows.map((workflow, i) => i);
      whichShowTileItem = props.workflowGroup.workflows.map(() => true);
    } else if (this.props.tileType === 'operations-nodes') {
      keys = props.operationsNodes.nodes.map((node, i) => i);
      whichShowTileItem = props.operationsNodes.nodes.map(() => true);
    }

    // Define the layout of the tile.
    let layout = this.getLocalStorageLayout();
    // If layout does not exist, reset to default layout.
    if (layout === undefined || layout === null || this.props.isChartAdded === true) {
      layout = this.getDefaultLayout(tileObject, whichShowTileItem, keys);
    }
    // If amount of tile items has changed, reset to default layout.
    const amountOfTileItems = this.getAmountOfTileItems(tileObject, whichShowTileItem);
    for (const breakpoint in layout) {
      if (layout[breakpoint].length !== amountOfTileItems) {
        layout = this.getDefaultLayout(tileObject, whichShowTileItem, keys);
      }
    }

    let apiLength = 0;
    const userAction = (this.props.app !== undefined ? this.props.app.user_action : undefined);
    if (props.app !== undefined && props.app.api_names.length > 0) {
      const duplicateApis = this.props.dashboardDuplicateApis.map(x => x.api_name);
      const trimmedDuplicateApis = this.props.app.api_names.map(x => x.api_name)
          .reduce((acc, el, i, arr) => {
            if (arr.indexOf(el) !== i && acc.indexOf(el) < 0)
              acc.push(el);
            return acc;
          }, []);
      if (trimmedDuplicateApis.length > 0) {
        apiLength = duplicateApis.length;
      } else {
        apiLength = props.app.api_names.length;
      }
    }

    this.state = {
      showingItems: {
        from: 0,
        to: 0,
      },
      activePage: 1,
      itemsCountPerPage: Config.dashboardTile.pagination.itemsCountPerPage,
      totalItemsCount: apiLength + (userAction === 'creator' ? 2 : 1),
      keys,
      layout,
      tileObject,
      whichShowTileItem,
      tileItemsFilterInput: '',
      app: props.app,
    };

    this.handlePageChange = this.handlePageChange.bind(this);
    this.handleTileItemFilterInputChange = this.handleTileItemFilterInputChange.bind(this);
    this.onLayoutChange = this.onLayoutChange.bind(this);
    this.resetTileLayout = this.resetTileLayout.bind(this);
  }

  getLocalStorageLayout() {
    const key = `${this.props.userProfile.email}-dashboardTile-${this.props.tileType}-${this.props.id}-layout`;
    return JSON.parse(localStorage.getItem(key));
  }

  setLocalStorageLayout(layout) {
    const key = `${this.props.userProfile.email}-dashboardTile-${this.props.tileType}-${this.props.id}-layout`;
    localStorage.setItem(key, JSON.stringify(layout));
  }

  resetTileLayout() {
    const layout = this.getDefaultLayout(
      this.state.tileObject,
      this.state.whichShowTileItem,
      this.state.keys
    );
    this.props.emitter.emit(common.eventNames.resetDashboardTileLayout, this.props.id);
    this.setLocalStorageLayout(layout);
    this.setState({ layout });
  }

  getDefaultLayout(tileObject, whichShowTileItem, keysState) {
    const numberOfCharts = this.getAmountOfTileItems(tileObject, whichShowTileItem);
    const keys = keysState.filter((key, i) => whichShowTileItem[i]);
    const layout = {
      xxlg: this.generateLayout(NUMBER_OF_COLUMNS_FOR_XXLG, numberOfCharts, [...keys]),
      xlg: this.generateLayout(NUMBER_OF_COLUMNS_FOR_XXLG, numberOfCharts, [...keys]),
      lg: this.generateLayout(NUMBER_OF_COLUMNS_FOR_LG, numberOfCharts, [...keys]),
      md: this.generateLayout(NUMBER_OF_COLUMNS_FOR_MD, numberOfCharts, [...keys]),
      sm: this.generateLayout(NUMBER_OF_COLUMNS_FOR_MD, numberOfCharts, [...keys]),
      xs: this.generateLayout(NUMBER_OF_COLUMNS_FOR_XS, numberOfCharts, [...keys]),
      xxs: this.generateLayout(NUMBER_OF_COLUMNS_FOR_XS, numberOfCharts, [...keys]),
    };
    return layout;
  }

  generateLayout(numberOfColumnsPerRow, numberOfCharts, keys) {
    layouts = [];
    if (this.props.tileType === 'transactions') {
      // Account for ops & exception chart..
      if (this.props.app.user_action === 'creator') {
        keys.unshift(1);
      }
      keys.unshift(0);
    }
    if (numberOfCharts > 0) {
      const numberOfChartsPerRow = numberOfColumnsPerRow / MINIMUM_CHART_WIDTH;
      const rowsWithMaximumCharts = Math.floor(numberOfCharts / numberOfChartsPerRow);
      const chartsInLastRow = numberOfCharts % numberOfChartsPerRow;
      let width = numberOfColumnsPerRow / numberOfChartsPerRow;
      for (let i = 0; i < rowsWithMaximumCharts; i++) {
        for (let j = 0; j < numberOfChartsPerRow; j++) {
          layouts.push({
            i: keys.shift().toString(),
            x: j * width,
            y: i * CHART_HEIGHT,
            w: width,
            h: CHART_HEIGHT,
            minW: MINIMUM_CHART_WIDTH,
            minH: CHART_HEIGHT,
            maxH: CHART_HEIGHT,
          });
        }
      }
      width = numberOfColumnsPerRow / chartsInLastRow;
      for (let i = 0; i < chartsInLastRow; i++) {
        layouts.push({
          i: keys.shift().toString(),
          x: i * width,
          y: rowsWithMaximumCharts * CHART_HEIGHT,
          w: width,
          h: CHART_HEIGHT,
          minW: MINIMUM_CHART_WIDTH,
          minH: CHART_HEIGHT,
          maxH: CHART_HEIGHT,
        });
      }
    }
    return layouts;
  }

  getAmountOfTileItems(tileObj, whichShowTileItems) {
    if (this.props.tileType === 'transactions') {
      const amountOfApiCharts = tileObj.api_names
        .filter((apiName, i) => whichShowTileItems[i]).length;
      const amountOfCreatorCharts = tileObj.user_action === 'creator' ? 2 : 1;
      return amountOfApiCharts + amountOfApiCharts + amountOfApiCharts + amountOfCreatorCharts;
    } else if (this.props.tileType === 'workflow') {
      return tileObj.workflows.filter((workflow, i) => whichShowTileItems[i]).length;
    } else if (this.props.tileType === 'operations-nodes') {
      return tileObj.nodes.filter((node, i) => whichShowTileItems[i]).length;
    }
  }

  onLayoutChange(breakpointLayout, layout) {
    this.setLocalStorageLayout(layout);
    this.setState({ layout });
    if (eventArgument && chartResized) {
      this.props.emitter.emit(common.eventNames.resizeChart, eventArgument);
      chartResized = false;
    }
  }

  onResizeStop(layout, oldItem, newItem, placeholder, e, element) {
    eventArgument = element.parentElement.id;
    chartResized = true;
  }

  handleTileItemFilterInputChange(e) {
    const regExp = new RegExp(e.target.value.toLowerCase());
    let whichShowTileItem;
    if (this.props.tileType === 'transactions') {
      whichShowTileItem = this.props.app.api_names
        .map(apiName => regExp.test(apiName.api_name.toLowerCase()));
    } else if (this.props.tileType === 'workflow') {
      whichShowTileItem = this.props.workflowGroup.workflows
        .map(workflow => regExp.test(workflow.workflow_name.toLowerCase()));
    } else if (this.props.tileType === 'operations-nodes') {
      whichShowTileItem = this.props.operationsNodes.nodes
        .map(node => regExp.test(node.toLowerCase()));
    }
    this.setState({
      whichShowTileItem,
      tileItemsFilterInput: e.target.value,
    }, this.resetTileLayout);
  }

  getTileHeadingRender(title, filterPlaceholder, userAction) {
    let userActionRender;
    if (userAction !== undefined) {
      userActionRender = (
        <Title pad={{ horizontal: 'small', vertical: 'small' }}>
          {userAction.replace(/\b\w/g, l => l.toUpperCase())}
        </Title>
      );
    }
    return (
      <Box direction="row" align="center" responsive={false}>
        <Box direction="row" full="horizontal" responsive={false}>
          <h3 className="mb-0">{title}</h3>
        </Box>
        <Box direction="row" full="horizontal" justify="end" responsive={false}>
          <Menu closeOnClick={false} icon={<MenuIcon size="small" />}>
            {userActionRender}
            <Button label={'Reset Layout'} plain={true} onClick={this.resetTileLayout}
              icon={<GridIcon size="small" />} />
            <Box margin={'small'} pad={'none'}>
              <Search placeHolder={filterPlaceholder}
                inline={true}
                fill={true}
                responsive={true}
                value={this.state.tileItemsFilterInput}
                onDOMChange={this.handleTileItemFilterInputChange} />
            </Box>
          </Menu>
        </Box>
      </Box>
    );
  }

  getTransactionChartsRender() {
    let currentCharts = [];
    const api_names = this.props.app.api_names;
    let MIN_CHARTS = 1;
    let exceptionChartId = 0;
    if (this.props.app.user_action === 'creator') {
      MIN_CHARTS = 2;
      exceptionChartId = 1;
    }

    let apiNamesTo = this.state.activePage * this.state.itemsCountPerPage;
    let apiNamesFrom = apiNamesTo - this.state.itemsCountPerPage;
    apiNamesTo -= MIN_CHARTS;
    apiNamesFrom -= MIN_CHARTS;

    if (apiNamesFrom !== -MIN_CHARTS) {
      MIN_CHARTS = 0;
    }

    if (api_names.length > 0) {
      const duplicateApis = this.props.dashboardDuplicateApis.map(x => x.api_name);
      const trimmedDuplicateApis = this.props.app.api_names.map(x => x.api_name)
        .reduce((acc, el, i, arr) => {
          if (arr.indexOf(el) !== i && acc.indexOf(el) < 0)
            acc.push(el);
          return acc;
        }, []);
      // FIXME: There is no filtering of API names from the API filter input happening here...
      if (trimmedDuplicateApis.length > 0) {
        currentCharts = [];
        duplicateApis.map((apiName, i) => {
          if (apiNamesFrom <= i && apiNamesTo > i) {
            currentCharts.push(<div id={this.props.app.appinstanceid + (apiName.originalIndex + MIN_CHARTS)}
              key={((currentCharts.length) + MIN_CHARTS)}>
              <ChartTile {...this.props.app} {...apiName} key={i + MIN_CHARTS}
                startTime={this.props.startTime}
                endTime={this.props.endTime}
                api_name={apiName}
                chartdata={this.props.opscharts}
                chartIndex={i + MIN_CHARTS}
                dashboardTileId={this.props.id}
                id={`${this.props.app.appinstanceid}-${i + MIN_CHARTS}`}
                emitter={this.props.emitter}
                chartType={'transactions'} />
            </div>);
          }
          return null;
        });
      } else {
        currentCharts = [];
        api_names.map((apiName, i) => {
          const modifiedApiName = { ...apiName };
          modifiedApiName.originalIndex = i;
          return modifiedApiName;
        })
          .filter((apiName, i) => this.state.whichShowTileItem[i])
          .map((apiName, i) => {
            if (apiNamesFrom <= i && apiNamesTo > i) {
              currentCharts.push((<div id={this.props.app.appinstanceid + (apiName.originalIndex + MIN_CHARTS)}
                key={((currentCharts.length) + MIN_CHARTS)}>
                <ChartTile {...this.props.app} {...apiName} key={i + MIN_CHARTS}
                  startTime={this.props.startTime}
                  endTime={this.props.endTime}
                  api_name={apiName.api_name}
                  chartdata={this.props.opscharts}
                  chartIndex={apiName.originalIndex + MIN_CHARTS}
                  id={`${this.props.app.appinstanceid}-${apiName.originalIndex + MIN_CHARTS}`}
                  dashboardTileId={this.props.id}
                  emitter={this.props.emitter}
                  chartType={'transactions'} />
              </div>));
            }
            return null;
          });
      }
    }

    if (apiNamesFrom === -MIN_CHARTS) {
      currentCharts.unshift(
        <div id={this.props.app.appinstanceid + exceptionChartId} key={exceptionChartId}>
          <ChartTile {...this.props.app}
            key={exceptionChartId}
            startTime={this.props.startTime}
            endTime={this.props.endTime}
            chartdata={this.props.opscharts}
            chartIndex={exceptionChartId}
            title={'App Exceptions'}
            showAlertButton={false}
            showAlertHistoryButton={false}
            dashboardTileId={this.props.id}
            id={`${this.props.app.appinstanceid}-${exceptionChartId}`}
            emitter={this.props.emitter}
            chartType={'exception'} />
        </div>
      );

      if (this.props.app.user_action === 'creator') {
        currentCharts.unshift(
          <div id={this.props.app.appinstanceid + 0} key={0}>
            <ChartTile {...this.props.app}
              key={0}
              startTime={this.props.startTime}
              endTime={this.props.endTime}
              chartdata={this.props.opscharts}
              chartIndex={0}
              title={'Operations'}
              showDrilldownLink={false}
              showAlertButton={false}
              showAlertHistoryButton={false}
              dashboardTileId={this.props.id}
              id={`${this.props.app.appinstanceid}-${0}`}
              emitter={this.props.emitter}
              chartType={'operations'} />
          </div>
        );
      }
    }

    if (currentCharts.length < this.state.itemsCountPerPage) {
      let noOfExtraCharts = (this.state.itemsCountPerPage) - (currentCharts.length);
      if (this.state.itemsCountPerPage > this.state.totalItemsCount) {
        noOfExtraCharts = 0;
      }
      for (let item = 0;item < noOfExtraCharts;item++) {
        currentCharts.push((<div style={{ display: 'none' }} key={(currentCharts.length)} />));
      }
    }

    return currentCharts;
  }

  getWorkflowChartsRender() {
    return this.props.workflowGroup.workflows
      .map((workflow, i) => {
        const modifiedWorkflow = { ...workflow };
        modifiedWorkflow.originalIndex = i;
        return modifiedWorkflow;
      })
      .filter((workflow, i) => this.state.whichShowTileItem[i])
      .map(workflow =>
        <div key={workflow.originalIndex} id={workflow.workflow_id}>
          <ChartTile
            title={workflow.workflow_name}
            startTime={this.props.startTime}
            endTime={this.props.endTime}
            showDrilldownLink={true}
            chartdata={true}
            dashboardTileId={this.props.id}
            id={workflow.workflow_id}
            emitter={this.props.emitter}
            workflow={{
              ...workflow,
              workflow_group_name: this.props.workflowGroup.workflow_group_name,
            }}
            chartType={'workflow'} />
        </div>
      );
  }

  getOpsNodesChartsRender() {
    return this.props.operationsNodes.nodes
      .map((node, i) => {
        const modifiedNode = { node };
        modifiedNode.originalIndex = i;
        return modifiedNode;
      })
      .filter((nodeObj, i) => this.state.whichShowTileItem[i])
      .map(nodeObj =>
        <div key={nodeObj.originalIndex} id={nodeObj.node}>
          <ChartTile
            title={`Node ${nodeObj.node}`}
            startTime={this.props.startTime}
            endTime={this.props.endTime}
            showDrilldownLink={true}
            chartdata={true}
            operationsNode={nodeObj.node}
            applicationInstanceId={this.props.applicationInstanceId}
            applicationName={this.props.applicationName}
            dashboardTileId={this.props.id}
            id={nodeObj.node}
            emitter={this.props.emitter}
            chartType={'operations-node'} />
        </div>
      );
  }

  getChartsRender() {
    if (this.props.tileType === 'transactions') {
      return this.getTransactionChartsRender();
    } else if (this.props.tileType === 'workflow') {
      return this.getWorkflowChartsRender();
    } else if (this.props.tileType === 'operations-nodes') {
      return this.getOpsNodesChartsRender();
    }
  }

  getPaginationRender() {
    if (this.props.tileType !== 'transactions') return;
    return (<div className="react-grid-layout" style={{ position: 'relative', height: '84px' }}>
      <div className="paginationState">
      Showing { this.state.showingItems.from } to { this.state.showingItems.to } of {this.state.totalItemsCount} charts.
      </div>
      <Pagination
        lastPageText="Last"
        firstPageText="First"
        nextPageText="Next"
        prevPageText="Prev"
        activePage={this.state.activePage}
        itemsCountPerPage={this.state.itemsCountPerPage}
        totalItemsCount={this.state.totalItemsCount}
        pageRangeDisplayed={5}
        onChange={this.handlePageChange} />
    </div>);
  }

  getTileHeading() {
    if (this.props.tileType === 'transactions') {
      const title = this.props.showInstanceOnTitle ?
        `${this.props.app.app_name} (${this.props.app.appinstanceid})` :
        this.props.app.app_name;
      return this.getTileHeadingRender(title, 'Filter APIs', this.props.app.user_action);
    } else if (this.props.tileType === 'workflow') {
      return this.getTileHeadingRender(this.props.workflowGroup.workflow_group_name, 'Filter Workflows');
    } else if (this.props.tileType === 'operations-nodes') {
      return this.getTileHeadingRender(this.props.applicationInstanceId, 'Filter Nodes');
    }
  }

  computeShowingItems(state) {
    state.showingItems.from = ((state.activePage - 1) * state.itemsCountPerPage) + 1;
    state.showingItems.to = (state.showingItems.from + state.itemsCountPerPage) - 1;
    if (state.showingItems.to > state.totalItemsCount) {
      state.showingItems.to = state.totalItemsCount;
    }
  }

  handlePageChange(pageNumber) {
    this.setState({ activePage: pageNumber });
  }

  render() {
    this.computeShowingItems(this.state);
    return (
      <div className="eachappnamediv apptile">
        <div className="eachappheading apptile-header">
          {this.getTileHeading()}
        </div>
        <ResponsiveReactGridLayout layouts={this.state.layout}
          isResizable={true} autoSize={true} margin={[5, 10]}
          onResizeStop={this.onResizeStop} onLayoutChange={this.onLayoutChange}
          breakpoints={{ xxlg: 1920, xlg: 1500, lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
          cols={{ xxlg: NUMBER_OF_COLUMNS_FOR_XXLG, xlg: NUMBER_OF_COLUMNS_FOR_XXLG,
            lg: NUMBER_OF_COLUMNS_FOR_LG, md: NUMBER_OF_COLUMNS_FOR_MD,
            sm: NUMBER_OF_COLUMNS_FOR_MD, xs: NUMBER_OF_COLUMNS_FOR_XS,
            xxs: NUMBER_OF_COLUMNS_FOR_XS }}>
          {this.getChartsRender()}
        </ResponsiveReactGridLayout>
        {this.getPaginationRender()}
      </div>
    );
  }
}

DashboardTile.propTypes = {
  applicationName: React.PropTypes.string,
  applicationInstanceId: React.PropTypes.string,
  id: React.PropTypes.string.isRequired,
  userProfile: React.PropTypes.object.isRequired,
  emitter: React.PropTypes.object.isRequired,
  endTime: React.PropTypes.string.isRequired,
  startTime: React.PropTypes.string.isRequired,
  tileType: React.PropTypes.string.isRequired,
  workflowGroup: React.PropTypes.object,
  operationsNodes: React.PropTypes.array,
  app: React.PropTypes.object,
  opscharts: React.PropTypes.array,
  showInstanceOnTitle: React.PropTypes.bool,
  dashboardDuplicateApis: React.PropTypes.array,
};

const mapStateToProps = state => ({
  userProfile: state.userProfile,
  dashboardDuplicateApis: state.dashboardDuplicateApis,
});

const mapDispatchToProps = () => ({
});

export default connect(mapStateToProps, mapDispatchToProps)(DashboardTile);
