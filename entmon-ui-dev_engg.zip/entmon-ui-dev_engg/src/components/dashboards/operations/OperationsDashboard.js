import React from 'react';
import Dashboard from '../Dashboard';

export default class OperationsDashboard extends React.Component {
  render() {
    return (
      <Dashboard dashboardType={'operations'} />
    );
  }
}
