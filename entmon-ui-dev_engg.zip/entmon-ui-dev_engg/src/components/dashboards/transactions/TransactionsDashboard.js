import React from 'react';
import Dashboard from '../Dashboard';

export default class TransactionsDashboard extends React.Component {
  render() {
    return (
      <Dashboard dashboardType={'transactions'} />
    );
  }
}
