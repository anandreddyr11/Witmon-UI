import React from 'react';
import Dashboard from '../Dashboard';

export default class WorkflowsDashboard extends React.Component {
  render() {
    return (
      <Dashboard dashboardType={'workflows'} />
    );
  }
}
