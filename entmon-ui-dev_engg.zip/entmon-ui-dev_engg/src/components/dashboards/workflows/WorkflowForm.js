import React from 'react';
import { connect } from 'react-redux';
import { buildQuery, processStatus } from 'grommet/utils/Rest';
import Heading from 'grommet/components/Heading';
import Header from 'grommet/components/Header';
import FormField from 'grommet/components/FormField';
import Button from 'grommet/components/Button';
import Select from 'grommet/components/Select';
import TextInput from 'grommet/components/TextInput';

const config = require(`../../../../config.${process.env.NODE_ENV}.json`);
const workflowGroupCustomInputText = 'Add a new Workflow group';

class WorkflowForm extends React.Component {
  constructor(props) {
    super(props);

    let workflowGroups;
    if (this.props.workflowGroups !== undefined) {
      workflowGroups = this.props.workflowGroups
        .map(workflowGroup => workflowGroup.workflow_group_name);
    } else {
      workflowGroups = [];
    }
    workflowGroups.unshift(workflowGroupCustomInputText);

    const appApis = {};
    const appApisInput = {};
    const appApisOptions = {};
    props.apps.forEach(app => {
      let apisInput = [];
      if (this.props.isWorkflowFormUpdate) {
        const formDataApp = props.workflowFormData.apps.find(workflowApp =>
          workflowApp.application_instance_id === app.appinstanceid);
        if (formDataApp !== undefined) apisInput = formDataApp.api_names;
      }
      const apiNames = app.api_names.map(api => api.api_name);
      appApis[`${app.appinstanceid}`] = apiNames;
      appApisInput[`${app.appinstanceid}-input`] = apisInput;
      appApisOptions[`${app.appinstanceid}-options`] = apiNames;
    });

    this.state = {
      ...appApis,
      ...appApisInput,
      ...appApisOptions,
      owner: this.props.workflowFormData.owner || this.props.userProfile.email,
      workflowGroups,
      workflowNameInput: this.props.workflowFormData.workflow_name || '',
      workflowGroupInput: this.props.workflowFormData.workflow_group_name || '',
      workflowGroupOptions: workflowGroups,
      workflowGroupCustomInput: '',
      workflowAdmins: [],
      workflowAdminsInput: [],
      workflowAdminsOptions: [],
      workflowUsers: [],
      workflowUsersInput: [],
      workflowUsersOptions: [],
      subscribersOfApps: undefined,
      showWorkflowGroupCustomInput: false,
      validationErrors: [],
    };

    this.handleFormSubmit = this.handleFormSubmit.bind(this);
  }

  componentDidMount() {
    this.fetchValidUsersForWorkflow();
    if (this.props.isWorkflowFormUpdate) {
      this.fetchWorkflowUserMappings();
    }
  }

  isEmptyString(str) {
    return str === '' || str === undefined;
  }

  formIsInvalid() {
    const isWorkflowNameInputInvalid = this.isEmptyString(this.state.workflowNameInput);
    const isWorkflowGroupInputInvalid = this.isEmptyString(this.state.workflowGroupInput) ||
      (
        this.state.showWorkflowGroupCustomInput &&
        this.isEmptyString(this.state.workflowGroupCustomInput)
      );
    const isApiInputInvalid = this.getRowsDataArray().length === 0;

    const isFormInvalid = (
      isWorkflowNameInputInvalid ||
      isWorkflowGroupInputInvalid ||
      isApiInputInvalid
    );

    const validationErrors = [];
    if (isWorkflowNameInputInvalid) validationErrors.push('Workflow name can not be empty');
    if (isWorkflowGroupInputInvalid) validationErrors.push('Workflow group can not be empty');
    if (isApiInputInvalid) validationErrors.push('Select at least one application API');
    this.setState({ validationErrors });

    return isFormInvalid;
  }

  fetchValidUsersForWorkflow() {
    const apps = this.props.apps.map(app => app.app_name);
    const method = 'GET';
    const endpoint = '/subscribers-of-apps';
    const uri = `${config.serverUrl}${endpoint}${buildQuery({ apps })}`;
    fetch(encodeURI(uri), { method })
      .then(processStatus)
      .then(response => response.json())
      .then(subscribersOfApps => {
        const users = subscribersOfApps
          .filter(subscriber => subscriber !== this.props.userProfile.email);
        this.setState({
          subscribersOfApps,
          workflowAdmins: subscribersOfApps,
          workflowAdminsOptions: subscribersOfApps,
          workflowUsers: users,
          workflowUsersOptions: users,
        });
      })
      .catch(err => {
        console.error(err);
        this.setState({ err });
      });
  }

  fetchWorkflowUserMappings() {
    const workflowId = this.props.workflowFormData.workflow_id;
    const method = 'GET';
    const endpoint = '/workflow-user-mapping';
    const uri = `${config.serverUrl}${endpoint}${buildQuery({ workflow_id: workflowId })}`;
    fetch(encodeURI(uri), { method })
      .then(processStatus)
      .then(response => response.json())
      .then(workflowUserMappings => {
        const users = workflowUserMappings.rows.filter(userMapping => userMapping.user_role === 'user')
          .map(userMapping => userMapping.user_email);
        const admins = workflowUserMappings.rows.filter(userMapping => userMapping.user_role === 'admin')
          .map(userMapping => userMapping.user_email);
        this.setState({
          workflowUsersInput: users,
          workflowAdminsInput: admins,
        });
      });
  }

  getWorkflowGroupNameInput() {
    return this.state.showWorkflowGroupCustomInput ?
      this.state.workflowGroupCustomInput :
      this.state.workflowGroupInput;
  }

  getRowsDataArray() {
    const rows = [];
    this.props.apps.forEach(app => {
      this.state[`${app.appinstanceid}-input`].forEach(apiSelected => {
        rows.push({
          workflow_name: this.state.workflowNameInput,
          application_instance_id: app.appinstanceid,
          app_name: app.app_name,
          api_name: apiSelected,
        });
      });
    });
    return rows;
  }

  getUserMappingRowsDataArray() {
    const workflowGroupName = this.getWorkflowGroupNameInput();
    const workflowUserRows = this.state.workflowUsersInput.map(userEmail => ({
      workflow_name: this.state.workflowNameInput,
      workflow_group_name: workflowGroupName,
      user_email: userEmail,
      user_role: 'user',
    }));
    const workflowAdmins = [...this.state.workflowAdminsInput];
    // Add self to workflowAdmins upon creation of Workflow and hasn't added self to admins
    // from the worklfow admins input.
    if (!this.props.isWorkflowFormUpdate &&
      !workflowAdmins.includes(this.props.userProfile.email)) {
      workflowAdmins.push(this.props.userProfile.email);
    }
    const workflowAdminRows = workflowAdmins.map(userEmail => ({
      workflow_name: this.state.workflowNameInput,
      workflow_group_name: workflowGroupName,
      user_email: userEmail,
      user_role: 'admin',
    }));
    const userMappingRows = workflowUserRows.concat(workflowAdminRows);
    return userMappingRows;
  }

  handleWorkflowGroupInputChange(value) {
    if (value === workflowGroupCustomInputText) {
      this.setState({
        workflowGroupInput: value,
        showWorkflowGroupCustomInput: true,
      });
    } else {
      this.setState({
        workflowGroupInput: value,
        workflowGroupCustomInput: '',
        showWorkflowGroupCustomInput: false,
      });
    }
  }

  handleInputSearch(filter, dataStateName, optionsStateName) {
    const regexp = new RegExp(filter);
    const result = this.state[dataStateName].filter(value => regexp.test(value));
    this.setState({ [optionsStateName]: result });
  }

  handleAdminFormSubmit() {
    const rows = this.getRowsDataArray();
    const userMappingRows = this.getUserMappingRowsDataArray();
    const body = new FormData();
    body.set('rows', JSON.stringify(rows));
    body.set('user_mapping_rows', JSON.stringify(userMappingRows));

    let method;
    if (this.props.isWorkflowFormUpdate) {
      method = 'PUT';
      body.set('workflow_id', this.props.workflowFormData.workflow_id);
    } else {
      method = 'POST';
    }

    const endpoint = '/workflow';
    const uri = `${config.serverUrl}${endpoint}`;
    fetch(encodeURI(uri), { method, body })
      .then(processStatus)
      .then(() => window.location.reload(true))
      .catch(err => {
        console.error(err);
        this.setState({ err });
      });
  }

  handleUserFormSubmit() {
    const workflowGroupName = this.getWorkflowGroupNameInput();
    const userMappingRow = {
      workflow_id: this.props.workflowFormData.workflow_id,
      workflow_name: this.props.workflowFormData.workflow_name,
      workflow_group_name: workflowGroupName,
      user_email: this.props.userProfile.email,
      user_role: 'user',
    };

    const body = new FormData();
    body.set('user_mapping_row', JSON.stringify(userMappingRow));

    const method = 'PUT';
    const endpoint = '/workflow-user-mapping';
    const uri = `${config.serverUrl}${endpoint}`;
    fetch(encodeURI(uri), { method, body })
      .then(processStatus)
      .then(() => window.location.reload(true))
      .catch(err => {
        console.error(err);
        this.setState({ err });
      });
  }

  handleFormSubmit(e) {
    e.preventDefault();
    if (this.formIsInvalid()) {
      return;
    }
    if (this.props.workflowFormData.user_role === 'user') {
      this.handleUserFormSubmit();
    } else {
      this.handleAdminFormSubmit();
    }
  }

  handleUserInputChange(input, inputStateName, restrictStateName, restrictStateNameOptions) {
    const validUsers = this.state.subscribersOfApps.filter(email => !input.includes(email));
    const restrictState = validUsers;
    const restrictStateOptions = validUsers;
    this.setState({
      [inputStateName]: input,
      [restrictStateName]: restrictState,
      [restrictStateNameOptions]: restrictStateOptions,
    });
  }

  getValidationErrorsRender() {
    return this.state.validationErrors.map((error, i) =>
      <span key={i} className="c-red">{error}<br /></span>
    );
  }

  getWorkflowGroupCustomInputRender() {
    if (this.state.showWorkflowGroupCustomInput === true) {
      return (
        <FormField label="New Workflow Group">
          <TextInput
            name={'workflow_group'}
            placeHolder={'Enter new Workflow group'}
            onDOMChange={e => this.setState({ workflowGroupCustomInput: e.target.value })} />
        </FormField>
      );
    }
  }

  getAppsFieldsSectionRender() {
    if (this.props.isWorkflowFormUpdate && this.props.workflowFormData.user_role === 'user') {
      return;
    }
    const appsFields = this.props.apps.map((app, i) =>
      <FormField key={i} label={`${app.app_name} <${app.appinstanceid}> [${app.user_action}]`}>
        <Select
          multiple={true}
          options={this.state[`${app.appinstanceid}-options`]}
          value={this.state[`${app.appinstanceid}-input`]}
          onChange={e => this.setState({ [`${app.appinstanceid}-input`]: e.value })}
          onSearch={e => this.handleInputSearch(e.target.value, `${app.appinstanceid}`, `${app.appinstanceid}-options`)} />
      </FormField>
    );
    return (
      <div>
        <Heading className="form-header" align="start" tag="h4">
          <strong>{'Workflow Application APIs'}</strong>
        </Heading>
        {appsFields}
      </div>
    );
  }

  getWorkflowUsersInputRender() {
    if (this.props.isWorkflowFormUpdate && this.props.workflowFormData.user_role === 'user') {
      return;
    }
    return (
      <FormField label={'Workflow Users'}>
        <Select
          multiple={true}
          options={this.state.workflowUsersOptions}
          value={this.state.workflowUsersInput}
          onChange={e => this.handleUserInputChange(e.value, 'workflowUsersInput', 'workflowAdmins', 'workflowAdminsOptions')}
          onSearch={e => this.handleInputSearch(e.target.value, 'workflowUsers', 'workflowUsersOptions')} />
      </FormField>
    );
  }

  getWorkflowAdminsInputRender() {
    if (this.props.isWorkflowFormUpdate && this.props.workflowFormData.user_role === 'user') {
      return;
    }
    return (
      <FormField label={'Workflow Admins'}>
        <Select
          multiple={true}
          options={this.state.workflowAdminsOptions}
          value={this.state.workflowAdminsInput}
          onChange={e => {
            // Refuse to let admin remove himself from mapping. Prefer delete button.
            if (this.props.isWorkflowFormUpdate &&
              !e.value.includes(this.props.userProfile.email)) {
              return;
            }
            this.handleUserInputChange(e.value, 'workflowAdminsInput', 'workflowUsers', 'workflowUsersOptions')
          }}
          onSearch={e => this.handleInputSearch(e.target.value, 'workflowAdmins', 'workflowAdminsOptions')} />
      </FormField>
    );
  }

  getWorkflowNameFieldRender() {
    if (this.props.isWorkflowFormUpdate && this.props.workflowFormData.user_role === 'user') {
      return;
    }
    return (
      <FormField label="Workflow Name">
        <TextInput
          name={'workflow_name'}
          placeHolder={'Enter Workflow name'}
          value={this.state.workflowNameInput}
          onDOMChange={e => this.setState({ workflowNameInput: e.target.value })} />
      </FormField>
    );
  }

  render() {
    const title = this.props.isWorkflowFormUpdate ?
      'Update an existing Workflow' :
      'Add a new Workflow';
    const submitLabel = this.props.isWorkflowFormUpdate ?
      'Update Workflow' :
      'Add Workflow';
    return (
      <div id="page-wrap">
        <form name="add_new_workflow_form" className="form-style">
          <Header>
            <Heading className="form-header" tag="h3">
              <strong>{title}</strong>
            </Heading>
          </Header>
          <hr />
          <Heading className="form-header" align="start" tag="h4">
            <strong>Workflow Details</strong>
          </Heading>
          {this.getWorkflowNameFieldRender()}
          <FormField label="Workflow Group">
            <Select
              className="form-field-inner-tag"
              name="workflow_group"
              placeHolder={'Select a Workflow group'}
              value={this.state.workflowGroupInput}
              options={this.state.workflowGroupOptions}
              onChange={e => this.handleWorkflowGroupInputChange(e.option)}
              onSearch={e => this.handleInputSearch(e.target.value, 'workflowGroups', 'workflowGroupOptions')} />
          </FormField>
          {this.getWorkflowGroupCustomInputRender()}
          {this.getWorkflowUsersInputRender()}
          {this.getWorkflowAdminsInputRender()}
          <br />
          {this.getAppsFieldsSectionRender()}
          <br />
          {this.getValidationErrorsRender()}
          <br />
          <Button type="submit" label={submitLabel} onClick={this.handleFormSubmit} />
        </form>
      </div>
    );
  }
}

WorkflowForm.propTypes = {
  apps: React.PropTypes.array.isRequired,
  userProfile: React.PropTypes.object.isRequired,
  workflowGroups: React.PropTypes.array.isRequired,
  isWorkflowFormUpdate: React.PropTypes.bool.isRequired,
  workflowFormData: React.PropTypes.object.isRequired,
};

const mapStateToProps = state => ({
  userProfile: state.userProfile,
  isWorkflowFormUpdate: state.isWorkflowFormUpdate,
  workflowFormData: state.workflowFormData,
});

const mapDispatchToProps = () => ({
});

export default connect(mapStateToProps, mapDispatchToProps)(WorkflowForm);
