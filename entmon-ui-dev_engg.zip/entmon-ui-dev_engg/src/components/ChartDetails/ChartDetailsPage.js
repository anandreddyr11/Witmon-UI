import React, { PropTypes } from 'react';
import moment from 'moment';
import { connect } from 'react-redux';
import { EventEmitter } from 'fbemitter';
import { processStatus, buildQuery } from 'grommet/utils/Rest';
import { menuAutoRefreshSet, menuShowAppnamesSet } from '../../actions/menu';
import ChartDetailsTable from './ChartDetailsTable';
import ChartTile from '../chart/ChartTile';
import DashboardTile from '../dashboards/DashboardTile';
import HorizontalStackedBar from '../chart/HorizontalStackedBar';
import PinchBar from '../chart/pinchbar';
import Label from 'grommet/components/Label';
import Heading from 'grommet/components/Heading';

const config = require(`../../../config.${process.env.NODE_ENV}`);

const dateFormat = 'YYYY-MM-DD HH:mm:ss';

class ChartDetailsPage extends React.Component {
  constructor(props) {
    super(props);

    const chartData = JSON.parse(sessionStorage.getItem('currentDetail'));
    if (chartData === null) {
      // Will occur if user clears cache and navigates directly to this page.
      window.location = '/#/Dashboard';
    }

    let startTime;
    let endTime;
    if (this.props.menuOptions.menuCustomStartTime) { // For custom time range
      startTime = moment(this.props.menuOptions.menuCustomStartTime).format(dateFormat);
      endTime = moment(this.props.menuOptions.menuCustomStartTime).add(this.props.menuOptions.menuTimeRange, 'Hours')
        .format(dateFormat);
    } else {
      endTime = moment.utc().format(dateFormat);
      startTime = moment.utc().subtract(this.props.menuOptions.menuTimeRange, 'Hours')
        .format(dateFormat);
    }

    let chartTableDataQueryParams;
    if (chartData.chartType === 'transactions') {
      const consumerId = chartData.user_action === 'creator' ? '' : chartData.appconsumerid;
      chartTableDataQueryParams = {
        app_name: chartData.app_name,
        api_name: chartData.api_name,
        start_time: startTime,
        end_time: endTime,
        user_action: chartData.user_action,
        application_instance_id: chartData.appinstanceid,
        application_consumer_id: consumerId,
      };
    } else if (chartData.chartType === 'exception') {
      const consumerId = chartData.user_action === 'creator' ? '' : chartData.appconsumerid;
      chartTableDataQueryParams = {
        app_name: chartData.app_name,
        api_name: chartData.api_name,
        start_time: startTime,
        end_time: endTime,
        user_action: chartData.user_action,
        application_instance_id: chartData.appinstanceid,
        application_consumer_id: consumerId,
      };
    } else if (chartData.chartType === 'alertHistory') {
      chartTableDataQueryParams = {
        app_name: chartData.app_name,
        api_name: chartData.api_name,
        start_time: startTime,
        end_time: endTime,
        user_action: chartData.user_action,
        application_instance_id: chartData.appinstanceid,
        user_email_id: chartData.userProfile.email,
      };
    } else if (chartData.chartType === 'workflow') {
      chartTableDataQueryParams = {
        start_time: startTime,
        end_time: endTime,
        user_email: chartData.userProfile.email,
        workflow_id: chartData.id,
      };
    }

    this.state = {
      startTime,
      endTime,
      chartData,
      chartTableDataQueryParams,
      timeRange: this.props.menuOptions.menuTimeRange,
      emitter: new EventEmitter(),
    };

    this.originalAutoRefreshState = this.props.menuAutoRefresh;
    this.previousAutoRefreshState = this.props.menuAutoRefresh;
    this.handlePinchbarChanged = this.handlePinchbarChanged.bind(this);
    this.onTableRowDoubleClick = this.onTableRowDoubleClick.bind(this);
  }

  componentDidMount() {
    this.props.menuAutoRefreshSet(false); // Turn off Auto Refresh
    this.props.menuShowAppnamesSet(false);
    window.scrollTo(0, 0); // Scroll page to Top

    if (this.state.chartData.chartType === 'operations') {
      this.fetchOperationsNodesData();
    }
  }

  componentWillReceiveProps(nextProps) {
    this.previousAutoRefreshState = this.props.menuAutoRefresh;
    if (nextProps.menuOptions && this.props.menuAutoRefresh === nextProps.menuAutoRefresh) {
      if (nextProps.menuOptions.menuCustomStartTime && nextProps.menuOptions.menuTimeRange) {
        this.setTimesForCustomMenu(nextProps.menuOptions.menuCustomStartTime,
          nextProps.menuOptions.menuTimeRange);
      } else if (nextProps.menuOptions.menuTimeRange) {
        this.setTimes(nextProps.menuOptions.menuTimeRange);
      }
    }
  }

  shouldComponentUpdate(nextProps) {
    return (this.props.menuAutoRefresh === nextProps.menuAutoRefresh);
  }

  componentWillUnmount() {
    this.props.menuAutoRefreshSet(this.originalAutoRefreshState);
  }

  fetchTransactionIdFlowChartData(transactionId) {
    const host = config.serverUrl;
    const endpoint = '/get-transaction-id-durations';
    const query = buildQuery({ transaction_id: transactionId });
    const uri = `${host}${endpoint}${query}`;
    this.fetchData(uri, 'transactionIdFlowChartData');
  }

  fetchOperationsNodesData() {
    const host = config.serverUrl;
    const endpoint = '/get-ops-data-nodes-for-app';
    const query = buildQuery({
      app_name: this.state.chartData.app_name,
      application_instance_id: this.state.chartData.appinstanceid,
    });
    const uri = `${host}${endpoint}${query}`;
    this.fetchData(uri, 'operationsNodes');
  }

  fetchData(uri, dataStateName) {
    fetch(encodeURI(uri))
      .then(processStatus)
      .then(response => response.json())
      .then(data => this.setState({ [dataStateName]: data }))
      .catch(error => this.setState({ error }));
  }

  setTimesForCustomMenu(menuCustomStartTime, timeRange) {
    const startTime = moment(menuCustomStartTime).format(dateFormat);
    const endTime = moment(menuCustomStartTime).add(timeRange, 'Hours')
      .format(dateFormat);
    const chartTableDataQueryParams = this.state.chartTableDataQueryParams;
    chartTableDataQueryParams.start_time = startTime;
    chartTableDataQueryParams.end_time = endTime;
    this.setState({ startTime, endTime, chartTableDataQueryParams, timeRange, 
      pinchbarSelected: false });
  }

  setTimes(timeRange) {
    const endTime = moment.utc().format(dateFormat);
    const startTime = moment.utc().subtract(timeRange, 'Hours')
      .format(dateFormat);
    const chartTableDataQueryParams = this.state.chartTableDataQueryParams;
    chartTableDataQueryParams.start_time = startTime;
    chartTableDataQueryParams.end_time = endTime;
    this.setState({ startTime, endTime, chartTableDataQueryParams, timeRange, 
      pinchbarSelected: false });
  }

  handlePinchbarChanged(pinchStart, pinchEnd, pinchbarSelected) {
    if (pinchStart && pinchEnd) {
      this.previousAutoRefreshState = this.props.menuAutoRefresh;
      this.props.menuAutoRefreshSet(false); // Turn off Auto Refresh
    } else {
      const timeRange = this.props.menuOptions.menuTimeRange;
      if (this.props.menuOptions.menuCustomStartTime) { // For custom time range
        pinchStart = moment(this.props.menuOptions.menuCustomStartTime).format(dateFormat);
        pinchEnd = moment(this.props.menuOptions.menuCustomStartTime).add(timeRange, 'Hours')
          .format(dateFormat);
      } else {
        pinchEnd = moment.utc().format(dateFormat);
        pinchStart = moment.utc().subtract(timeRange, 'Hours')
          .format(dateFormat);
      }
      this.props.menuAutoRefreshSet(this.previousAutoRefreshState);
    }
    this.setState({
      startTime: pinchStart,
      endTime: pinchEnd,
      pinchbarSelected,
    });
  }

  onTableRowDoubleClick(row) {  
    this.fetchTransactionIdFlowChartData(row.transaction_id);
    this.setState({
      transactionIdDataQueryParams: {
        transaction_id: row.transaction_id,
        user_email: this.props.userProfile.email,
      },
    });
  }

  getTransactionIdFlowChartRender() {
    if (this.state.transactionIdFlowChartData === undefined) return;
    let apidata = this.state.transactionIdFlowChartData.apiData;
    let apiData = {};
    let apiNames = this.state.transactionIdFlowChartData.apiNames;

    apiNames.forEach(function(name,i) {
      apiNames[i] = apiNames[i] + i;
      apiData[apiNames[i]] = Math.abs(apidata[i][name]);
    });

    return (
        <HorizontalStackedBar data={[apiData]}
        stackKeys={apiNames} chartWidth={1000}
        chartHeight={100} disableYAxisTickLabels={true} />
    );
  }

  getChildChartsRender() {
    if (this.state.chartData.chartType !== 'operations') return;
    if (this.state.operationsNodes === undefined) return;
    return (
      <DashboardTile tileType={'operations-nodes'} startTime={this.state.startTime}
        endTime={this.state.endTime} operationsNodes={this.state.operationsNodes}
        emitter={this.state.emitter} applicationInstanceId={this.state.chartData.appinstanceid}
        applicationName={this.state.chartData.app_name} />
    );
  }

  getChartDetailsTableRender() {
    if (this.state.chartData.chartType === 'operations') return;
    const onDblClick = this.state.chartData.chartType === 'alertHistory' ? (() => {}) : this.onTableRowDoubleClick;
    return (
      <ChartDetailsTable params={this.state.chartTableDataQueryParams}
        startTime={this.state.startTime} enablePagination={true}
        endTime={this.state.endTime} enableExportToCsv={true}
        enableMultiColumnSearch={true} showRowDetailsOnDoubleClick={true}
        expandRowOnDoubleClick={true} tableType={this.state.chartData.chartType}
        onRowDoubleClick={onDblClick} />
    );
  }

  getTransactionFlowRender() {
    if (this.state.transactionIdDataQueryParams === undefined) return;

    return (
      <div className="tile">
        <div className="tile-header">
          <Heading tag="h3">
            <strong>Transaction ID:</strong>&nbsp;
            {this.state.transactionIdDataQueryParams.transaction_id}
          </Heading>
        </div>
        <div className="tile-body">
          <div className="vp-15">
            {this.getTransactionIdFlowChartRender()}
          </div>
          <ChartDetailsTable params={this.state.transactionIdDataQueryParams}
            startTime={this.state.startTime} endTime={this.state.endTime}
            enablePagination={true} enableMultiColumnSearch={true} 
            expandRowOnDoubleClick={true} showRowDetailsOnDoubleClick={true}
            tableType={'transactionId'} />
        </div>
      </div>
    );
  }

  render() {
    return (
      <div>
        <div className="pinchbar-container" id="pinchbar-container">
          <Label className="time-range-label">
            <b>Time Range:</b> {this.state.startTime} ~ {this.state.endTime} (Etc/UTC GMT +0)
          </Label>
          <PinchBar {...this.state} timeRange={this.props.menuOptions.menuTimeRange}
            handlePinchbarChanged={this.handlePinchbarChanged} />
        </div>
        <div className="txn-chartcontainer">
          <ChartTile {...this.state.chartData}
            startTime={this.state.startTime}
            endTime={this.state.endTime}
            showDrilldownLink={false}
            refreshInterval={this.state.interval}
            emitter={this.state.emitter}
            chartType={this.state.chartData.chartType} />
        </div>
        {this.getChildChartsRender()}
        {this.getChartDetailsTableRender()}
        <br />
        <br />
        <br />
        {this.getTransactionFlowRender()}
        <br />
      </div>
    );
  }
}

ChartDetailsPage.propTypes = {
  userProfile: PropTypes.object.isRequired,
  menuOptions: PropTypes.object.isRequired,
  menuRefreshNow: PropTypes.object.isRequired,
  menuAutoRefresh: PropTypes.bool.isRequired,
  menuAutoRefreshSet: PropTypes.func.isRequired,
  menuShowAppnamesSet: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  userProfile: state.userProfile,
  menuOptions: state.menuOptions,
  menuAutoRefresh: state.menuAutoRefresh,
  menuRefreshNow: state.menuRefreshNow,
});

const mapDispatchToProps = dispatch => ({
  menuAutoRefreshSet: bool => dispatch(menuAutoRefreshSet(bool)),
  menuShowAppnamesSet: bool => dispatch(menuShowAppnamesSet(bool)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ChartDetailsPage);
