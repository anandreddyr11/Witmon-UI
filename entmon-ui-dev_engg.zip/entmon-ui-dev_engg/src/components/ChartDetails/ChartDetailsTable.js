import React from 'react';
import _ from 'lodash';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import { processStatus, buildQuery } from 'grommet/utils/Rest';
import Spinning from 'grommet/components/icons/Spinning';
import Box from 'grommet/components/Box';
import ReactTooltip from 'react-tooltip';

import 'react-bootstrap-table/dist/react-bootstrap-table.min';
import 'bootstrap/dist/js/bootstrap.min';

const common = require('../home/common.js');
const config = require(`../../../config.${process.env.NODE_ENV}`);

export default class ChartDetailsTable extends React.Component {
  static columnClassNameFormat(row) {
    if (row !== undefined && row.rowBehavior === 'expand') {
      return 'ClickableExpandableColumn';
    } else {
      return 'tableRowsColumns';
    }
  }

  static shouldRefreshData(current, next) {
    return (
      current.startTime !== next.startTime ||
      current.endTime !== next.endTime ||
      !_.isEqual(current.params, next.params)
    );
  }

  static tableCellTooltip(cell, row, formatExtraData, rowIdx) {
    const id = `${cell}${rowIdx}`;
    return (
      <div>
        <div className={ChartDetailsTable.columnClassNameFormat(row)} data-tip={true}
          data-for={id}>
          {cell}
        </div>
        <ReactTooltip id={id} className="tableTooltip" delayShow={500} effect="float">
          <span>{cell}</span>
        </ReactTooltip>
      </div>
    );
  }

  constructor(props) {
    super(props);

    this.state = {
      data: [],
      rowData: [],
      showRowDetail: false,
      currentPage: 1,
      handleWithRemote: (this.props.tableType === 'transactions' || this.props.tableType === 'alertHistory' || this.props.tableType === 'exception' || this.props.tableType === 'workflow'),
      sizePerPage: 10,
      searchSize: 0,
      totalSize: 0,
      updateTotalSize: true,
      optionalParamValues: {},
      sortName: (this.props.tableType === 'alertHistory' ? 'notification_sent_time' : 'start_time'),
      sortOrder: 'desc',
    };

    this.onRowDoubleClick = this.onRowDoubleClick.bind(this);
    this.renderShowsTotal = this.renderShowsTotal.bind(this);
    this.onHandlePageChange = this.onHandlePageChange.bind(this);
    this.onHandleSizePerPageChange = this.onHandleSizePerPageChange.bind(this);
    this.onSearchChange = this.onSearchChange.bind(this);
    this.onFilterChange = this.onFilterChange.bind(this);
    this.onSortChange = this.onSortChange.bind(this);
  }

  componentWillMount() {
    const optionalParamValues = {};
    optionalParamValues.fetchSize = this.state.sizePerPage;
    optionalParamValues.sortName = this.state.sortName;
    optionalParamValues.sortOrder = this.state.sortOrder;
    optionalParamValues.getCount = false;
    Object.assign(optionalParamValues, this.props.params);
    this.setState({ optionalParamValues });
    this.fetchTableData(optionalParamValues);
    optionalParamValues.getCount = true;
    this.fetchTableData(optionalParamValues);
  }

  componentWillReceiveProps(nextProps) {
    if (ChartDetailsTable.shouldRefreshData(this.props, nextProps)) {
      const optionalParamValues = {};
      optionalParamValues.fetchSize = this.state.sizePerPage;
      optionalParamValues.sortName = this.state.sortName;
      optionalParamValues.sortOrder = this.state.sortOrder;
      optionalParamValues.getCount = false;
      Object.assign(optionalParamValues, nextProps.params);
      this.setState({ optionalParamValues });
      this.fetchTableData(optionalParamValues);
      optionalParamValues.getCount = true;
      this.fetchTableData(optionalParamValues);
    }
  }

  fetchTableData(params) {
    this.setState({ gettingData: true });

    const host = config.serverUrl;
    let uri;
    let options;
    let endpoint;
    if (this.props.tableType === 'exception') {
      endpoint = '/post-exception-trans-details';
      uri = `${host}${endpoint}`;
      params.responsestatus = 'Fail';
      options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(params),
      };
    } else if (this.props.tableType === 'alertHistory') {
      endpoint = '/post-notification-history-details';
      uri = `${host}${endpoint}`;
      params.responsestatus = 'Fail';
      options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(params),
      };
    } else if (this.props.tableType === 'transactions') {
      endpoint = '/post-trans-details';
      uri = `${host}${endpoint}`;
      params.responsestatus = 'Pass';
      options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(params),
      };
    } else if (this.props.tableType === 'workflow') {
      endpoint = '/post-trans-workflow-details';
      uri = `${host}${endpoint}`;
      options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(params),
      };
    } else {
      endpoint = '/get-transaction-id-chart-data-detail';
      const query = buildQuery(params);
      uri = `${host}${endpoint}${query}`;
      options = { method: 'GET' };
    }

    if (params.getCount) {
      fetch(uri, options)
        .then(processStatus)
        .then(response => response.json())
        .then(data => {
          this.setState({
            gettingData: false,
            searchSize: (data.length === 0) ? 0 : parseInt(data[0].count),
          });
          if (this.state.updateTotalSize) {
            this.setState({
              gettingData: false,
              totalSize: (data.length === 0) ? 0 : parseInt(data[0].count),
            });
          }
        })
        .catch(error => this.setState({ error, gettingData: false }));
    } else {
      fetch(uri, options)
        .then(processStatus)
        .then(response => response.json())
        .then(data => {
          data.forEach((row, i) => {
            row.id = i;
            row.rowBehavior = 'collapse';
          });
          this.setState({
            data,
            gettingData: false,
          });
        })
        .catch(error => this.setState({ error, gettingData: false }));
    }
  }

  renderShowsTotal(start, to, total) {
    let message = `Showing ${start} to ${to}`;
    if (!this.state.handleWithRemote) {
      message = message.concat(` of ${this.state.searchSize} (filtered from ${total} entries) `);
      if (total < this.state.data.length) {
        message = message.concat(`  (filtered from ${this.state.data.length} total entries)`);
      }
    } else {
      message = message.concat(` of ${this.state.searchSize} (filtered from ${this.state.totalSize} entries)`);
    }
    return (
      <p>
        <strong>{message}</strong>
      </p>
    );
  }

  onRowDoubleClick(row) {
    const state = {};

    if (this.props.expandRowOnDoubleClick) {
      const data = _.cloneDeep(this.state.data);
      if (row.rowBehavior === 'collapse') data[row.id].rowBehavior = 'expand';
      else data[row.id].rowBehavior = 'collapse';
      state.data = data;
    }

    if (this.props.showRowDetailsOnDoubleClick) {
      state.rowData = [{
        transaction_id: row.transaction_id,
        request_body: row.request_body,
        response_body: row.response_body,
      }];
      state.showRowDetail = true;
    }

    this.props.onRowDoubleClick(row);

    this.setState(state);
  }

  onHandlePageChange(page, sizePerPage) {
    const optionalParamValues = this.state.optionalParamValues;
    optionalParamValues.fetchSize = sizePerPage;
    optionalParamValues.getCount = false;
    optionalParamValues.start = (page - 1) * sizePerPage;
    this.setState({ currentPage: page, optionalParamValues, sizePerPage });
    this.fetchTableData(optionalParamValues);
  }

  onHandleSizePerPageChange(sizePerPage) {
    this.setState({ sizePerPage });
    const optionalParamValues = this.state.optionalParamValues;
    optionalParamValues.fetchSize = sizePerPage;
    optionalParamValues.getCount = false;
    optionalParamValues.start = 0;
    this.fetchTableData(optionalParamValues);
  }

  escapString(str) {
    str = str.split('\\').join('\\\\');
    str = str.split(' ').join('\\ ');
    str = str.split('-').join('\\-');
    str = str.split('$').join('\\$');
    str = str.split(':').join('\\:');
    return str;
  }

  onSearchChange(searchText) {
    searchText = searchText.trim();
    searchText = this.escapString(searchText);
    this.setState({
      updateTotalSize: false,
    });

    const optionalParamValues = {};
    optionalParamValues.fetchSize = this.state.sizePerPage;
    optionalParamValues.sortName = this.state.sortName;
    optionalParamValues.sortOrder = this.state.sortOrder;
    optionalParamValues.getCount = false;
    if (searchText !== '') {
      optionalParamValues.start = 0;
      optionalParamValues.request_body = searchText;
      optionalParamValues.response_body = searchText;
      optionalParamValues.responsestatus = searchText;
      optionalParamValues.responsestatuscode = searchText;
      optionalParamValues.node_instance_id = searchText;
      optionalParamValues.duration = searchText;
      optionalParamValues.application_consumer_id = searchText;
      optionalParamValues.request_parameter_name1 = searchText;
      optionalParamValues.request_parameter_name2 = searchText;
      optionalParamValues.request_parameter_name3 = searchText;
      optionalParamValues.request_parameter_name4 = searchText;
      optionalParamValues.request_parameter_name5 = searchText;
      optionalParamValues.request_parameter_value1 = searchText;
      optionalParamValues.request_parameter_value2 = searchText;
      optionalParamValues.request_parameter_value3 = searchText;
      optionalParamValues.request_parameter_value4 = searchText;
      optionalParamValues.request_parameter_value5 = searchText;
      optionalParamValues.response_parameter_name1 = searchText;
      optionalParamValues.response_parameter_name2 = searchText;
      optionalParamValues.response_parameter_name3 = searchText;
      optionalParamValues.response_parameter_name4 = searchText;
      optionalParamValues.response_parameter_name5 = searchText;
      optionalParamValues.response_parameter_value1 = searchText;
      optionalParamValues.response_parameter_value2 = searchText;
      optionalParamValues.response_parameter_value3 = searchText;
      optionalParamValues.response_parameter_value4 = searchText;
      optionalParamValues.response_parameter_value5 = searchText;
      optionalParamValues.globalSearch = true;
    }
    Object.assign(optionalParamValues, this.props.params);
    this.setState({ optionalParamValues });
    this.fetchTableData(optionalParamValues);
    optionalParamValues.getCount = true;
    this.fetchTableData(optionalParamValues);
  }

  onFilterChange(filterObj) {
    const optionalParamValues = {};
    optionalParamValues.fetchSize = this.state.sizePerPage;
    optionalParamValues.sortName = this.state.sortName;
    optionalParamValues.sortOrder = this.state.sortOrder;
    optionalParamValues.globalSearch = false;
    optionalParamValues.start = 0;
    optionalParamValues.getCount = false;
    for (const key in filterObj) {
      switch (filterObj[key].type) {
        case 'NumberFilter': {
          optionalParamValues[key] = filterObj[key].value.number;
          break;
        }
        default: {
          optionalParamValues[key] = this.escapString(filterObj[key].value);
          break;
        }
      }
    }
    const propsParam = this.props.params;
    let continueFetchData = true;
    Object.assign(optionalParamValues, propsParam);
    if (this.props.tableType === 'transactions' || this.props.tableType === 'alertHistory' || this.props.tableType === 'exception') {
      if (filterObj.app_name && !propsParam.app_name.includes(filterObj.app_name.value)) {
        continueFetchData = false;
      } else if (filterObj.api_name && !propsParam.api_name.includes(filterObj.api_name.value)) {
        continueFetchData = false;
      } else if (filterObj.application_instance_id &&
          !propsParam.application_instance_id.includes(filterObj.application_instance_id.value)) {
        continueFetchData = false;
      } else if (filterObj.application_consumer_id && propsParam.user_action === 'creator') {
        optionalParamValues.application_consumer_id = filterObj.application_consumer_id.value;
      } else if (filterObj.application_consumer_id && propsParam.user_action === 'subscriber' &&
          !propsParam.application_consumer_id.includes(filterObj.application_consumer_id)) {
        continueFetchData = false;
      }
    }

    if (continueFetchData) {
      this.setState({ optionalParamValues });
      this.fetchTableData(optionalParamValues);
      optionalParamValues.getCount = true;
      this.fetchTableData(optionalParamValues);
      this.setState({
        updateTotalSize: false,
      });
    } else {
      this.setState({
        data: [],
        searchSize: 0,
        totalSize: 0,
        updateTotalSize: true,
      });
    }
  }

  onSortChange(sortName, sortOrder) {
    const optionalParamValues = this.state.optionalParamValues;
    optionalParamValues.getCount = false;
    optionalParamValues.sortName = sortName;
    optionalParamValues.sortOrder = sortOrder;
    optionalParamValues.start = 0;
    this.setState({
      sortName,
      sortOrder,
      currentPage: 1,
      optionalParamValues,
    });
    this.fetchTableData(optionalParamValues);
  }

  getRowDetailsDisplayStyle() {
    return this.state.showRowDetail ? { display: 'inherit' } : { display: 'none' };
  }

  getRowDetailsRender() {
    if (!this.props.showRowDetailsOnDoubleClick || this.props.tableType === 'alertHistory') return;

    return (
      <div id={'secondTable'} style={this.getRowDetailsDisplayStyle()}>
        <BootstrapTable data={this.state.rowData}>
          <TableHeaderColumn dataField="transaction_id" isKey={true} dataAlign="left" headerAlign="left" className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn" width="150">Transaction ID</TableHeaderColumn>
          <TableHeaderColumn dataField="request_body" dataAlign="left" headerAlign="left" className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn">Request Body</TableHeaderColumn>
          <TableHeaderColumn dataField="response_body" dataAlign="left" headerAlign="left" className="ClickableExpandableColumn" columnClassName="ClickableExpandableColumn">Response Body</TableHeaderColumn>
        </BootstrapTable>
      </div>
    );
  }

  render() {
    const options = {
      page: this.state.currentPage, // Page you want to show as default
      sizePerPageList: [
        { text: '10', value: 10 },
        { text: '25', value: 25 },
        { text: '30', value: 30 },
        { text: '50', value: 50 },
      ], // Dropdown list values
      sizePerPage: this.state.sizePerPage, // which size per page you want to display as default
      pageStartIndex: 1, // where to start counting the pages
      paginationSize: 5, // the pagination bar size
      prePage: 'Prev', // Previous page button text
      nextPage: 'Next', // Next page button text
      firstPage: 'First', // First page button text
      lastPage: 'Last', // Last page button text
      noDataText: this.state.gettingData ?
        common.messages.gettingdata :
        common.messages.nodata, // Text for empty table
      paginationShowsTotal: this.renderShowsTotal,
      onRowDoubleClick: this.onRowDoubleClick,
      onPageChange: this.onHandlePageChange,
      onSizePerPageList: this.onHandleSizePerPageChange,
      onSearchChange: this.onSearchChange,
      onFilterChange: this.onFilterChange,
      sortName: this.state.sortName,
      sortOrder: this.state.sortOrder,
      onSortChange: this.onSortChange,
      searchDelayTime: 500,
    };

    let transactionDetailField;
    let alertHistoryDetailField;
    if (this.props.tableType === 'transactions' || this.props.tableType === 'exception' || this.props.tableType === 'transactionId' || this.props.tableType === 'workflow' ) {
      transactionDetailField = (<div>
        <BootstrapTable ref="table" data={this.state.data} bordered={true} condensed={true} search={this.props.enableMultiColumnSearch} searchPlaceholder="Search All Columns" multiColumnSearch={true} striped={true} hover={true} pagination={this.props.enablePagination} exportCSV={this.props.enableExportToCsv} csvFileName="Table Data.csv" options={options} remote= {this.state.handleWithRemote} fetchInfo={{ dataTotalSize: this.state.totalSize }}>
          <TableHeaderColumn dataField="transaction_id" isKey={true} dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="150" dataFormat={ChartDetailsTable.tableCellTooltip} >Transaction ID</TableHeaderColumn>
          <TableHeaderColumn dataField="node_instance_id" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="150" dataFormat={ChartDetailsTable.tableCellTooltip} >Node Instance ID</TableHeaderColumn>
          <TableHeaderColumn dataField="app_name" csvHeader="App Name" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="150" dataFormat={ChartDetailsTable.tableCellTooltip} >App Name</TableHeaderColumn>
          <TableHeaderColumn dataField="api_name" csvHeader="Api Name" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="150" dataFormat={ChartDetailsTable.tableCellTooltip} >Api Name</TableHeaderColumn>
          <TableHeaderColumn dataField="start_time" csvHeader="Start Time" dataAlign="left" headerAlign="left" dataSort={true} width="190" dataFormat={ChartDetailsTable.tableCellTooltip} >Start Time</TableHeaderColumn>
          <TableHeaderColumn dataField="end_time" csvHeader="End Time" dataAlign="left" headerAlign="left" dataSort={true} width="190" dataFormat={ChartDetailsTable.tableCellTooltip} >End Time</TableHeaderColumn>
          <TableHeaderColumn dataField="duration" csvHeader="Duration" dataAlign="left" headerAlign="left" dataSort={true} width="100" dataFormat={ChartDetailsTable.tableCellTooltip} >Duration</TableHeaderColumn>
          <TableHeaderColumn dataField="application_instance_id" csvHeader="Application Instance ID" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="200" dataFormat={ChartDetailsTable.tableCellTooltip} >Application Instance ID</TableHeaderColumn>
          <TableHeaderColumn dataField="application_consumer_id" csvHeader="Application Consumer ID" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="200" dataFormat={ChartDetailsTable.tableCellTooltip} >Application Consumer ID</TableHeaderColumn>
          <TableHeaderColumn dataField="request_body" csvHeader="Request Body" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="350" dataFormat={ChartDetailsTable.tableCellTooltip} >Request Body</TableHeaderColumn>
          <TableHeaderColumn dataField="response_body" csvHeader="Response Body" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="350" dataFormat={ChartDetailsTable.tableCellTooltip} >Response Body</TableHeaderColumn>
          <TableHeaderColumn dataField="responsestatus" csvHeader="Response Status" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="150" dataFormat={ChartDetailsTable.tableCellTooltip} >Response Status</TableHeaderColumn>
          <TableHeaderColumn dataField="responsestatuscode" csvHeader="Response Status Code" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="180" dataFormat={ChartDetailsTable.tableCellTooltip} >Response Status Code</TableHeaderColumn>
          <TableHeaderColumn dataField="request_parameter_name1" csvHeader="Request Parameter Name1" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="210" dataFormat={ChartDetailsTable.tableCellTooltip} >Request Parameter Name1</TableHeaderColumn>
          <TableHeaderColumn dataField="request_parameter_value1" csvHeader="Request Parameter Value1" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="210" dataFormat={ChartDetailsTable.tableCellTooltip} >Request Parameter Value1</TableHeaderColumn>
          <TableHeaderColumn dataField="request_parameter_name2" csvHeader="Request Parameter Name2" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="210" dataFormat={ChartDetailsTable.tableCellTooltip} >Request Parameter Name2</TableHeaderColumn>
          <TableHeaderColumn dataField="request_parameter_value2" csvHeader="Request Parameter Value2" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="210" dataFormat={ChartDetailsTable.tableCellTooltip} >Request Parameter Value2</TableHeaderColumn>
          <TableHeaderColumn dataField="request_parameter_name3" csvHeader="Request Parameter Name3" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="210" dataFormat={ChartDetailsTable.tableCellTooltip} >Request Parameter Name3</TableHeaderColumn>
          <TableHeaderColumn dataField="request_parameter_value3" csvHeader="Request Parameter Value3" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="210" dataFormat={ChartDetailsTable.tableCellTooltip} >Request Parameter Value3</TableHeaderColumn>
          <TableHeaderColumn dataField="request_parameter_name4" csvHeader="Request Parameter Name4" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="210" dataFormat={ChartDetailsTable.tableCellTooltip} >Request Parameter Name4</TableHeaderColumn>
          <TableHeaderColumn dataField="request_parameter_value4" csvHeader="Request Parameter Value4" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="210" dataFormat={ChartDetailsTable.tableCellTooltip} >Request Parameter Value4</TableHeaderColumn>
          <TableHeaderColumn dataField="request_parameter_name5" csvHeader="Request Parameter Name5" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="210" dataFormat={ChartDetailsTable.tableCellTooltip} >Request Parameter Name5</TableHeaderColumn>
          <TableHeaderColumn dataField="request_parameter_value5" csvHeader="Request Parameter Value5" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="210" dataFormat={ChartDetailsTable.tableCellTooltip} >Request Parameter Value5</TableHeaderColumn>
          <TableHeaderColumn dataField="response_parameter_name1" csvHeader="Response Parameter Name1" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="215" dataFormat={ChartDetailsTable.tableCellTooltip} >Response Parameter Name1</TableHeaderColumn>
          <TableHeaderColumn dataField="response_parameter_value1" csvHeader="Response Parameter Value1" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="215" dataFormat={ChartDetailsTable.tableCellTooltip} >Response Parameter Value1</TableHeaderColumn>
          <TableHeaderColumn dataField="response_parameter_name2" csvHeader="Response Parameter Name1" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="215" dataFormat={ChartDetailsTable.tableCellTooltip} >Response Parameter Name2</TableHeaderColumn>
          <TableHeaderColumn dataField="response_parameter_value2" csvHeader="Response Parameter Value1" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="215" dataFormat={ChartDetailsTable.tableCellTooltip} >Response Parameter Value2</TableHeaderColumn>
          <TableHeaderColumn dataField="response_parameter_name3" csvHeader="Response Parameter Name1" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="215" dataFormat={ChartDetailsTable.tableCellTooltip} >Response Parameter Name3</TableHeaderColumn>
          <TableHeaderColumn dataField="response_parameter_value3" csvHeader="Response Parameter Value1" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="215" dataFormat={ChartDetailsTable.tableCellTooltip} >Response Parameter Value3</TableHeaderColumn>
          <TableHeaderColumn dataField="response_parameter_name4" csvHeader="Response Parameter Name1" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="215" dataFormat={ChartDetailsTable.tableCellTooltip} >Response Parameter Name4</TableHeaderColumn>
          <TableHeaderColumn dataField="response_parameter_value4" csvHeader="Response Parameter Value1" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="215" dataFormat={ChartDetailsTable.tableCellTooltip} >Response Parameter Value4</TableHeaderColumn>
          <TableHeaderColumn dataField="response_parameter_name5" csvHeader="Response Parameter Name1" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="215" dataFormat={ChartDetailsTable.tableCellTooltip} >Response Parameter Name5</TableHeaderColumn>
          <TableHeaderColumn dataField="response_parameter_value5" csvHeader="Response Parameter Value1" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="215" dataFormat={ChartDetailsTable.tableCellTooltip} >Response Parameter Value5</TableHeaderColumn>
        </BootstrapTable>
      </div>);
    } else if (this.props.tableType === 'alertHistory') {
      alertHistoryDetailField = (
        <BootstrapTable ref="table" data={this.state.data} bordered={true} condensed={true} search={this.props.enableMultiColumnSearch} searchPlaceholder="Search All Columns" multiColumnSearch={true} striped={true} hover={true} pagination={this.props.enablePagination} exportCSV={this.props.enableExportToCsv} csvFileName="Alert History.csv" options={options} remote= {this.state.handleWithRemote} fetchInfo={{ dataTotalSize: this.state.totalSize }}>
          <TableHeaderColumn dataField="app_name" isKey={true} csvHeader="App Name" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="150" dataFormat={ChartDetailsTable.tableCellTooltip} >App Name</TableHeaderColumn>
          <TableHeaderColumn dataField="api_name" csvHeader="Api Name" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="150" dataFormat={ChartDetailsTable.tableCellTooltip} >Api Name</TableHeaderColumn>
          <TableHeaderColumn dataField="application_instance_id" csvHeader="Application Instance ID" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="200" dataFormat={ChartDetailsTable.tableCellTooltip} >Application Instance ID</TableHeaderColumn>
          <TableHeaderColumn dataField="notification_sent_time" csvHeader="Notification Sent Time" dataAlign="left" headerAlign="left" dataSort={true} width="190" dataFormat={ChartDetailsTable.tableCellTooltip} >Notification Sent Time</TableHeaderColumn>
          <TableHeaderColumn dataField="notification_email_id" csvHeader="Alert Receiver Email Id" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="400" dataFormat={ChartDetailsTable.tableCellTooltip} >Alert Receiver Email Id</TableHeaderColumn>
          <TableHeaderColumn dataField="user_email_id" csvHeader="Alert Creator Email Id" dataAlign="left" headerAlign="left" dataSort={!handleWithRemote} filter={{ type: 'TextFilter' }} width="200" dataFormat={ChartDetailsTable.tableCellTooltip} >Alert Creator Email Id</TableHeaderColumn>
        </BootstrapTable>
      );
    }

    const handleWithRemote = this.state.handleWithRemote;
    return (
      <div>
        <Box direction="row" full="horizontal" justify="end" pad={{ horizontal: 'medium' }}>
          <Spinning style={{ visibility: this.state.gettingData ? 'visible' : 'hidden' }} />
        </Box>
        {transactionDetailField}
        {alertHistoryDetailField}
        {this.getRowDetailsRender()}
      </div>
    );
  }
}

ChartDetailsTable.propTypes = {
  tableType: React.PropTypes.string.isRequired,
  params: React.PropTypes.oneOfType([React.PropTypes.array, React.PropTypes.object]),
  startTime: React.PropTypes.string,
  endTime: React.PropTypes.string,
  enableExportToCsv: React.PropTypes.bool,
  enableMultiColumnSearch: React.PropTypes.bool,
  enablePagination: React.PropTypes.bool,
  expandRowOnDoubleClick: React.PropTypes.bool,
  onRowDoubleClick: React.PropTypes.func,
  showRowDetailsOnDoubleClick: React.PropTypes.bool,
};
