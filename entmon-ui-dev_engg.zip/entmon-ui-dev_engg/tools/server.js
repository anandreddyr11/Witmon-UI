// only ES5 is allowed in this file
require("babel-register");

// other babel configuration, if necessary

// load your app
require("./distServer.js");