# PageMill

![PageMill icon](docs/images/pagemill-app-icon.png)

PageMill is a comprehensive starter kit for rapid application development using Grommet, based upon [React Slingshot](https://github.com/coryhouse/react-slingshot) by [Cory House](http://www.bitnative.com/). 

Why PageMill?

1. **One command to get started** - Type `npm start` to start development in your default browser.
2. **Rapid feedback** - Each time you hit save, changes hot reload and linting and automated tests run.
3. **One command line to check** - All feedback is displayed on a single command line.
4. **No more JavaScript fatigue** - PageMill uses the most popular and powerful libraries for working with Grommet.
5. **Working example app** - The included example app shows how this all works together with included [Millstone](https://github.hpe.com/Centers-of-Excellence/UxUi-Millstone) components. Moreover, it is already pre-branded and standardized for HPE.
6. **Automated production build** - Type `npm run build` to be ready to release in production.

## Additional Information

Check out the [FAQ](/docs/FAQ.md) for additional information, questions, answers, and important topics to further assist in your use of PageMill. In addition, be sure to review [How Sample App Works](/docs/HowSampleAppWorks.md) to better understand the included sample application.

## Release Notes

To see what's new in the latest release, view the [release notes](/docs/ReleaseNotes.md).

## Get Started

1. **Initial Machine Setup** - First time running the starter kit? Then complete the [Initial Machine Setup](https://github.hpe.com/Centers-of-Excellence/UxUi-PageMill#initial-machine-setup).
2. **Clone the project** - `git clone https://github.hpe.com/Centers-of-Excellence/UxUi-PageMill.git`.
3. **Run the setup script** - `npm run setup` - Note: This will prompt you to enter project specific details (e.g. project name, author, license, etc.) and will delete all Git tracking as a result from cloning the project in the previous step. Afterward, all that's required is to rename the project folder and add to source control if desired.
4. **Configure Editor Config** - In order to promote shareable editor settings (e.g. tabs or spaces, etc.), an [.editorconfig](/.editorconfig) file is included. Modify it to suit the needs of your project and ensure the appropriate editor config plugin is installed. Learn more at [http://editorconfig.org](http://editorconfig.org). 
5. **Configure Linting Rules** - In order to promote quality coding standards, an [.eslintrc](/.eslintrc) file is included. Modify it to suit the needs of your project. To learn more about configuring this file, go [here](http://eslint.org/docs/user-guide/configuring).
6. **Run the example app** - `npm start -s`
This will run the automated build process, start up a webserver, and open the application in your default browser. When doing development with this kit, this command will continue watching all your files. Every time you hit save the code is rebuilt, linting runs, and tests run automatically. Note: The -s flag is optional. It enables silent mode which suppresses unnecessary messages during the build.
7. **Review the example app** - This starter kit includes a working example app that uses [Millstone](https://github.hpe.com/Centers-of-Excellence/UxUi-Millstone) components with proper HPE styling, layouts, and more. Note how all source code is placed under /src. Tests are placed alongside the file under test. The final built app is placed under `/dist`. These are the files you run in production.

## Initial Machine Setup

1. **Install [Node 4.0.0 or greater](https://nodejs.org)** - (5.0 or greater is recommended for optimal build performance). Need to run multiple versions of Node? Use [nvm](https://github.com/creationix/nvm).
2. **Install [Git](https://git-scm.com/downloads)**. 
3. **Update NPM to Latest Version** - `npm -g install npm`
4. **Configure NPM Proxy**. - `npm config set proxy http://web-proxy.corp.hpecorp.net:8080/` and `npm config set https-proxy http://web-proxy.corp.hpecorp.net:8080/`
5. **Configure @hpe Packages to Use Private NPM** - Setup npm to be able to fetch [Millstone](https://github.hpe.com/Centers-of-Excellence/UxUi-Millstone) from HPE's private npm server (all other packages will be fetched from public server). To do so, run the following command: `npm config set @hpe:registry https://registry.npmjs.itcs.hpecorp.net/`. Note the inclusion of "@hpe:" to specify that only @hpe packages come from the enterprise repo. If this step fails to work, locate **c:&#92;users&#92;username&#92;.npmrc** and replace it with [this](/docs/supplemental/.npmrc) file.

### On Mac

You're all set. If you're on Linux or Windows, complete the steps for your OS below.

### On Linux

[Increase the limit](http://stackoverflow.com/questions/16748737/grunt-watch-error-waiting-fatal-error-watch-enospc) on the number of files Linux will watch. [Here's the reason](https://github.com/coryhouse/react-slingshot/issues/6). This can be accomplished with the following command: `echo fs.inotify.max_user_watches=524288 | sudo tee -a /etc/sysctl.conf && sudo sysctl -p`

### On Windows

1. **Install [Python 2.7](https://www.python.org/downloads/)** - Some node modules may rely on node-gyp, which requires Python on Windows.
2. **Install C++ Compiler** -Browser-sync requires a C++ compiler on Windows. [Visual Studio Express](https://www.visualstudio.com/en-US/products/visual-studio-express-vs) comes bundled with a free C++ compiler. Or, if you already have Visual Studio installed: Open Visual Studio and go to File -> New -> Project -> Visual C++ -> Install Visual C++ Tools for Windows Desktop. The C++ compiler is used to compile browser-sync (and perhaps other Node modules).

## Technologies

PageMill offers a rich development experience using the following technologies:

| **Tech** | **Description** |**Learn More**|
|----------|-------|---|
|  [Grommet](https://github.com/grommet/grommet)  |   The most advanced UX framework for enterprise apps utilizing React.    | [More About Grommet](https://grommet.github.io/), [Pluralsight Course on React and Redux](http://www.pluralsight.com/courses/react-redux-react-router-es6/table-of-contents) |
|  [Redux](http://redux.js.org) |  Enforces unidirectional data flows and immutable, hot reloadable store. Supports time-travel debugging. Lean alternative to [Facebook's Flux](https://facebook.github.io/flux/docs/overview.html).| |
|  [React Router](https://github.com/reactjs/react-router) | A complete routing library for React | [Pluralsight Course](https://www.pluralsight.com/courses/react-flux-building-applications) |
|  [Babel](http://babeljs.io) |  Compiles ES6 to ES5. Enjoy the new version of JavaScript today.     | [ES6 REPL](https://babeljs.io/repl/), [ES6 vs ES5](http://es6-features.org), [ES6 Katas](http://es6katas.org), [Pluralsight course](https://www.pluralsight.com/courses/javascript-fundamentals-es6) |
| [Webpack](http://webpack.github.io) | Bundles npm packages and our JS into a single file. Includes hot reloading via [react-transform-hmr](https://www.npmjs.com/package/react-transform-hmr). | [Quick Webpack How-to](https://github.com/petehunt/webpack-howto) [Pluralsight Course](https://www.pluralsight.com/courses/webpack-fundamentals)|
| [Browsersync](https://www.browsersync.io/) | Lightweight development HTTP server that supports synchronized testing and debugging on multiple devices. | [Intro vid](https://www.youtube.com/watch?time_continue=1&v=heNWfzc7ufQ)|
| [Mocha](http://mochajs.org) | Automated tests with [Chai](http://chaijs.com/) for assertions and [Enzyme](https://github.com/airbnb/enzyme) for DOM testing without a browser using Node. | [Pluralsight Course](https://www.pluralsight.com/courses/testing-javascript) |
| [Isparta](https://github.com/douglasduteil/isparta) | Code coverage tool for ES6 code transpiled by Babel. |
| [ESLint](http://eslint.org/)| Lint JS. Reports syntax and style issues. Using [eslint-plugin-react](https://github.com/yannickcr/eslint-plugin-react) for additional React specific linting rules. | |
| [SASS](http://sass-lang.com/) | Compiled CSS styles with variables, functions, and more. | [Pluralsight Course](https://www.pluralsight.com/courses/better-css)|
| [PostCSS](https://github.com/postcss/postcss) | Transform styles with JS plugins. Used to autoprefix CSS. |
| [Editor Config](http://editorconfig.org) | Enforce consistent editor settings (spaces vs tabs, etc). | [IDE Plugins](http://editorconfig.org/#download) |
| [npm Scripts](https://docs.npmjs.com/misc/scripts)| Glues all this together in a handy automated build. | [Pluralsight course](https://www.pluralsight.com/courses/npm-build-tool-introduction), [Why not Gulp?](https://medium.com/@housecor/why-i-left-gulp-and-grunt-for-npm-scripts-3d6853dd22b8#.vtaziro8n)  |

The starter kit includes a working example app that puts all of the above to use. However, the following must be configured explicity: Redux and testing tools (Mocha, Chai, Enzyme, and Isparta). Editor Config file is already configured but should be tweaked based upon project preferences.

## Important Note About Internal/External Use

The **Open Source Program Office** has a special process that is required when deciding to use open source software within HPE. Since this project is based upon an open source project originally licensed under MIT,
it is for **internal use only**. However, if you wish to use this project for external purposes then a full review would be required. For more information, please go [here](http://opensource.corp.hpecorp.net/osrp.html).

Something else to note, when building for production all files are placed into a folder named **dist** which no longer contains code based upon the React Slingshot project. This information may help the Open Source Program Office in their review process.

## Derivative Works Copyright Notice

All dervivate works included within are &#169; Copyright 2016 Hewlett Packard Enterprise Development LP. This includes the sample application data and any changes or additions made to the original React Slingshot project by Cory House.
