// https://medium.com/@jerrymao/testing-react-js-components-with-enzyme-mocha-and-chai-534c7f000976

'use strict';
import _ from 'lodash';
import React from 'react';
import chai, { expect } from 'chai';
import chaiEnzyme from 'chai-enzyme';
import { mount } from 'enzyme';
import jsdom from 'jsdom';
import cheerio from 'cheerio';
import UserProfileMenu from '../../../src/components/home/UserProfileMenu';
import Button from 'grommet/components/Button';

chai.use(chaiEnzyme());

const defaultState = {
  loginErrored: {
    hasErrored: false,
  },
  loginProcessComplete: () => {
  },
  loginIsProcessing: false,
  processLogin: {
  },
  processLogout: {
  },
  userProfile: {
    loggedin: true,
  },
};

const defaultStore = {
  dispatch: () => undefined,
  getState() {
    return defaultState;
  },
  subscribe: () => undefined,
};

const defaultRouter = {
  push: () => {},
};

describe('(Component) UserProfileMenu', () => {
  it('should exist', () => {
    // Because router is accessed in this case, we need to add it to the component's context.
    // childContextTypes option not specified in documentation but is referenced here https://github.com/airbnb/enzyme/pull/171
    const wrapper = mount(<UserProfileMenu store={defaultStore} />, {
      context: { router: defaultRouter },
      childContextTypes: { router: React.PropTypes.object },
    });
    expect(wrapper).to.exist;
  });
  it('renders without exploding', () => {
    const wrapper = mount(<UserProfileMenu store={defaultStore} />, {
      context: { router: defaultRouter },
      childContextTypes: { router: React.PropTypes.object },
    });
    expect(wrapper).to.have.length(1);
  });
  it('should have type UserProfileMenu', () => {
    const wrapper = mount(<UserProfileMenu store={defaultStore} />, {
      context: { router: defaultRouter },
      childContextTypes: { router: React.PropTypes.object },
    });
    expect(wrapper).to.have.type(UserProfileMenu);
  });
  it('should have a Button with label "Please Wait..." when logged out and login is processing', () => {
    const caseState = _.cloneDeep(defaultState);
    caseState.userProfile.loggedin = false;
    caseState.loginIsProcessing = true;
    const caseStore = _.cloneDeep(defaultStore);
    caseStore.getState = () => caseState;
    const wrapper = mount(<UserProfileMenu store={caseStore} />, {
      context: { router: defaultRouter },
      childContextTypes: { router: React.PropTypes.object },
    });
    expect(wrapper.find(Button)).to.have.prop('label', 'Please Wait...');
  });
  it('should have a Button with label "Login" when logged out', () => {
    const caseState = _.cloneDeep(defaultState);
    caseState.userProfile.loggedin = false;
    const caseStore = _.cloneDeep(defaultStore);
    caseStore.getState = () => caseState;
    const wrapper = mount(<UserProfileMenu store={caseStore} />, {
      context: { router: defaultRouter },
      childContextTypes: { router: React.PropTypes.object },
    });
    expect(wrapper.find(Button)).to.have.prop('label', 'Login');
  });
  it('should have a logout Button and add users Button on when user is logged in', () => {
    const wrapper = mount(<UserProfileMenu store={defaultStore} />, {
      context: { router: defaultRouter },
      childContextTypes: { router: React.PropTypes.object },
    });
    // Simulate a click on the dropdown menu
    wrapper.find('button').simulate('click');
    // Because Grommet uses javascript DOM manipulation on the root of the document body,
    // instead of within the component itself, to hide/show dropdowns on the Grommet
    // Menu component, we need to go into the jsdom document, instead of the Enzyme
    // wrapper, to make test assertions.
    const $ = cheerio.load(jsdom.serializeDocument(global.document));
    expect($('.grommetux-drop ul li:nth-child(1) button')).to.contain.text('Add a User to your app group');
    expect($('.grommetux-drop ul li:nth-child(2) button')).to.contain.text('Logout');
  });
});
