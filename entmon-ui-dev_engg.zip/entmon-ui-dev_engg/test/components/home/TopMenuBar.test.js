'use strict';

import _ from 'lodash';
import React from 'react';
import chai, { expect } from 'chai';
import chaiEnzyme from 'chai-enzyme';
import { mount } from 'enzyme';
import jsdom from 'jsdom';
import cheerio from 'cheerio';
import TopMenuBar from '../../../src/components/home/TopMenuBar';

chai.use(chaiEnzyme());

const defaultState = {
  appFilterInput: '',
  menuAppnames: [
    { appName: 'All Apps' },
    { appName: 'testing' },
    { appName: 'some more testing' },
  ],
  menuAppNamesSelected: [
    true,
    true,
    true,
  ],
  menuLabel: 'menuLabel',
  menuTheme: 'light-theme',
  menuShowAppnames: true,
  menuShowTimeRange: true,
  menuAutoRefresh: true,
  menuOptions: {},
  menuShowMenu: true,
  userProfile: {
    loggedin: true,
  },
};

const defaultStore = {
  dispatch: () => undefined,
  getState() {
    return defaultState;
  },
  subscribe: () => undefined,
};

describe('(Component) TopMenuBar', () => {
  it('should show "All Apps" on app menu when all apps are selected', () => {
    const wrapper = mount(<TopMenuBar store={defaultStore} />);
    expect(wrapper.find('#apps-menu button')).to.contain.text('All Apps');
  });
  it('should show app name "some more testing" on app menu when only "some more testing" app is selected', () => {
    const caseState = _.cloneDeep(defaultState);
    caseState.menuAppNamesSelected[0] = false;
    caseState.menuAppNamesSelected[1] = false;
    const caseStore = _.cloneDeep(defaultStore);
    caseStore.getState = () => caseState;
    const wrapper = mount(<TopMenuBar store={caseStore} />);
    expect(wrapper.find('#apps-menu button')).to.contain.text('some more testing');
  });
  it('should show "No Apps" on app menu when no apps are selected', () => {
    const caseState = _.cloneDeep(defaultState);
    caseState.menuAppNamesSelected[0] = false;
    caseState.menuAppNamesSelected[1] = false;
    caseState.menuAppNamesSelected[2] = false;
    const caseStore = _.cloneDeep(defaultStore);
    caseStore.getState = () => caseState;
    const wrapper = mount(<TopMenuBar store={caseStore} />);
    expect(wrapper.find('#apps-menu button')).to.contain.text('No Apps');
  });
  it('should show all app names in the app names dropdown when nothing is in app name filter input', () => {
    const wrapper = mount(<TopMenuBar store={defaultStore} />);
    // Simulate a click on the dropdown menu
    wrapper.find('#apps-menu button').simulate('click');
    const $ = cheerio.load(jsdom.serializeDocument(global.document));
    expect($('.grommetux-drop ul li:nth-child(1)')).to.contain.text('All Apps');
    expect($('.grommetux-drop ul li:nth-child(2)')).to.contain.text('testing');
    expect($('.grommetux-drop ul li:nth-child(3)')).to.contain.text('some more testing');
  });
  it('should only show "some more testing" in the app names dropdown when "more" is in the app name filter input', () => {
    const caseState = _.cloneDeep(defaultState);
    caseState.appFilterInput = 'more';
    const caseStore = _.cloneDeep(defaultStore);
    caseStore.getState = () => caseState;
    const wrapper = mount(<TopMenuBar store={caseStore} />);
    // Simulate a click on the dropdown menu
    wrapper.find('#apps-menu button').simulate('click');
    const $ = cheerio.load(jsdom.serializeDocument(global.document));
    expect($('.grommetux-drop ul li:nth-child(1)')).to.contain.text('some more testing');
  });
});
